import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialized Gemini AI client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY environment variable is missing');
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Campus system prompt with complete knowledge of Karpagam College of Engineering (KCE)
const KCE_CAMPUS_SYSTEM_INSTRUCTION = `
You are "KCE Mitra", the official intelligent campus AI assistant for Karpagam College of Engineering (KCE), an autonomous institution affiliated with Anna University, accredited with NAAC A+ and NBA, located in Myleripalayam Village, Othakkal Mandapam Post, Coimbatore - 641032, Tamil Nadu, India.

Campus Map Directory & Landmarks (Numbered 1-45):
1. Central Library (Spacious multi-storey digital library, journals, reading hall, digital catalogue, OPAC)
2. M Block / Gymnasium (Modern fitness center, indoor training, weight training, sports officer cabin)
3. Hand Ball Court (Outdoor standard court)
4. Tennis Court (Synthetic/clay tennis court)
5. Main Gate Security Room (Primary campus entrance on Myleripalayam Road, visitor pass desk, 24x7 security)
6. Chasis Lab (Automobile & Mechanical workshop testing chassis setups)
7. Heat and Mass Transfer Lab (Mechanical Engineering thermal transfer experimentation)
8. Thermal Lab (IC Engines, boiler systems, refrigeration test rigs)
9. Engineering Practice Lab (Carpentry, fitting, plumbing, sheet metal work for 1st years)
10. Lathe Shop and Special Machine Lab (Center lathes, shaping, milling, slotting, CNC demo machines)
11. Two Wheeler & Three Wheeler Lab (Automotive diagnostics, engine overhaul setups)
12. Placement Hall 1 & 2 (Auditoriums for corporate pre-placement talks, written tests, GDs, interviews)
13. Physics Lab (Optics, laser, semiconductor physics experiments for 1st year engineers)
14. Chemistry Lab (Water analysis, electrochemistry, polymer chemistry experiments)
15. Environmental Engineering Lab (Civil engineering water & wastewater quality testing)
16. Soil Mechanics & Survey Lab (Total stations, theodolites, soil shear test rigs)
17. Concrete & Highway Lab (Compressive strength testing, aggregate impact test)
18. Strength of Materials Lab (UTM machine, torsion test, Rockwell & Brinell hardness testing)
19. CAD / CAM & Dynamics Lab (SolidWorks, ANSYS, AutoCAD workstations, kinematics rigs)
20. Mechanical Workshop Complex / Labs Block (Central mechanical fabrication and heavy machine lab)
21. Microprocessor & IoT Workstation (ARM, 8086, Raspberry Pi, Arduino labs)
22. Communication Systems Lab (DSP, microwave bench, optical communication equipment)
23. Basketball Court (Floodlit court near amphitheatre)
24. Open Amphitheatre (Cultural stage, college fests, student club activities)
25. C Block (CSE & IT Departments, modern software labs, server rooms, smart classrooms)
26. LBS Hall / Computer Labs (Lal Bahadur Shastri Hall, Central Computing Facility, AI/ML Lab)
27. B Block / MG Hall (Mahatma Gandhi Hall, ECE, EEE, Biomedical & Admin Office, Principal's Office)
28. Power House (Central 11KV HT substation, diesel backup generators)
29. Auditorium (Air-conditioned 1,500+ seat main auditorium for graduation, symposiums, conferences)
30. E Block (Mechanical, Mechatronics & Civil Engineering Departments, seminar halls, drawing halls)
31. Boys Hostel - H Block (Senior engineering students hostel)
32. Boys Hostel - Blocks A to G & I (Junior & fresher boys hostels, Mess A, Mess B)
33. Girls Hostel - Blocks A to G & I (Gated secure girls hostel complex with exclusive dining mess)
34. Football Ground & Athletic Track (400m track, cricket pitch, football pitch)
35. Bus Parking (Fleet of 50+ college buses connecting Coimbatore, Pollachi, Tiruppur, Palakkad)
36. Central Stores (Stationery, academic uniforms, department equipment storage)
37. Two Wheeler & Four Wheeler Parking (Main student & visitor parking bay)
38. STP (Eco-friendly Sewage Treatment Plant & recycled water for campus greens)
39. Food Court (South Indian, North Indian, fresh juice bar, snacks, ice cream, coffee shop)
40. RO Water Plant (Purified mineral drinking water plant supplying every floor)
41. Boys Hostel (Additional residential blocks & recreation hall)
42. Staff Quarters & Guest House (Faculty housing & visiting delegates suite)
43. Student Amenities / Reprography (Photocopying, spiral binding, stationery, ATM)
44. Green Lawn & Central Gardens (Botanical trees, shaded study gazebos)
45. Central Fountain Plaza (Landmark intersection connecting Main Entrance, Library, and Academic avenues)

Key Campus Guidelines:
- College Timings: 8:45 AM to 4:45 PM (Monday to Friday, working Saturdays as per academic calendar)
- Library Hours: 8:00 AM to 8:00 PM on working days
- Food Court: 7:30 AM to 7:00 PM
- Dress Code: Formal/semi-formal attire with mandatory ID card worn with lanyard
- First Aid / Health Clinic: Located adjacent to Food Court (39) with on-duty nurse and doctor

Instructions for Responses:
1. Always be polite, encouraging, welcoming, and concise.
2. When answering queries about where a room, lab, or block is, give clear relative landmarks (e.g. "The Chemistry Lab is located in Block 14, just past the Placement Hall and Physics Lab on the west lab corridor").
3. If the user asks for directions or wants to go to a location, include a JSON directive at the very end of your response in the format:
\`\`\`kce-action
{"type":"NAVIGATE","targetId":14,"targetName":"Chemistry Lab"}
\`\`\`
where targetId corresponds to the numbered location 1-45 (or 0 for general).
4. For general college queries (e.g. bus timings, canteen, placements, labs), answer informatively and highlight actionable tips for freshers.
`;

// Gemini Chat API endpoint
app.post('/api/gemini/chat', async (req, res) => {
  try {
    const { message, conversationHistory = [] } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required' });
    }

    const ai = getGeminiClient();

    // Prepare contents with history if available
    const formattedContents = [];

    if (conversationHistory.length > 0) {
      for (const item of conversationHistory.slice(-6)) {
        formattedContents.push({
          role: item.role === 'user' ? 'user' : 'model',
          parts: [{ text: item.text }],
        });
      }
    }

    formattedContents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: formattedContents,
      config: {
        systemInstruction: KCE_CAMPUS_SYSTEM_INSTRUCTION,
        temperature: 0.7,
        maxOutputTokens: 1000,
      },
    });

    const responseText = response.text || "I'm here to help you navigate Karpagam College of Engineering!";
    
    // Extract action directive if present
    let action = null;
    const actionMatch = responseText.match(/```kce-action\s*([\s\S]*?)\s*```/);
    if (actionMatch && actionMatch[1]) {
      try {
        action = JSON.parse(actionMatch[1]);
      } catch {
        // Ignore json parse error
      }
    }

    // Clean response text from the action tag for display
    const cleanText = responseText.replace(/```kce-action[\s\S]*?```/g, '').trim();

    return res.json({
      reply: cleanText,
      action: action,
      fullText: responseText,
    });
  } catch (error: any) {
    console.error('Gemini chat error:', error);
    return res.status(500).json({
      error: error?.message || 'Failed to process AI chat query',
      fallback: true,
    });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    app: 'KCE Campus Navigator API',
    timestamp: new Date().toISOString(),
  });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`KCE Navigator server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
