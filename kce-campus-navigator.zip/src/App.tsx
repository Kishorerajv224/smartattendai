/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { HeaderNavbar } from './components/HeaderNavbar';
import { HomeDashboard } from './components/HomeDashboard';
import { GoogleCampusMap } from './components/GoogleCampusMap';
import { CampusMapCanvas } from './components/CampusMapCanvas';
import { BuildingDetailModal } from './components/BuildingDetailModal';
import { NavigationPanel } from './components/NavigationPanel';
import { IndoorNavigatorModal } from './components/IndoorNavigatorModal';
import { QRScannerModal } from './components/QRScannerModal';
import { AiChatDrawer } from './components/AiChatDrawer';
import { VoiceAssistantModal } from './components/VoiceAssistantModal';
import { CampusLegendDirectory } from './components/CampusLegendDirectory';
import { OfflineBanner } from './components/OfflineBanner';
import { LiveLocationManager } from './components/LiveLocationManager';

import { CAMPUS_LOCATIONS, NAV_NODES, KCE_BASE_COORDINATES } from './data/campusData';
import { CampusLocation, RouteResult, UserLiveLocation } from './types/campus';
import { RouteSettings } from './components/RoutingSettingsPanel';
import {
  calculateShortestPath,
  findNearestNode,
  findNodeByBuildingId,
} from './utils/pathfinding';
import { speakText } from './utils/speech';

export default function App() {
  // Navigation tabs: 'home' | 'map' | 'directory' | 'indoor' | 'chat'
  const [activeTab, setActiveTab] = useState<'home' | 'map' | 'directory' | 'indoor' | 'chat'>('home');

  // Map view mode: 'vector_canvas' (Blueprint Map) as default, can toggle to 'google_map'
  const [mapEngine, setMapEngine] = useState<'google_map' | 'vector_canvas'>('vector_canvas');
  const [mapLayer, setMapLayer] = useState<'hybrid' | 'vector' | 'satellite'>('hybrid');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [selectedLocation, setSelectedLocation] = useState<CampusLocation | null>(null);

  // Route Settings State (Starting Point to Destination)
  const [routeSettings, setRouteSettings] = useState<RouteSettings>({
    originType: 'gps',
    originBuildingId: 5, // Main Entrance Gate
    destinationBuildingId: 1, // Central Library
    preference: 'fastest',
  });
  const [isRoutingPanelOpen, setIsRoutingPanelOpen] = useState<boolean>(false);

  // User Live GPS State (Default starts near Main Entrance Gate #5)
  const [userLocation, setUserLocation] = useState<UserLiveLocation>({
    x: 320,
    y: 435,
    lat: KCE_BASE_COORDINATES.lat,
    lng: KCE_BASE_COORDINATES.lng,
    heading: 90,
    isSimulated: false,
    accuracy: 3,
  });

  // Active Route & Navigation State
  const [activeRoute, setActiveRoute] = useState<RouteResult | null>(null);
  const [destinationLocation, setDestinationLocation] = useState<CampusLocation | null>(null);
  const [isSimulatingWalk, setIsSimulatingWalk] = useState<boolean>(false);

  // Modals & Panels
  const [showLiveLocationModal, setShowLiveLocationModal] = useState<boolean>(false);
  const [showBuildingDetail, setShowBuildingDetail] = useState<boolean>(false);
  const [showFloorPlanModal, setShowFloorPlanModal] = useState<boolean>(false);
  const [floorPlanLocation, setFloorPlanLocation] = useState<CampusLocation | null>(null);
  const [floorPlanInitialFloor, setFloorPlanInitialFloor] = useState<number>(0);
  const [showQRScannerModal, setShowQRScannerModal] = useState<boolean>(false);
  const [showVoiceModal, setShowVoiceModal] = useState<boolean>(false);
  const [showAiChatDrawer, setShowAiChatDrawer] = useState<boolean>(false);
  const [aiChatInitialPrompt, setAiChatInitialPrompt] = useState<string>('');

  // Real-world GPS watch position if available
  useEffect(() => {
    if ('geolocation' in navigator) {
      const watchId = navigator.geolocation.watchPosition(
        (pos) => {
          // If within Coimbatore vicinity, update live coordinates
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          if (lat > 10.8 && lat < 11.0 && lng > 76.8 && lng < 77.1) {
            setUserLocation((prev) => ({
              ...prev,
              lat,
              lng,
              heading: pos.coords.heading || prev.heading,
              accuracy: pos.coords.accuracy,
            }));
          }
        },
        () => {},
        { enableHighAccuracy: true, maximumAge: 5000, timeout: 10000 }
      );
      return () => navigator.geolocation.clearWatch(watchId);
    }
  }, []);

  // Handle building selection
  const handleSelectLocation = useCallback((loc: CampusLocation) => {
    setSelectedLocation(loc);
    setShowBuildingDetail(true);
  }, []);

  // Compute Shortest Path Dijkstra Navigation between starting point and destination
  const handleCalculateRoute = useCallback(
    (startBuildingId: number | null, endBuildingId: number) => {
      const targetLoc = CAMPUS_LOCATIONS.find((l) => l.id === endBuildingId);
      if (!targetLoc) return;

      let startNodeId: string | null = null;
      if (startBuildingId !== null) {
        const originLoc = CAMPUS_LOCATIONS.find((l) => l.id === startBuildingId);
        const node = findNodeByBuildingId(startBuildingId);
        if (node) {
          startNodeId = node.id;
        } else if (originLoc) {
          const nearest = findNearestNode(originLoc.coordinates.x, originLoc.coordinates.y);
          startNodeId = nearest ? nearest.id : null;
        }
      } else {
        const nearest = findNearestNode(userLocation.x, userLocation.y);
        startNodeId = nearest ? nearest.id : null;
      }

      const endNode = findNodeByBuildingId(endBuildingId);
      const endNodeId = endNode ? endNode.id : null;

      if (!startNodeId || !endNodeId) {
        alert('Could not determine walkable route between the selected points.');
        return;
      }

      const routeResult = calculateShortestPath(startNodeId, endNodeId, endBuildingId);
      if (routeResult) {
        setActiveRoute(routeResult);
        setDestinationLocation(targetLoc);
        setSelectedLocation(targetLoc);
        setIsSimulatingWalk(false);
      } else {
        alert(`No direct path found to ${targetLoc.name}.`);
      }
    },
    [userLocation.x, userLocation.y]
  );

  // Compute Shortest Path Dijkstra Navigation & Launch Map
  const handleStartNavigation = useCallback(
    (targetLoc?: CampusLocation, originBuildingId?: number | null) => {
      const dest = targetLoc || (routeSettings.destinationBuildingId ? CAMPUS_LOCATIONS.find((l) => l.id === routeSettings.destinationBuildingId) : null);
      if (!dest) return;

      const originId = originBuildingId !== undefined 
        ? originBuildingId 
        : (routeSettings.originType === 'building' ? routeSettings.originBuildingId : null);

      let startNodeId: string | null = null;
      if (originId !== null) {
        const originLoc = CAMPUS_LOCATIONS.find((l) => l.id === originId);
        const node = findNodeByBuildingId(originId);
        if (node) {
          startNodeId = node.id;
        } else if (originLoc) {
          const nearest = findNearestNode(originLoc.coordinates.x, originLoc.coordinates.y);
          startNodeId = nearest ? nearest.id : null;
        }
        // Update user location position if starting from a specific building
        if (originLoc) {
          setUserLocation((prev) => ({
            ...prev,
            x: originLoc.coordinates.x,
            y: originLoc.coordinates.y,
            lat: originLoc.coordinates.lat || prev.lat,
            lng: originLoc.coordinates.lng || prev.lng,
          }));
        }
      } else {
        const nearest = findNearestNode(userLocation.x, userLocation.y);
        startNodeId = nearest ? nearest.id : null;
      }

      const endNode = findNodeByBuildingId(dest.id);
      if (!startNodeId || !endNode) {
        alert('Could not determine walkable route to this location.');
        return;
      }

      const routeResult = calculateShortestPath(startNodeId, endNode.id, dest.id);

      if (routeResult) {
        setActiveRoute(routeResult);
        setDestinationLocation(dest);
        setSelectedLocation(dest);
        setActiveTab('map');
        setIsSimulatingWalk(false);

        // Voice announcement
        speakText(`Navigating to ${dest.name}. Estimated distance: ${routeResult.totalDistanceMeters} meters.`);
      } else {
        alert(`No direct path found to ${dest.name}.`);
      }
    },
    [routeSettings.destinationBuildingId, routeSettings.originType, routeSettings.originBuildingId, userLocation.x, userLocation.y]
  );

  // Set Origin from building marker click / menu
  const handleSetOrigin = useCallback((loc: CampusLocation) => {
    setRouteSettings((prev) => ({
      ...prev,
      originType: 'building',
      originBuildingId: loc.id,
    }));
    setUserLocation((prev) => ({
      ...prev,
      x: loc.coordinates.x,
      y: loc.coordinates.y,
      lat: loc.coordinates.lat || prev.lat,
      lng: loc.coordinates.lng || prev.lng,
    }));
    setIsRoutingPanelOpen(true);
    speakText(`Set ${loc.name} as start point.`);
  }, []);

  // Set Destination from building marker click / menu
  const handleSetDestination = useCallback((loc: CampusLocation) => {
    setRouteSettings((prev) => ({
      ...prev,
      destinationBuildingId: loc.id,
    }));
    setIsRoutingPanelOpen(true);
    speakText(`Set ${loc.name} as destination.`);
  }, []);

  // End navigation
  const handleEndNavigation = useCallback(() => {
    setActiveRoute(null);
    setDestinationLocation(null);
    setIsSimulatingWalk(false);
  }, []);

  // Floor plan triggers
  const handleOpenFloorPlan = useCallback((loc: CampusLocation, floorNum: number = 0) => {
    setFloorPlanLocation(loc);
    setFloorPlanInitialFloor(floorNum);
    setShowFloorPlanModal(true);
  }, []);

  // QR checkpoint selection callback
  const handleCheckpointLocation = useCallback((loc: CampusLocation, floorNumber?: number) => {
    setSelectedLocation(loc);
    setActiveTab('map');
    // Set user position to this checkpoint
    setUserLocation({
      x: loc.coordinates.x,
      y: loc.coordinates.y,
      lat: loc.coordinates.lat || KCE_BASE_COORDINATES.lat,
      lng: loc.coordinates.lng || KCE_BASE_COORDINATES.lng,
      heading: 0,
      isSimulated: false,
    });
    if (floorNumber !== undefined && loc.floors && loc.floors.length > 0) {
      handleOpenFloorPlan(loc, floorNumber);
    }
  }, [handleOpenFloorPlan]);

  // AI chat trigger from anywhere
  const handleAskAi = useCallback((prompt: string) => {
    setAiChatInitialPrompt(prompt);
    setShowAiChatDrawer(true);
  }, []);

  return (
    <div className="w-full h-screen flex flex-col bg-slate-950 text-slate-100 overflow-hidden font-sans">
      {/* Offline Status Listener */}
      <OfflineBanner />

      {/* Header & Main Nav Bar */}
      <HeaderNavbar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          if (tab === 'chat') {
            setShowAiChatDrawer(true);
          } else {
            setActiveTab(tab);
          }
        }}
        onOpenVoice={() => setShowVoiceModal(true)}
        onOpenQRScanner={() => setShowQRScannerModal(true)}
        onSelectLocation={handleSelectLocation}
        mapLayer={mapLayer}
        setMapLayer={setMapLayer}
        isNavigating={!!activeRoute}
        userLocation={userLocation}
        onOpenLiveLocation={() => setShowLiveLocationModal(true)}
      />

      {/* Main View Area */}
      <main className="flex-1 relative overflow-hidden">
        {activeTab === 'home' ? (
          <HomeDashboard
            userLocation={userLocation}
            routeSettings={routeSettings}
            setRouteSettings={setRouteSettings}
            onNavigateToDestination={(dest, originId) => handleStartNavigation(dest, originId)}
            onOpenMap={() => setActiveTab('map')}
            onOpenVoice={() => setShowVoiceModal(true)}
            onOpenQRScanner={() => setShowQRScannerModal(true)}
            onOpenAiChat={(prompt) => {
              if (prompt) setAiChatInitialPrompt(prompt);
              setShowAiChatDrawer(true);
            }}
            onOpenFloorPlan={(loc) => handleOpenFloorPlan(loc)}
            activeRoute={activeRoute}
            onCalculateRoute={handleCalculateRoute}
            onStartNavigation={() => handleStartNavigation()}
            onClearRoute={handleEndNavigation}
            onOpenLiveLocation={() => setShowLiveLocationModal(true)}
          />
        ) : activeTab === 'map' ? (
          mapEngine === 'google_map' ? (
            <div className="w-full h-full relative">
              <GoogleCampusMap
                selectedLocation={selectedLocation}
                onSelectLocation={(loc) => {
                  setSelectedLocation(loc);
                  setShowBuildingDetail(true);
                }}
                activeRoute={activeRoute}
                userLocation={userLocation}
                setUserLocation={setUserLocation}
                onStartNavigation={handleStartNavigation}
                onOpenFloorPlan={handleOpenFloorPlan}
                onOpenLocationDetail={(loc) => {
                  setSelectedLocation(loc);
                  setShowBuildingDetail(true);
                }}
                categoryFilter={categoryFilter}
                setCategoryFilter={setCategoryFilter}
                onSwitchToVectorMap={() => setMapEngine('vector_canvas')}
              />
              <button
                onClick={() => setMapEngine('vector_canvas')}
                className="absolute top-4 right-4 z-20 px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-bold shadow-2xl flex items-center gap-1.5 transition-all border border-amber-300"
              >
                🗺️ Switch to Official Blueprint Map
              </button>
            </div>
          ) : (
            <div className="w-full h-full relative">
              <CampusMapCanvas
                selectedLocation={selectedLocation}
                onSelectLocation={handleSelectLocation}
                activeRoute={activeRoute}
                userLocation={userLocation}
                setUserLocation={setUserLocation}
                mapLayer={mapLayer}
                setMapLayer={setMapLayer}
                isSimulatingWalk={isSimulatingWalk}
                onOpenLocationDetail={(loc) => {
                  setSelectedLocation(loc);
                  setShowBuildingDetail(true);
                }}
                categoryFilter={categoryFilter}
                setCategoryFilter={setCategoryFilter}
                onSetOrigin={handleSetOrigin}
                onSetDestination={handleSetDestination}
                onOpenRoutingPanel={() => setIsRoutingPanelOpen(true)}
                onOpenLiveLocationModal={() => setShowLiveLocationModal(true)}
              />
              {/* Button to toggle to Google Satellite Map */}
              <button
                onClick={() => setMapEngine('google_map')}
                className="absolute bottom-6 right-4 z-20 px-3 py-1.5 bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white rounded-xl text-xs font-semibold shadow-2xl border border-slate-700 flex items-center gap-1.5 transition-all backdrop-blur-md"
              >
                🛰️ Satellite View
              </button>
            </div>
          )
        ) : (
          <div className="w-full h-full overflow-y-auto bg-slate-950">
            <CampusLegendDirectory
              onSelectLocation={(loc) => {
                setSelectedLocation(loc);
                setActiveTab('map');
              }}
              onNavigateToLocation={(loc) => {
                handleStartNavigation(loc);
              }}
              onOpenFloorPlan={(loc) => {
                handleOpenFloorPlan(loc);
              }}
              onOpenQR={(loc) => {
                setShowQRScannerModal(true);
              }}
            />
          </div>
        )}

        {/* Turn-by-Turn Navigation Overlay Panel */}
        {activeRoute && destinationLocation && (
          <NavigationPanel
            route={activeRoute}
            destination={destinationLocation}
            onEndNavigation={handleEndNavigation}
            userLocation={userLocation}
            setUserLocation={setUserLocation}
            isSimulatingWalk={isSimulatingWalk}
            setIsSimulatingWalk={setIsSimulatingWalk}
            onOpenFloorPlan={handleOpenFloorPlan}
            onOpenQRScanner={() => setShowQRScannerModal(true)}
          />
        )}
      </main>

      {/* Live Location & High-Accuracy GPS Access Manager Modal */}
      <LiveLocationManager
        isOpen={showLiveLocationModal}
        onClose={() => setShowLiveLocationModal(false)}
        userLocation={userLocation}
        setUserLocation={setUserLocation}
        onOpenMapCanvas={() => {
          setActiveTab('map');
          setMapEngine('vector_canvas');
        }}
        onSpeak={speakText}
        onSetAsRouteOrigin={handleSetOrigin}
      />

      {/* Building Detail Modal */}
      {showBuildingDetail && (
        <BuildingDetailModal
          location={selectedLocation}
          onClose={() => setShowBuildingDetail(false)}
          onStartNavigation={handleStartNavigation}
          onSetOrigin={handleSetOrigin}
          onOpenFloorPlan={handleOpenFloorPlan}
          onScanQR={(loc) => {
            setShowBuildingDetail(false);
            setShowQRScannerModal(true);
          }}
          onAskAi={handleAskAi}
        />
      )}

      {/* Indoor Floor Plan Navigator Modal */}
      {showFloorPlanModal && floorPlanLocation && (
        <IndoorNavigatorModal
          location={floorPlanLocation}
          onClose={() => setShowFloorPlanModal(false)}
          initialFloor={floorPlanInitialFloor}
        />
      )}

      {/* Indoor QR Scanner Modal */}
      {showQRScannerModal && (
        <QRScannerModal
          onClose={() => setShowQRScannerModal(false)}
          onSelectCheckpointLocation={handleCheckpointLocation}
          onOpenFloorPlan={handleOpenFloorPlan}
        />
      )}

      {/* Voice Assistant Hands-Free Modal */}
      <VoiceAssistantModal
        isOpen={showVoiceModal}
        onClose={() => setShowVoiceModal(false)}
        onNavigateToLocation={handleStartNavigation}
      />

      {/* AI Mitra Chat Drawer (Gemini 3.7) */}
      <AiChatDrawer
        isOpen={showAiChatDrawer}
        onClose={() => {
          setShowAiChatDrawer(false);
          setAiChatInitialPrompt('');
        }}
        onNavigateToBuilding={handleStartNavigation}
        onOpenFloorPlan={handleOpenFloorPlan}
        onLocateOnMap={(loc) => {
          setSelectedLocation(loc);
          setActiveTab('map');
        }}
        initialPrompt={aiChatInitialPrompt}
      />
    </div>
  );
}
