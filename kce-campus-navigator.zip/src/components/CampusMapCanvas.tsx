import React, { useRef, useState, useEffect } from 'react';
import {
  Plus,
  Minus,
  Compass,
  Locate,
  LocateFixed,
  Route,
  Info,
  Navigation,
  MapPin,
  Layers,
  ArrowRightLeft,
  Sparkles,
  Maximize2,
  Minimize2,
  Crosshair,
  Radio,
  CheckCircle2,
  Sliders,
  X,
} from 'lucide-react';
import { CAMPUS_LOCATIONS, NAV_NODES, NAV_EDGES } from '../data/campusData';
import { CampusLocation, RouteResult, UserLiveLocation } from '../types/campus';
import { findNearestLocation, canvasCoordinateToGps } from '../utils/geolocation';

interface CampusMapCanvasProps {
  selectedLocation: CampusLocation | null;
  onSelectLocation: (loc: CampusLocation) => void;
  activeRoute: RouteResult | null;
  userLocation: UserLiveLocation;
  setUserLocation: React.Dispatch<React.SetStateAction<UserLiveLocation>>;
  mapLayer: 'blueprint' | 'hybrid' | 'satellite';
  setMapLayer: (layer: 'blueprint' | 'hybrid' | 'satellite') => void;
  isSimulatingWalk: boolean;
  onOpenLocationDetail: (loc: CampusLocation) => void;
  categoryFilter: string;
  setCategoryFilter: (cat: string) => void;
  onSetOrigin?: (loc: CampusLocation) => void;
  onSetDestination?: (loc: CampusLocation) => void;
  onOpenRoutingPanel?: () => void;
  onOpenLiveLocationModal?: () => void;
}

export const CampusMapCanvas: React.FC<CampusMapCanvasProps> = ({
  selectedLocation,
  onSelectLocation,
  activeRoute,
  userLocation,
  setUserLocation,
  mapLayer,
  setMapLayer,
  isSimulatingWalk,
  onOpenLocationDetail,
  categoryFilter,
  setCategoryFilter,
  onSetOrigin,
  onSetDestination,
  onOpenRoutingPanel,
  onOpenLiveLocationModal,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  // Transform State: pan (x, y), zoom level, and tilt angle
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [showPathsOverlay, setShowPathsOverlay] = useState(true);
  const [showLabels, setShowLabels] = useState(true);
  const [is3DTilt, setIs3DTilt] = useState(false);
  const [hoveredBuilding, setHoveredBuilding] = useState<CampusLocation | null>(null);

  // Pin Live Location state
  const [isPinModeActive, setIsPinModeActive] = useState<boolean>(false);
  const [pinFeedback, setPinFeedback] = useState<string | null>(null);

  // Nearest building to user pin
  const nearestBuildingInfo = findNearestLocation(userLocation.x, userLocation.y);

  // Center on selected location or active route
  useEffect(() => {
    if (selectedLocation) {
      const targetX = (500 - selectedLocation.coordinates.x) * zoom;
      const targetY = (400 - selectedLocation.coordinates.y) * zoom;
      setPan({ x: targetX, y: targetY });
    }
  }, [selectedLocation, zoom]);

  // Center on user location when simulating walk
  useEffect(() => {
    if (isSimulatingWalk) {
      const targetX = (500 - userLocation.x) * zoom;
      const targetY = (400 - userLocation.y) * zoom;
      setPan({ x: targetX, y: targetY });
    }
  }, [userLocation.x, userLocation.y, isSimulatingWalk, zoom]);

  // Mouse pan handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  };

  const handleMouseUp = () => setIsDragging(false);

  // Wheel zoom
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomDelta = e.deltaY > 0 ? 0.9 : 1.1;
    setZoom((prev) => Math.min(Math.max(prev * zoomDelta, 0.55), 4));
  };

  // Touch pinch-to-zoom and drag
  const touchStartRef = useRef<{ dist: number; pan: { x: number; y: number } } | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setIsDragging(true);
      setDragStart({ x: e.touches[0].clientX - pan.x, y: e.touches[0].clientY - pan.y });
    } else if (e.touches.length === 2) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      touchStartRef.current = { dist, pan: { ...pan } };
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 1 && isDragging) {
      setPan({
        x: e.touches[0].clientX - dragStart.x,
        y: e.touches[0].clientY - dragStart.y,
      });
    } else if (e.touches.length === 2 && touchStartRef.current) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      const factor = dist / touchStartRef.current.dist;
      setZoom((prev) => Math.min(Math.max(prev * (factor > 1 ? 1.03 : 0.97), 0.55), 4));
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
    touchStartRef.current = null;
  };

  const resetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
    setIs3DTilt(false);
  };

  // Click on SVG map to drop custom live pin
  const handleSvgClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!isPinModeActive || !svgRef.current) return;
    const svg = svgRef.current;
    const pt = svg.createSVGPoint();
    pt.x = e.clientX;
    pt.y = e.clientY;
    const svgP = pt.matrixTransform(svg.getScreenCTM()?.inverse());
    const newX = Math.round(Math.max(50, Math.min(950, svgP.x)));
    const newY = Math.round(Math.max(50, Math.min(750, svgP.y)));
    const gps = canvasCoordinateToGps(newX, newY);

    setUserLocation((prev) => ({
      ...prev,
      x: newX,
      y: newY,
      lat: gps.lat,
      lng: gps.lng,
      isSimulated: true,
      accuracy: 2,
    }));

    const nearest = findNearestLocation(newX, newY);
    const placeName = nearest ? nearest.location.name : 'Campus Ground';
    setPinFeedback(`📍 Live Location Pinned near ${placeName}`);
    setIsPinModeActive(false);

    setTimeout(() => {
      setPinFeedback(null);
    }, 4000);
  };

  // Center camera on user pin
  const centerOnUserPin = () => {
    setPan({
      x: (500 - userLocation.x) * zoom,
      y: (400 - userLocation.y) * zoom,
    });
  };

  // Filter locations by category
  const filteredLocations = CAMPUS_LOCATIONS.filter((loc) => {
    if (categoryFilter === 'all') return true;
    if (categoryFilter === 'academic') return loc.category === 'academic' || loc.category === 'admin';
    if (categoryFilter === 'lab') return loc.category === 'lab';
    if (categoryFilter === 'hostel') return loc.category === 'hostel';
    if (categoryFilter === 'sports') return loc.category === 'sports';
    if (categoryFilter === 'amenity') return loc.category === 'amenity' || loc.category === 'parking';
    return true;
  });

  return (
    <div
      ref={containerRef}
      id="campus-map-container"
      className={`relative w-full h-full bg-[#eef3f7] dark:bg-slate-950 overflow-hidden select-none ${
        isPinModeActive ? 'cursor-crosshair' : 'cursor-grab active:cursor-grabbing'
      }`}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onWheel={handleWheel}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Active Pin Mode Guidance Banner */}
      {isPinModeActive && (
        <div className="absolute top-14 left-4 right-4 sm:left-1/2 sm:-translate-x-1/2 sm:w-auto z-40 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm shadow-2xl flex items-center justify-between gap-3 animate-in slide-in-from-top-3 border border-amber-300">
          <div className="flex items-center gap-2">
            <Crosshair className="w-4 h-4 animate-spin text-slate-950" />
            <span>Tap anywhere on the campus blueprint to drop your live location pin</span>
          </div>
          <button
            onClick={() => setIsPinModeActive(false)}
            className="px-2.5 py-1 bg-slate-950/80 hover:bg-slate-950 text-amber-300 rounded-lg text-xs font-semibold flex items-center gap-1 transition"
          >
            <X className="w-3.5 h-3.5" />
            <span>Cancel</span>
          </button>
        </div>
      )}

      {/* Pin Feedback Notification Toast */}
      {pinFeedback && (
        <div className="absolute top-14 left-1/2 -translate-x-1/2 z-40 bg-slate-900/95 border border-emerald-500/50 text-emerald-300 px-4 py-2 rounded-2xl text-xs font-bold shadow-2xl flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{pinFeedback}</span>
        </div>
      )}

      {/* Category Filter Chips on top */}
      <div className="absolute top-3 left-3 right-16 z-20 flex items-center gap-1.5 overflow-x-auto pb-1.5 scrollbar-none pointer-events-auto">
        {[
          { id: 'all', label: 'All 45 Locations' },
          { id: 'academic', label: 'Academic & Admin' },
          { id: 'lab', label: 'Laboratories (6-20)' },
          { id: 'hostel', label: 'Hostels & Mess' },
          { id: 'sports', label: 'Sports & Grounds' },
          { id: 'amenity', label: 'Parking & Food' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setCategoryFilter(tab.id)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap shadow-md backdrop-blur-md transition ${
              categoryFilter === tab.id
                ? 'bg-blue-700 text-white shadow-blue-700/20'
                : 'bg-white/90 dark:bg-slate-900/85 text-slate-700 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800 border border-slate-300 dark:border-slate-700/60'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Floating Live Location HUD Badge in Top-Left */}
      <div className="absolute top-14 left-3 z-20 hidden sm:flex items-center gap-2 p-1.5 pl-3 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-2xl shadow-xl pointer-events-auto">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <div className="text-left leading-tight">
            <div className="text-[11px] font-bold text-slate-200 flex items-center gap-1">
              <span>Pinned:</span>
              <span className="text-emerald-400 truncate max-w-[140px]">
                {nearestBuildingInfo ? nearestBuildingInfo.location.name : 'Main Entrance'}
              </span>
            </div>
            <div className="text-[9px] text-slate-400">
              {userLocation.isSimulated ? 'Custom Pin' : 'Live GPS (±3m)'}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 border-l border-slate-800 pl-1.5 ml-1">
          <button
            id="btn-hud-pin-toggle"
            onClick={() => setIsPinModeActive(!isPinModeActive)}
            className={`p-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition ${
              isPinModeActive
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white'
            }`}
            title="Drop Pin on Map"
          >
            <Crosshair className="w-3.5 h-3.5" />
            <span className="text-[10px]">Pin</span>
          </button>

          {onOpenLiveLocationModal && (
            <button
              id="btn-hud-gps-settings"
              onClick={onOpenLiveLocationModal}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 hover:text-emerald-300 transition"
              title="Allow Access & Live Location Settings"
            >
              <LocateFixed className="w-3.5 h-3.5" />
            </button>
          )}

          <button
            id="btn-hud-center-pin"
            onClick={centerOnUserPin}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-blue-400 hover:text-blue-300 transition"
            title="Center Camera on My Pin"
          >
            <Compass className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Floating Map Controls on Right */}
      <div className="absolute right-3 top-3 z-20 flex flex-col gap-2 pointer-events-auto">
        <button
          onClick={() => setZoom((z) => Math.min(z * 1.25, 4))}
          className="w-9 h-9 rounded-xl bg-white/95 dark:bg-slate-900/90 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-300 dark:border-slate-700 flex items-center justify-center shadow-lg transition"
          title="Zoom In"
        >
          <Plus className="w-4 h-4" />
        </button>
        <button
          onClick={() => setZoom((z) => Math.max(z * 0.8, 0.55))}
          className="w-9 h-9 rounded-xl bg-white/95 dark:bg-slate-900/90 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-300 dark:border-slate-700 flex items-center justify-center shadow-lg transition"
          title="Zoom Out"
        >
          <Minus className="w-4 h-4" />
        </button>
        <button
          onClick={resetView}
          className="w-9 h-9 rounded-xl bg-white/95 dark:bg-slate-900/90 hover:bg-slate-100 dark:hover:bg-slate-800 text-blue-600 dark:text-blue-400 border border-slate-300 dark:border-slate-700 flex items-center justify-center shadow-lg transition"
          title="Reset Campus View"
        >
          <Compass className="w-4 h-4" />
        </button>
        <button
          onClick={() => setIsPinModeActive(!isPinModeActive)}
          className={`w-9 h-9 rounded-xl border flex items-center justify-center shadow-lg transition ${
            isPinModeActive
              ? 'bg-amber-500 text-slate-950 border-amber-400 animate-pulse'
              : 'bg-white/95 dark:bg-slate-900/90 hover:bg-slate-100 dark:hover:bg-slate-800 text-emerald-600 dark:text-emerald-400 border-slate-300 dark:border-slate-700'
          }`}
          title="Pin Live Location on Map"
        >
          <Crosshair className="w-4 h-4" />
        </button>
        <button
          onClick={() => setIs3DTilt(!is3DTilt)}
          className={`w-9 h-9 rounded-xl border flex items-center justify-center shadow-lg transition ${
            is3DTilt
              ? 'bg-blue-600 text-white border-blue-500 font-bold text-xs'
              : 'bg-white/95 dark:bg-slate-900/90 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700 text-xs'
          }`}
          title="Toggle 3D Perspective"
        >
          3D
        </button>
        <button
          onClick={() => setShowPathsOverlay(!showPathsOverlay)}
          className={`w-9 h-9 rounded-xl border flex items-center justify-center shadow-lg transition ${
            showPathsOverlay
              ? 'bg-sky-600 text-white border-sky-400'
              : 'bg-white/95 dark:bg-slate-900/90 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
          }`}
          title="Toggle Walkable Paths Network"
        >
          <Route className="w-4 h-4" />
        </button>
        <button
          onClick={onOpenLiveLocationModal || centerOnUserPin}
          className="w-9 h-9 rounded-xl bg-white/95 dark:bg-slate-900/90 hover:bg-slate-100 dark:hover:bg-slate-800 text-emerald-600 dark:text-emerald-400 border border-slate-300 dark:border-slate-700 flex items-center justify-center shadow-lg transition"
          title="Allow GPS Access & Location Settings"
        >
          <LocateFixed className="w-4 h-4" />
        </button>
      </div>

      {/* SVG Canvas Stage - Matching Karpagam College of Engineering Blueprint */}
      <div
        className="w-full h-full flex items-center justify-center transition-transform duration-75"
        style={{
          transform: is3DTilt
            ? `perspective(900px) rotateX(25deg) translate(${pan.x}px, ${pan.y}px) scale(${zoom})`
            : `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transformOrigin: 'center center',
        }}
      >
        <svg
          ref={svgRef}
          onClick={handleSvgClick}
          viewBox="0 0 1000 800"
          className="w-[1000px] h-[800px] max-w-none shadow-2xl rounded-lg overflow-hidden border border-slate-300 dark:border-slate-800"
          style={{
            background: '#ffffff',
          }}
        >
          <defs>
            {/* Blueprint Hatching Patterns */}
            <pattern id="hostel-hatch" width="8" height="8" patternUnits="userSpaceOnUse">
              <rect width="8" height="8" fill="#5890c0" />
              <line x1="0" y1="0" x2="8" y2="8" stroke="#ffffff" strokeWidth="1.2" opacity="0.7" />
              <line x1="8" y1="0" x2="0" y2="8" stroke="#ffffff" strokeWidth="1.2" opacity="0.7" />
            </pattern>

            <pattern id="auditorium-hatch" width="10" height="10" patternUnits="userSpaceOnUse">
              <rect width="10" height="10" fill="#d9e5f0" />
              <line x1="0" y1="0" x2="10" y2="10" stroke="#7097be" strokeWidth="1.2" />
            </pattern>

            <pattern id="eblock-hatch" width="12" height="12" patternUnits="userSpaceOnUse">
              <rect width="12" height="12" fill="#d6e4f0" />
              <line x1="0" y1="6" x2="12" y2="6" stroke="#486581" strokeWidth="1.2" />
              <line x1="6" y1="0" x2="6" y2="12" stroke="#486581" strokeWidth="1.2" />
            </pattern>

            <pattern id="lawn-plus" width="16" height="16" patternUnits="userSpaceOnUse">
              <rect width="16" height="16" fill="#2eb85c" />
              <path d="M 8 5 L 8 11 M 5 8 L 11 8" stroke="#1f8b42" strokeWidth="1" opacity="0.6" />
            </pattern>

            <pattern id="lawn-dark" width="20" height="20" patternUnits="userSpaceOnUse">
              <rect width="20" height="20" fill="#1ea84c" />
              <circle cx="10" cy="10" r="1.5" fill="#147a35" opacity="0.5" />
            </pattern>

            {/* Glowing route filters */}
            <filter id="glow-cyan" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>

            <linearGradient id="route-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#2563eb" />
              <stop offset="50%" stopColor="#06b6d4" />
              <stop offset="100%" stopColor="#10b981" />
            </linearGradient>
          </defs>

          {/* 1. Official Blueprint Header Banner */}
          <g id="kce-header-banner">
            {/* White Header Canvas */}
            <rect x="0" y="0" width="1000" height="95" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1" />
            
            {/* KCE Geometric Color Icon */}
            <g transform="translate(35, 20)">
              <rect x="0" y="10" width="12" height="12" rx="2" fill="#0284c7" />
              <rect x="15" y="10" width="12" height="12" rx="2" fill="#0284c7" />
              <rect x="30" y="10" width="12" height="12" rx="2" fill="#0284c7" />
              <rect x="15" y="25" width="12" height="12" rx="2" fill="#eab308" />
              <rect x="30" y="25" width="12" height="12" rx="2" fill="#eab308" />
              <rect x="30" y="40" width="12" height="12" rx="2" fill="#eab308" />
            </g>

            {/* College Name in Official Typography */}
            <text x="500" y="32" textAnchor="middle" fill="#0f4c81" fontSize="20" fontWeight="900" letterSpacing="1.5">
              KARPAGAM COLLEGE OF ENGINEERING
            </text>

            <text x="500" y="49" textAnchor="middle" fill="#334155" fontSize="9.5" fontWeight="600">
              Accredited by NAAC with 'A+' grade | Accredited by NBA (CSE, CIVIL, ECE, EEE, IT & MECH)
            </text>

            <text x="500" y="63" textAnchor="middle" fill="#475569" fontSize="9" fontWeight="500">
              Autonomous | Affiliated to Anna University
            </text>

            <text x="500" y="77" textAnchor="middle" fill="#64748b" fontSize="8.5" fontStyle="italic">
              (An ISO 9001:2015 and ISO 14001:2015 Certified institution)
            </text>

            {/* Official Compass Rose on Top-Right */}
            <g id="official-compass" transform="translate(890, 48)">
              <circle cx="0" cy="0" r="22" fill="none" stroke="#475569" strokeWidth="1.5" />
              <circle cx="0" cy="0" r="18" fill="none" stroke="#94a3b8" strokeWidth="0.8" strokeDasharray="2,2" />
              <polygon points="0,-16 4,0 0,-3 -4,0" fill="#1e293b" />
              <polygon points="0,16 4,0 0,3 -4,0" fill="#94a3b8" />
              <text x="0" y="-7" textAnchor="middle" fill="#0f172a" fontSize="9" fontWeight="900">
                N
              </text>
            </g>
          </g>

          {/* 2. Main Campus Ground & Greenery Zones */}
          {/* Main campus background */}
          <rect x="0" y="95" width="1000" height="705" fill="#f8fafc" />

          {/* West Road: Myleripalayam Road */}
          <g id="myleripalayam-road">
            {/* Road ribbon */}
            <path
              d="M 215 95 L 260 410 L 265 790"
              fill="none"
              stroke="#e2e8f0"
              strokeWidth="24"
            />
            <path
              d="M 215 95 L 260 410 L 265 790"
              fill="none"
              stroke="#475569"
              strokeWidth="1.5"
            />
            {/* Arrow and Text */}
            <text
              x="235"
              y="220"
              transform="rotate(78, 235, 220)"
              fill="#334155"
              fontSize="10"
              fontWeight="900"
              letterSpacing="2"
            >
              ← MYLERIPALAYAM
            </text>
          </g>

          {/* West Green Lawn / Football Ground (34) */}
          <g id="zone-34-football" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 34)!)} className="cursor-pointer">
            <rect x="40" y="240" width="180" height="180" fill="url(#lawn-plus)" stroke="#1f8b42" strokeWidth="2" rx="4" />
            {/* Pitch markings */}
            <rect x="65" y="265" width="130" height="130" fill="none" stroke="#ffffff" strokeWidth="1.5" opacity="0.8" />
            <circle cx="130" cy="330" r="24" fill="none" stroke="#ffffff" strokeWidth="1.5" opacity="0.8" />
            <rect x="115" y="320" width="30" height="20" fill="#ffffff" rx="3" />
            <text x="130" y="334" textAnchor="middle" fill="#0f172a" fontSize="11" fontWeight="900">
              34
            </text>
          </g>

          {/* Bus Parking Bay (35) - Bottom Left */}
          <g id="zone-35-bus" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 35)!)} className="cursor-pointer">
            <rect x="55" y="475" width="160" height="70" fill="#0284c7" stroke="#0369a1" strokeWidth="2" rx="3" />
            <rect x="120" y="498" width="30" height="20" fill="#ffffff" rx="3" />
            <text x="135" y="512" textAnchor="middle" fill="#0f172a" fontSize="11" fontWeight="900">
              35
            </text>
          </g>

          {/* Two Wheeler & Four Wheeler Parking (37) */}
          <g id="zone-37-parking" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 37)!)} className="cursor-pointer">
            <rect x="280" y="460" width="130" height="50" fill="#0284c7" stroke="#0369a1" strokeWidth="2" rx="3" />
            <rect x="330" y="475" width="30" height="20" fill="#ffffff" rx="3" />
            <text x="345" y="489" textAnchor="middle" fill="#0f172a" fontSize="11" fontWeight="900">
              37
            </text>
          </g>

          {/* Botanical Gardens & Lawns (44) - South Center */}
          <g id="zone-44-lawn" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 44)!)} className="cursor-pointer">
            <rect x="440" y="540" width="185" height="110" fill="url(#lawn-plus)" stroke="#1f8b42" strokeWidth="2" rx="4" />
            <rect x="517" y="585" width="30" height="20" fill="#ffffff" rx="3" />
            <text x="532" y="599" textAnchor="middle" fill="#0f172a" fontSize="11" fontWeight="900">
              44
            </text>
          </g>

          {/* South East Green Field & Boys Hostel (41) */}
          <g id="zone-41-hostel" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 41)!)} className="cursor-pointer">
            <rect x="775" y="420" width="205" height="85" fill="url(#lawn-plus)" stroke="#1f8b42" strokeWidth="2" rx="4" />
            {/* Two brown horizontal blocks */}
            <rect x="875" y="430" width="90" height="26" fill="#883832" stroke="#5a2420" strokeWidth="1" rx="2" />
            <rect x="875" y="468" width="90" height="26" fill="#883832" stroke="#5a2420" strokeWidth="1" rx="2" />
            <rect x="910" y="436" width="20" height="14" fill="#ffffff" rx="2" />
            <text x="920" y="447" textAnchor="middle" fill="#0f172a" fontSize="9" fontWeight="900">
              41
            </text>
            <rect x="910" y="474" width="20" height="14" fill="#ffffff" rx="2" />
            <text x="920" y="485" textAnchor="middle" fill="#0f172a" fontSize="9" fontWeight="900">
              41
            </text>
          </g>

          {/* Campus Green Lawns (North & Central Compound) */}
          {/* Girls Hostel compound green lawn */}
          <rect x="210" y="125" width="295" height="135" fill="url(#lawn-plus)" stroke="#1f8b42" strokeWidth="1.5" rx="3" />
          
          {/* East side green compound */}
          <rect x="520" y="150" width="460" height="185" fill="url(#lawn-plus)" stroke="#1f8b42" strokeWidth="1.5" rx="3" />

          {/* Central Lab lawn */}
          <rect x="375" y="325" width="80" height="95" fill="url(#lawn-plus)" stroke="#1f8b42" strokeWidth="1.5" rx="3" />

          {/* Sports Courts green zone */}
          <rect x="530" y="325" width="105" height="110" fill="url(#lawn-plus)" stroke="#1f8b42" strokeWidth="1.5" rx="3" />

          {/* 3. Main Internal Roads & Walkways */}
          <g id="campus-paved-roads" stroke="#e2e8f0" strokeLinecap="round" strokeLinejoin="round">
            {/* Entrance Road from Myleripalayam to Fountain */}
            <path d="M 260 410 L 310 445 L 430 435 L 515 435 L 760 435" fill="none" stroke="#ffffff" strokeWidth="16" />
            <path d="M 260 410 L 310 445 L 430 435 L 515 435 L 760 435" fill="none" stroke="#64748b" strokeWidth="1.5" />

            {/* North-South Central Spine Road */}
            <path d="M 515 435 L 515 200 L 760 200 L 760 435" fill="none" stroke="#ffffff" strokeWidth="14" />
            <path d="M 515 435 L 515 200 L 760 200 L 760 435" fill="none" stroke="#64748b" strokeWidth="1.5" />

            {/* West Road to Girls Hostel */}
            <path d="M 310 445 L 360 260 L 435 260" fill="none" stroke="#ffffff" strokeWidth="12" />
            <path d="M 310 445 L 360 260 L 435 260" fill="none" stroke="#64748b" strokeWidth="1.5" />
          </g>

          {/* 4. Entrance Roundabout & Gate 5 */}
          {/* Roundabout Green Island */}
          <circle cx="370" cy="425" r="18" fill="#1ea84c" stroke="#1f8b42" strokeWidth="1.5" />

          {/* Main Gate Security Room (5) */}
          <g id="bldg-5-maingate" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 5)!)} className="cursor-pointer">
            <rect x="305" y="388" width="30" height="28" fill="#883832" stroke="#5a2420" strokeWidth="1.5" rx="2" />
            <rect x="312" y="394" width="16" height="14" fill="#ffffff" rx="2" />
            <text x="320" y="405" textAnchor="middle" fill="#0f172a" fontSize="9" fontWeight="900">
              5
            </text>
          </g>

          {/* Central Entrance Plaza: Library (1) & Fountain (45) */}
          <g id="bldg-1-45-entrance" className="cursor-pointer">
            {/* Green Island for 1 & 45 */}
            <path d="M 405 425 C 405 415, 515 415, 515 425 C 515 445, 405 445, 405 425 Z" fill="#1ea84c" stroke="#1f8b42" strokeWidth="1.5" />
            
            {/* 1: Central Library */}
            <rect
              x="460"
              y="420"
              width="20"
              height="14"
              fill="#0284c7"
              stroke="#0369a1"
              strokeWidth="1"
              rx="2"
              onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 1)!)}
            />
            <text x="470" y="431" textAnchor="middle" fill="#ffffff" fontSize="9" fontWeight="900">
              1
            </text>

            {/* 45: Central Plaza / Landmark */}
            <rect
              x="482"
              y="420"
              width="20"
              height="14"
              fill="#ffffff"
              stroke="#64748b"
              strokeWidth="1"
              rx="2"
              onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 45)!)}
            />
            <text x="492" y="431" textAnchor="middle" fill="#0f172a" fontSize="9" fontWeight="900">
              45
            </text>
          </g>

          {/* 2: M Block / Gymnasium (South Brown Square) */}
          <g id="bldg-2-gym" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 2)!)} className="cursor-pointer">
            <rect x="525" y="420" width="40" height="48" fill="#883832" stroke="#5a2420" strokeWidth="1.5" rx="2" />
            <rect x="536" y="435" width="18" height="16" fill="#ffffff" rx="2" />
            <text x="545" y="447" textAnchor="middle" fill="#0f172a" fontSize="10" fontWeight="900">
              2
            </text>
          </g>

          {/* 3, 4, 23: Sports Courts (South East) */}
          {/* 23: Basketball Court */}
          <g id="bldg-23-court" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 23)!)} className="cursor-pointer">
            <rect x="535" y="385" width="22" height="22" fill="#ffffff" stroke="#64748b" strokeWidth="1" rx="2" />
            <text x="546" y="400" textAnchor="middle" fill="#0f172a" fontSize="9" fontWeight="900">
              23
            </text>
          </g>

          {/* 4: Tennis Court */}
          <g id="bldg-4-tennis" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 4)!)} className="cursor-pointer">
            <rect x="590" y="365" width="36" height="42" fill="#dcfce7" stroke="#1f8b42" strokeWidth="1" rx="2" />
            <rect x="600" y="378" width="16" height="14" fill="#ffffff" rx="2" />
            <text x="608" y="389" textAnchor="middle" fill="#0f172a" fontSize="9" fontWeight="900">
              4
            </text>
          </g>

          {/* 3: Handball Court */}
          <g id="bldg-3-handball" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 3)!)} className="cursor-pointer">
            <rect x="590" y="412" width="36" height="28" fill="#dcfce7" stroke="#1f8b42" strokeWidth="1" rx="2" />
            <rect x="600" y="419" width="16" height="14" fill="#ffffff" rx="2" />
            <text x="608" y="430" textAnchor="middle" fill="#0f172a" fontSize="9" fontWeight="900">
              3
            </text>
          </g>

          {/* 24: Open Amphitheatre (Green Arc) */}
          <g id="bldg-24-amphi" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 24)!)} className="cursor-pointer">
            <path d="M 545 352 C 545 342, 570 342, 570 352 Z" fill="#1ea84c" stroke="#1f8b42" strokeWidth="1" />
            <text x="557" y="350" textAnchor="middle" fill="#ffffff" fontSize="7.5" fontWeight="900">
              24
            </text>
          </g>

          {/* 25: C Block & 26: LBS Hall */}
          <g id="bldg-25-cblock" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 25)!)} className="cursor-pointer">
            <rect x="555" y="328" width="70" height="22" fill="#0284c7" stroke="#0369a1" strokeWidth="1.5" rx="2" />
            <rect x="580" y="332" width="18" height="14" fill="#ffffff" rx="2" />
            <text x="589" y="343" textAnchor="middle" fill="#0f172a" fontSize="9" fontWeight="900">
              25
            </text>
          </g>

          {/* 26: LBS Hall / Computer Labs (adjacent right) */}
          <g id="bldg-26-lbshall" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 26)!)} className="cursor-pointer">
            <rect x="605" y="352" width="22" height="15" fill="#ffffff" stroke="#64748b" strokeWidth="1" rx="2" />
            <text x="616" y="363" textAnchor="middle" fill="#0f172a" fontSize="8" fontWeight="900">
              26
            </text>
          </g>

          {/* 29: Auditorium (Auditorium with Hatch Pattern) */}
          <g id="bldg-29-auditorium" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 29)!)} className="cursor-pointer">
            <path
              d="M 555 285 L 670 275 L 682 322 L 555 315 Z"
              fill="url(#auditorium-hatch)"
              stroke="#486581"
              strokeWidth="1.5"
            />
            <rect x="605" y="288" width="22" height="15" fill="#ffffff" rx="2" />
            <text x="616" y="300" textAnchor="middle" fill="#0f172a" fontSize="9" fontWeight="900">
              29
            </text>
          </g>

          {/* 36: Stores (small block near auditorium) */}
          <g id="bldg-36-stores" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 36)!)} className="cursor-pointer">
            <rect x="532" y="288" width="15" height="15" fill="#0284c7" stroke="#0369a1" strokeWidth="1" rx="2" />
            <text x="539" y="299" textAnchor="middle" fill="#ffffff" fontSize="7.5" fontWeight="900">
              36
            </text>
          </g>

          {/* 30: E Block (Patterned Long Block) */}
          <g id="bldg-30-eblock" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 30)!)} className="cursor-pointer">
            <rect x="525" y="195" width="195" height="35" fill="url(#eblock-hatch)" stroke="#334e68" strokeWidth="1.5" rx="2" />
            <rect x="655" y="205" width="22" height="16" fill="#ffffff" rx="2" />
            <text x="666" y="217" textAnchor="middle" fill="#0f172a" fontSize="10" fontWeight="900">
              30
            </text>
          </g>

          {/* 38: STP (Top Center) */}
          <g id="bldg-38-stp" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 38)!)} className="cursor-pointer">
            <rect x="600" y="170" width="28" height="18" fill="#ffffff" stroke="#64748b" strokeWidth="1" rx="2" />
            <text x="614" y="183" textAnchor="middle" fill="#0f172a" fontSize="9" fontWeight="900">
              38
            </text>
          </g>

          {/* 42 & 43: Staff Quarters Blocks */}
          <g id="bldg-42-43-staff" className="cursor-pointer">
            <rect x="728" y="235" width="28" height="28" fill="#883832" stroke="#5a2420" strokeWidth="1" rx="2" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 42)!)} />
            <text x="742" y="252" textAnchor="middle" fill="#ffffff" fontSize="8" fontWeight="bold">
              42
            </text>
            <rect x="760" y="235" width="28" height="28" fill="#883832" stroke="#5a2420" strokeWidth="1" rx="2" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 43)!)} />
            <text x="774" y="252" textAnchor="middle" fill="#ffffff" fontSize="8" fontWeight="bold">
              43
            </text>
          </g>

          {/* 31: Boys Hostel - H Block (Top Right Cross-Hatch) */}
          <g id="bldg-31-hostel-h" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 31)!)} className="cursor-pointer">
            <path
              d="M 835 195 L 910 195 L 910 270 L 855 270 L 855 240 L 835 240 Z"
              fill="url(#hostel-hatch)"
              stroke="#204060"
              strokeWidth="1.5"
            />
            <rect x="860" y="242" width="20" height="15" fill="#ffffff" rx="2" />
            <text x="870" y="253" textAnchor="middle" fill="#0f172a" fontSize="9" fontWeight="900">
              31
            </text>
            {/* Mess block beside 31 */}
            <rect x="855" y="285" width="65" height="32" fill="url(#hostel-hatch)" stroke="#204060" strokeWidth="1" rx="2" />
            <text x="887" y="305" textAnchor="middle" fill="#ffffff" fontSize="8" fontWeight="bold">
              MESS
            </text>
            {/* Court 23 & 4 beside mess */}
            <rect x="775" y="280" width="26" height="32" fill="#883832" stroke="#5a2420" strokeWidth="1" rx="2" />
            <text x="788" y="300" textAnchor="middle" fill="#ffffff" fontSize="8" fontWeight="bold">
              23
            </text>
            <rect x="805" y="280" width="26" height="32" fill="#883832" stroke="#5a2420" strokeWidth="1" rx="2" />
            <text x="818" y="300" textAnchor="middle" fill="#ffffff" fontSize="8" fontWeight="bold">
              4
            </text>
          </g>

          {/* 32: Boys Hostel - Blocks A to G & I */}
          <g id="bldg-32-boys-hostel" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 32)!)} className="cursor-pointer">
            {/* G Block */}
            <rect x="445" y="180" width="45" height="22" fill="#e2e8f0" stroke="#64748b" strokeWidth="1" rx="2" />
            <text x="467" y="195" textAnchor="middle" fill="#0f172a" fontSize="8" fontWeight="bold">G</text>
            {/* E Block */}
            <rect x="445" y="210" width="45" height="22" fill="#883832" stroke="#5a2420" strokeWidth="1" rx="2" />
            <text x="467" y="225" textAnchor="middle" fill="#ffffff" fontSize="8" fontWeight="bold">E</text>
            <text x="453" y="222" textAnchor="middle" fill="#ffffff" fontSize="7" fontWeight="bold">32</text>
            {/* D Block */}
            <rect x="445" y="240" width="45" height="18" fill="#ffffff" stroke="#64748b" strokeWidth="1" rx="2" />
            <text x="467" y="253" textAnchor="middle" fill="#0f172a" fontSize="8" fontWeight="bold">D</text>
            {/* C, B, A Blocks */}
            <rect x="455" y="262" width="30" height="14" fill="#ffffff" stroke="#64748b" strokeWidth="1" rx="1" />
            <text x="470" y="273" textAnchor="middle" fill="#0f172a" fontSize="7.5" fontWeight="bold">C</text>
            <rect x="455" y="278" width="30" height="14" fill="#883832" stroke="#5a2420" strokeWidth="1" rx="1" />
            <text x="470" y="289" textAnchor="middle" fill="#ffffff" fontSize="7.5" fontWeight="bold">B</text>
            <rect x="455" y="294" width="30" height="14" fill="#ffffff" stroke="#64748b" strokeWidth="1" rx="1" />
            <text x="470" y="305" textAnchor="middle" fill="#0f172a" fontSize="7.5" fontWeight="bold">A</text>
          </g>

          {/* 33: Girls Hostel - Blocks A to G & I (Top Left) */}
          <g id="bldg-33-girls-hostel" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 33)!)} className="cursor-pointer">
            {/* G & D Blocks */}
            <rect x="238" y="175" width="40" height="24" fill="#ffffff" stroke="#64748b" strokeWidth="1" rx="2" />
            <text x="258" y="191" textAnchor="middle" fill="#0f172a" fontSize="8" fontWeight="bold">G</text>
            <rect x="290" y="175" width="45" height="24" fill="#ffffff" stroke="#64748b" strokeWidth="1" rx="2" />
            <text x="312" y="191" textAnchor="middle" fill="#0f172a" fontSize="8" fontWeight="bold">D</text>
            
            {/* 33 Badge */}
            <rect x="280" y="200" width="18" height="12" fill="#ffffff" rx="2" />
            <text x="289" y="209" textAnchor="middle" fill="#0f172a" fontSize="7" fontWeight="bold">33</text>

            {/* B, C, E Blocks */}
            <rect x="255" y="215" width="22" height="24" fill="#883832" stroke="#5a2420" strokeWidth="1" rx="2" />
            <text x="266" y="230" textAnchor="middle" fill="#ffffff" fontSize="7" fontWeight="bold">B</text>
            <rect x="280" y="215" width="22" height="24" fill="#883832" stroke="#5a2420" strokeWidth="1" rx="2" />
            <text x="291" y="230" textAnchor="middle" fill="#ffffff" fontSize="7" fontWeight="bold">C</text>
            <rect x="320" y="200" width="25" height="24" fill="#883832" stroke="#5a2420" strokeWidth="1" rx="2" />
            <text x="332" y="215" textAnchor="middle" fill="#ffffff" fontSize="7" fontWeight="bold">E</text>

            {/* A Block */}
            <rect x="285" y="250" width="60" height="22" fill="#ffffff" stroke="#64748b" strokeWidth="1" rx="2" />
            <text x="315" y="265" textAnchor="middle" fill="#0f172a" fontSize="8" fontWeight="bold">A</text>

            {/* 40: RO Plant */}
            <rect x="260" y="240" width="14" height="10" fill="#ffffff" stroke="#64748b" strokeWidth="0.8" rx="1" />
            <text x="267" y="248" textAnchor="middle" fill="#0f172a" fontSize="5.5" fontWeight="bold">40</text>

            {/* I Block & Mess A, Mess B */}
            <rect x="370" y="175" width="34" height="26" fill="#ffffff" stroke="#64748b" strokeWidth="1" rx="2" />
            <text x="387" y="191" textAnchor="middle" fill="#0f172a" fontSize="8" fontWeight="bold">I</text>
            <rect x="368" y="208" width="36" height="20" fill="#0284c7" stroke="#0369a1" strokeWidth="1" rx="2" />
            <text x="386" y="221" textAnchor="middle" fill="#ffffff" fontSize="6.5" fontWeight="bold">MESS B</text>
            <rect x="368" y="245" width="36" height="25" fill="#0284c7" stroke="#0369a1" strokeWidth="1" rx="2" />
            <text x="386" y="260" textAnchor="middle" fill="#ffffff" fontSize="6.5" fontWeight="bold">MESS A</text>
          </g>

          {/* 27: B Block / MG Hall & 28: Power House & 39: Food Court */}
          <g id="bldg-27-28-39" className="cursor-pointer">
            {/* 27: B Block */}
            <rect x="372" y="312" width="22" height="18" fill="#ffffff" stroke="#64748b" strokeWidth="1" rx="2" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 27)!)} />
            <text x="383" y="325" textAnchor="middle" fill="#0f172a" fontSize="8" fontWeight="bold">27</text>

            {/* 28: Power House */}
            <rect x="424" y="312" width="22" height="18" fill="#ffffff" stroke="#64748b" strokeWidth="1" rx="2" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 28)!)} />
            <text x="435" y="325" textAnchor="middle" fill="#0f172a" fontSize="8" fontWeight="bold">28</text>

            {/* 39: Food Court */}
            <rect x="466" y="312" width="32" height="18" fill="#0284c7" stroke="#0369a1" strokeWidth="1" rx="2" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 39)!)} />
            <text x="482" y="325" textAnchor="middle" fill="#ffffff" fontSize="8" fontWeight="bold">39</text>
          </g>

          {/* Placement Hall & Labs Row (12, 13, 14, 15) */}
          <g id="labs-row-12-15" className="cursor-pointer">
            <rect x="372" y="335" width="22" height="15" fill="#f8fafc" stroke="#64748b" strokeWidth="1" rx="1" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 12)!)} />
            <text x="383" y="346" textAnchor="middle" fill="#0f172a" fontSize="7.5" fontWeight="bold">12</text>

            <rect x="396" y="335" width="22" height="15" fill="#f8fafc" stroke="#64748b" strokeWidth="1" rx="1" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 13)!)} />
            <text x="407" y="346" textAnchor="middle" fill="#0f172a" fontSize="7.5" fontWeight="bold">13</text>

            <rect x="420" y="335" width="22" height="15" fill="#f8fafc" stroke="#64748b" strokeWidth="1" rx="1" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 14)!)} />
            <text x="431" y="346" textAnchor="middle" fill="#0f172a" fontSize="7.5" fontWeight="bold">14</text>

            <rect x="444" y="335" width="22" height="15" fill="#f8fafc" stroke="#64748b" strokeWidth="1" rx="1" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 15)!)} />
            <text x="455" y="346" textAnchor="middle" fill="#0f172a" fontSize="7.5" fontWeight="bold">15</text>
          </g>

          {/* Central Lab 20 */}
          <g id="bldg-20-lab" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 20)!)} className="cursor-pointer">
            <rect x="432" y="358" width="34" height="22" fill="#0284c7" stroke="#0369a1" strokeWidth="1" rx="2" />
            <text x="449" y="372" textAnchor="middle" fill="#ffffff" fontSize="9" fontWeight="900">20</text>
          </g>

          {/* Labs Row 16, 17, 18, 19 */}
          <g id="labs-row-16-19" className="cursor-pointer">
            <rect x="480" y="354" width="18" height="12" fill="#fef08a" stroke="#ca8a04" strokeWidth="0.8" rx="1" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 16)!)} />
            <text x="489" y="363" textAnchor="middle" fill="#713f12" fontSize="6.5" fontWeight="bold">16</text>

            <rect x="500" y="354" width="18" height="12" fill="#fef08a" stroke="#ca8a04" strokeWidth="0.8" rx="1" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 17)!)} />
            <text x="509" y="363" textAnchor="middle" fill="#713f12" fontSize="6.5" fontWeight="bold">17</text>

            <rect x="480" y="368" width="18" height="12" fill="#fef08a" stroke="#ca8a04" strokeWidth="0.8" rx="1" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 18)!)} />
            <text x="489" y="377" textAnchor="middle" fill="#713f12" fontSize="6.5" fontWeight="bold">18</text>

            <rect x="500" y="368" width="18" height="12" fill="#fef08a" stroke="#ca8a04" strokeWidth="0.8" rx="1" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 19)!)} />
            <text x="509" y="377" textAnchor="middle" fill="#713f12" fontSize="6.5" fontWeight="bold">19</text>

            {/* 21 & 22 */}
            <rect x="480" y="336" width="16" height="10" fill="#ffffff" stroke="#64748b" strokeWidth="0.8" rx="1" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 21)!)} />
            <text x="488" y="344" textAnchor="middle" fill="#0f172a" fontSize="5.5" fontWeight="bold">21</text>
            <rect x="498" y="336" width="16" height="10" fill="#ffffff" stroke="#64748b" strokeWidth="0.8" rx="1" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 22)!)} />
            <text x="506" y="344" textAnchor="middle" fill="#0f172a" fontSize="5.5" fontWeight="bold">22</text>
          </g>

          {/* Labs Row 6, 7, 8, 9, 10, 11 */}
          <g id="labs-row-6-11" className="cursor-pointer">
            <rect x="480" y="386" width="18" height="12" fill="#fef08a" stroke="#ca8a04" strokeWidth="0.8" rx="1" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 6)!)} />
            <text x="489" y="395" textAnchor="middle" fill="#713f12" fontSize="6.5" fontWeight="bold">6</text>

            <rect x="500" y="386" width="18" height="12" fill="#fef08a" stroke="#ca8a04" strokeWidth="0.8" rx="1" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 7)!)} />
            <text x="509" y="395" textAnchor="middle" fill="#713f12" fontSize="6.5" fontWeight="bold">7</text>

            <rect x="480" y="400" width="18" height="12" fill="#fef08a" stroke="#ca8a04" strokeWidth="0.8" rx="1" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 8)!)} />
            <text x="489" y="409" textAnchor="middle" fill="#713f12" fontSize="6.5" fontWeight="bold">8</text>

            <rect x="500" y="400" width="18" height="12" fill="#fef08a" stroke="#ca8a04" strokeWidth="0.8" rx="1" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 9)!)} />
            <text x="509" y="409" textAnchor="middle" fill="#713f12" fontSize="6.5" fontWeight="bold">9</text>

            <rect x="480" y="414" width="18" height="12" fill="#fef08a" stroke="#ca8a04" strokeWidth="0.8" rx="1" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 10)!)} />
            <text x="489" y="423" textAnchor="middle" fill="#713f12" fontSize="6" fontWeight="bold">10</text>

            <rect x="500" y="414" width="18" height="12" fill="#fef08a" stroke="#ca8a04" strokeWidth="0.8" rx="1" onClick={() => onSelectLocation(CAMPUS_LOCATIONS.find((l) => l.id === 11)!)} />
            <text x="509" y="423" textAnchor="middle" fill="#713f12" fontSize="6" fontWeight="bold">11</text>
          </g>

          {/* 5. Walkable Navigation Network Overlay */}
          {showPathsOverlay && (
            <g id="walkable-paths-graph" opacity="0.65">
              {NAV_EDGES.map((edge, idx) => {
                const nodeFrom = NAV_NODES[edge.from];
                const nodeTo = NAV_NODES[edge.to];
                if (!nodeFrom || !nodeTo) return null;
                return (
                  <line
                    key={`edge-${idx}`}
                    x1={nodeFrom.x}
                    y1={nodeFrom.y}
                    x2={nodeTo.x}
                    y2={nodeTo.y}
                    stroke="#2563eb"
                    strokeWidth="2.5"
                    strokeDasharray="4,3"
                    strokeLinecap="round"
                  />
                );
              })}
              {Object.values(NAV_NODES).map((node) => (
                <circle
                  key={node.id}
                  cx={node.x}
                  cy={node.y}
                  r="3.5"
                  fill="#2563eb"
                  stroke="#ffffff"
                  strokeWidth="1.2"
                />
              ))}
            </g>
          )}

          {/* 6. Active Shortest Route Polyline */}
          {activeRoute && activeRoute.pathCoordinates.length > 1 && (
            <g id="active-navigation-route">
              {/* Route Glow Underlay */}
              <polyline
                points={activeRoute.pathCoordinates.map((p) => `${p.x},${p.y}`).join(' ')}
                fill="none"
                stroke="#38bdf8"
                strokeWidth="10"
                strokeLinecap="round"
                strokeLinejoin="round"
                opacity="0.6"
                filter="url(#glow-cyan)"
              />
              {/* Main Glowing Route Path */}
              <polyline
                points={activeRoute.pathCoordinates.map((p) => `${p.x},${p.y}`).join(' ')}
                fill="none"
                stroke="url(#route-gradient)"
                strokeWidth="5"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeDasharray="10,5"
                className="animate-[dash_1.2s_linear_infinite]"
              />

              {/* Start Marker (Green Pin) */}
              <g transform={`translate(${activeRoute.pathCoordinates[0].x}, ${activeRoute.pathCoordinates[0].y})`}>
                <circle cx="0" cy="0" r="8" fill="#10b981" stroke="#ffffff" strokeWidth="2.5" />
                <circle cx="0" cy="0" r="3" fill="#ffffff" />
              </g>

              {/* Destination Marker (Red Pin with pulse) */}
              <g
                transform={`translate(${activeRoute.pathCoordinates[activeRoute.pathCoordinates.length - 1].x}, ${
                  activeRoute.pathCoordinates[activeRoute.pathCoordinates.length - 1].y
                })`}
              >
                <circle cx="0" cy="0" r="14" fill="#ef4444" opacity="0.3" className="animate-ping" />
                <circle cx="0" cy="0" r="9" fill="#ef4444" stroke="#ffffff" strokeWidth="2.5" />
                <circle cx="0" cy="0" r="4" fill="#ffffff" />
              </g>
            </g>
          )}

          {/* 7. Live User Location Marker with Directional Cone & Label */}
          <g id="user-live-gps-marker" transform={`translate(${userLocation.x}, ${userLocation.y})`}>
            {/* Outer Radar Waves */}
            <circle cx="0" cy="0" r="28" fill="#10b981" opacity="0.18" className="animate-ping" />
            <circle cx="0" cy="0" r="18" fill="#0284c7" opacity="0.25" />
            <circle cx="0" cy="0" r="11" fill="#0284c7" opacity="0.4" />
            
            {/* Directional Heading Cone */}
            <g transform={`rotate(${userLocation.heading})`}>
              <path d="M 0 -24 L 7 -9 L -7 -9 Z" fill="#0284c7" opacity="0.9" />
            </g>

            {/* Core Pin Dot */}
            <circle cx="0" cy="0" r="7.5" fill="#0284c7" stroke="#ffffff" strokeWidth="2.5" />
            <circle cx="0" cy="0" r="3" fill="#ffffff" />

            {/* Pinned Marker Floating Badge */}
            <g transform="translate(0, -28)">
              <rect
                x="-36"
                y="-13"
                width="72"
                height="16"
                rx="8"
                fill="#0f172a"
                stroke="#38bdf8"
                strokeWidth="1.2"
                opacity="0.95"
              />
              <text
                x="0"
                y="-2"
                textAnchor="middle"
                fill="#38bdf8"
                fontSize="8"
                fontWeight="bold"
                letterSpacing="0.3"
              >
                {userLocation.isSimulated ? '📍 PINNED' : '📍 YOU'}
              </text>
            </g>
          </g>

          {/* Selected Building Highlight Aura */}
          {selectedLocation && (
            <g id="selected-building-indicator" transform={`translate(${selectedLocation.coordinates.x}, ${selectedLocation.coordinates.y})`}>
              <circle cx="0" cy="0" r="24" fill="none" stroke="#f59e0b" strokeWidth="3" strokeDasharray="5,3" className="animate-spin" />
              <circle cx="0" cy="0" r="14" fill="#f59e0b" stroke="#ffffff" strokeWidth="2" />
              <text x="0" y="4" textAnchor="middle" fill="#0f172a" fontSize="10" fontWeight="900">
                {selectedLocation.number}
              </text>
            </g>
          )}
        </svg>
      </div>

      {/* Quick Selected Location Floating Banner at Bottom */}
      {selectedLocation && !activeRoute && (
        <div className="absolute bottom-4 left-4 right-4 sm:left-auto sm:right-4 sm:w-[420px] z-30 bg-slate-900/95 border border-slate-700/80 rounded-2xl p-3.5 shadow-2xl backdrop-blur-md flex flex-col gap-2.5 animate-in fade-in slide-in-from-bottom-4 duration-200">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 overflow-hidden">
              <span
                className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-white text-sm shrink-0 shadow-md"
                style={{ backgroundColor: selectedLocation.color || '#2563eb' }}
              >
                #{selectedLocation.number}
              </span>
              <div className="overflow-hidden">
                <h3 className="font-bold text-sm text-slate-100 truncate">
                  {selectedLocation.name}
                </h3>
                <p className="text-xs text-slate-400 truncate">
                  {selectedLocation.shortDesc}
                </p>
              </div>
            </div>
            <button
              onClick={() => onOpenLocationDetail(selectedLocation)}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl border border-slate-700 shadow transition flex items-center gap-1 shrink-0"
            >
              <Info className="w-3.5 h-3.5" />
              <span>Info</span>
            </button>
          </div>

          {/* Quick Routing Action Buttons */}
          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
            <button
              id="btn-quick-set-start"
              onClick={() => onSetOrigin && onSetOrigin(selectedLocation)}
              className="py-1.5 px-2 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition"
            >
              <MapPin className="w-3.5 h-3.5 text-emerald-400" />
              Set as Start Point
            </button>
            <button
              id="btn-quick-set-dest"
              onClick={() => onSetDestination && onSetDestination(selectedLocation)}
              className="py-1.5 px-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 shadow transition"
            >
              <Navigation className="w-3.5 h-3.5" />
              Route to Here
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
