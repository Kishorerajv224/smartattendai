import React, { useState, useEffect } from 'react';
import {
  MapPin,
  Navigation,
  LocateFixed,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
  Compass,
  Crosshair,
  Radio,
  Sliders,
  ShieldCheck,
  ChevronRight,
  X,
  Footprints,
  Info,
} from 'lucide-react';
import { CampusLocation, UserLiveLocation } from '../types/campus';
import { CAMPUS_LOCATIONS } from '../data/campusData';
import {
  GeolocationStatus,
  gpsToCanvasCoordinate,
  canvasCoordinateToGps,
  findNearestLocation,
} from '../utils/geolocation';

interface LiveLocationManagerProps {
  userLocation: UserLiveLocation;
  setUserLocation: React.Dispatch<React.SetStateAction<UserLiveLocation>>;
  isOpen: boolean;
  onClose: () => void;
  onCenterOnUser?: () => void;
  onEnablePinMode?: () => void;
  isPinModeActive?: boolean;
  onOpenMapCanvas?: () => void;
  onSetAsRouteOrigin?: (location: CampusLocation) => void;
  onSpeak?: (text: string) => void;
}

export const LiveLocationManager: React.FC<LiveLocationManagerProps> = ({
  userLocation,
  setUserLocation,
  isOpen,
  onClose,
  onCenterOnUser,
  onEnablePinMode,
  isPinModeActive = false,
  onOpenMapCanvas,
  onSetAsRouteOrigin,
  onSpeak,
}) => {
  const [geoStatus, setGeoStatus] = useState<GeolocationStatus>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isWatching, setIsWatching] = useState<boolean>(false);
  const [watchId, setWatchId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Nearest building to current user location
  const nearestInfo = findNearestLocation(userLocation.x, userLocation.y);

  // Request high-accuracy live GPS
  const handleRequestLiveGps = () => {
    if (!('geolocation' in navigator)) {
      setGeoStatus('unavailable');
      setErrorMessage('Geolocation is not supported by your current browser.');
      return;
    }

    setGeoStatus('requesting');
    setErrorMessage(null);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const accuracy = Math.round(pos.coords.accuracy || 3);
        const heading = pos.coords.heading || userLocation.heading || 0;

        const { x, y, isInsideCampus } = gpsToCanvasCoordinate(lat, lng);

        setUserLocation((prev) => ({
          ...prev,
          x: isInsideCampus ? x : prev.x, // If outside campus, preserve campus position or update lat/lng
          y: isInsideCampus ? y : prev.y,
          lat,
          lng,
          heading,
          accuracy,
          isSimulated: false,
        }));

        setGeoStatus(isInsideCampus ? 'granted' : 'off_campus');
        onCenterOnUser?.();

        if (onSpeak) {
          onSpeak(
            isInsideCampus
              ? `Live location pinned with accuracy of ${accuracy} meters.`
              : `Live GPS acquired. Real location is outside campus bounds, pinned to campus reference.`
          );
        }

        // Start continuous watcher
        if (!isWatching) {
          startGpsWatch();
        }
      },
      (err) => {
        if (err.code === err.PERMISSION_DENIED) {
          setGeoStatus('denied');
          setErrorMessage('Location permission was denied. You can still tap anywhere on the map to pin your location.');
        } else if (err.code === err.TIMEOUT) {
          setGeoStatus('timeout');
          setErrorMessage('GPS request timed out. Please check device location services.');
        } else {
          setGeoStatus('unavailable');
          setErrorMessage(err.message || 'Unable to retrieve your live GPS coordinates.');
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 12000,
        maximumAge: 0,
      }
    );
  };

  // Continuous GPS watch
  const startGpsWatch = () => {
    if (!('geolocation' in navigator)) return;

    try {
      const id = navigator.geolocation.watchPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          const accuracy = Math.round(pos.coords.accuracy || 3);
          const heading = pos.coords.heading || 0;

          const { x, y, isInsideCampus } = gpsToCanvasCoordinate(lat, lng);

          setUserLocation((prev) => ({
            ...prev,
            x: isInsideCampus ? x : prev.x,
            y: isInsideCampus ? y : prev.y,
            lat,
            lng,
            heading: heading || prev.heading,
            accuracy,
            isSimulated: false,
          }));

          setGeoStatus(isInsideCampus ? 'granted' : 'off_campus');
        },
        () => {},
        {
          enableHighAccuracy: true,
          timeout: 15000,
          maximumAge: 2000,
        }
      );
      setWatchId(id);
      setIsWatching(true);
    } catch {}
  };

  // Stop watching GPS
  const stopGpsWatch = () => {
    if (watchId !== null && 'geolocation' in navigator) {
      navigator.geolocation.clearWatch(watchId);
      setWatchId(null);
      setIsWatching(false);
    }
  };

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (watchId !== null && 'geolocation' in navigator) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, [watchId]);

  // Quick pin preset locations
  const handlePinBuilding = (loc: CampusLocation) => {
    setUserLocation((prev) => ({
      ...prev,
      x: loc.coordinates.x,
      y: loc.coordinates.y,
      lat: loc.coordinates.lat || prev.lat,
      lng: loc.coordinates.lng || prev.lng,
      isSimulated: true,
      accuracy: 2,
    }));
    onCenterOnUser?.();
    if (onSpeak) {
      onSpeak(`Live location pinned to ${loc.name}.`);
    }
  };

  if (!isOpen) return null;

  const filteredPlaces = CAMPUS_LOCATIONS.filter((loc) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      loc.name.toLowerCase().includes(q) ||
      loc.number.toString() === q ||
      loc.shortDesc.toLowerCase().includes(q) ||
      loc.category.toLowerCase().includes(q)
    );
  }).slice(0, 6);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 shadow-lg shadow-emerald-500/20 shrink-0">
              <LocateFixed className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                Live Location & Pinning
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  GPS Engine
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Grant device GPS access or drop custom pin on campus
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-4 sm:p-5 space-y-4 overflow-y-auto">
          {/* Current Live Pin Status Card */}
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                Current Pinned Position
              </span>
              <span
                className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1 border ${
                  userLocation.isSimulated
                    ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                    : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                }`}
              >
                <CheckCircle2 className="w-3 h-3" />
                {userLocation.isSimulated ? 'Custom Pin' : 'Live Device GPS'}
              </span>
            </div>

            {/* Nearest Landmark display */}
            <div className="flex items-start gap-3 p-3 bg-slate-900/90 rounded-xl border border-slate-800">
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center font-bold text-white text-xs shrink-0 shadow"
                style={{ backgroundColor: nearestInfo?.location.color || '#0284c7' }}
              >
                #{nearestInfo?.location.number || '5'}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-slate-100 truncate">
                    {nearestInfo ? nearestInfo.location.name : 'Main Entrance Gate'}
                  </h4>
                  {nearestInfo && (
                    <span className="text-[11px] font-medium text-emerald-400 ml-2 shrink-0">
                      ~{nearestInfo.distanceMeters}m away
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 truncate">
                  {nearestInfo ? nearestInfo.location.shortDesc : 'Campus main entry & security check'}
                </p>
              </div>
            </div>

            {/* Detailed GPS Coordinate Pill Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-500 block">Latitude</span>
                <span className="font-mono font-semibold text-slate-200">
                  {userLocation.lat ? userLocation.lat.toFixed(5) : '10.90250'}
                </span>
              </div>
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-500 block">Longitude</span>
                <span className="font-mono font-semibold text-slate-200">
                  {userLocation.lng ? userLocation.lng.toFixed(5) : '76.99300'}
                </span>
              </div>
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-500 block">Accuracy</span>
                <span className="font-mono font-semibold text-emerald-400">
                  ±{userLocation.accuracy || 3}m
                </span>
              </div>
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-500 block">Heading</span>
                <span className="font-mono font-semibold text-blue-400">
                  {Math.round(userLocation.heading || 0)}°
                </span>
              </div>
            </div>
          </div>

          {/* Primary Action 1: Allow & Request High-Accuracy GPS */}
          <div className="space-y-2">
            <button
              id="btn-request-device-gps"
              onClick={handleRequestLiveGps}
              disabled={geoStatus === 'requesting'}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-xl shadow-emerald-950/50 flex items-center justify-center gap-2.5 transition active:scale-[0.98] disabled:opacity-50"
            >
              {geoStatus === 'requesting' ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Connecting to Device GPS Satellite...</span>
                </>
              ) : (
                <>
                  <LocateFixed className="w-5 h-5 text-emerald-200" />
                  <span>Allow Access & Pin Live GPS Location</span>
                </>
              )}
            </button>

            {/* Error / Status Feedback */}
            {errorMessage && (
              <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-800 text-xs text-rose-200 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <p className="leading-relaxed">{errorMessage}</p>
              </div>
            )}

            {geoStatus === 'off_campus' && (
              <div className="p-3 rounded-xl bg-amber-950/60 border border-amber-800 text-xs text-amber-200 flex items-start gap-2">
                <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  Real GPS coordinates acquired! Since you are currently outside Karpagam College of Engineering campus, your position is pinned for interactive demo on campus.
                </p>
              </div>
            )}
          </div>

          {/* Primary Action 2: Interactive Tap-To-Pin Mode on Map */}
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center shrink-0">
                <Crosshair className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-100">Drop Pin Anywhere on Map</h4>
                <p className="text-[11px] text-slate-400">
                  Tap any spot on the blueprint map to position yourself
                </p>
              </div>
            </div>
            <button
              onClick={() => {
                if (onEnablePinMode) {
                  onEnablePinMode();
                } else if (onOpenMapCanvas) {
                  onOpenMapCanvas();
                }
                onClose();
              }}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow ${
                isPinModeActive
                  ? 'bg-amber-500 text-slate-950'
                  : 'bg-blue-600 hover:bg-blue-500 text-white'
              }`}
            >
              <MapPin className="w-3.5 h-3.5" />
              {isPinModeActive ? 'Active' : 'Drop Pin'}
            </button>
          </div>

          {/* Preset Fast-Pin Landmarks */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5 text-amber-400" />
                Quick Pin to Campus Entry Points & Blocks
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {[
                { label: 'Main Gate (#5)', id: 5, color: '#f43f5e' },
                { label: 'Central Library (#1)', id: 1, color: '#0284c7' },
                { label: 'C-Block CSE/IT (#25)', id: 25, color: '#6366f1' },
                { label: 'Placement Hall (#12)', id: 12, color: '#f59e0b' },
                { label: 'Food Court (#39)', id: 39, color: '#10b981' },
                { label: 'Hostel Gate (#31)', id: 31, color: '#8b5cf6' },
              ].map((item) => {
                const loc = CAMPUS_LOCATIONS.find((l) => l.id === item.id);
                return (
                  <button
                    key={item.id}
                    onClick={() => loc && handlePinBuilding(loc)}
                    className="p-2.5 rounded-xl bg-slate-950/70 hover:bg-slate-800/80 border border-slate-800 hover:border-slate-700 text-left flex items-center gap-2.5 transition group"
                  >
                    <span
                      className="w-6 h-6 rounded-lg flex items-center justify-center font-bold text-white text-[10px] shrink-0"
                      style={{ backgroundColor: item.color }}
                    >
                      #{item.id}
                    </span>
                    <span className="text-xs font-semibold text-slate-300 group-hover:text-amber-400 truncate">
                      {item.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between gap-2">
          <button
            onClick={() => {
              onCenterOnUser?.();
              if (onOpenMapCanvas) {
                onOpenMapCanvas();
              }
              onClose();
            }}
            className="flex-1 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-1.5 transition"
          >
            <Compass className="w-3.5 h-3.5 text-blue-400" />
            Center Map on My Pin
          </button>

          {nearestInfo && onSetAsRouteOrigin && (
            <button
              onClick={() => {
                onSetAsRouteOrigin(nearestInfo.location);
                onClose();
              }}
              className="flex-1 py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow transition"
            >
              <Navigation className="w-3.5 h-3.5" />
              Use as Route Start
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
