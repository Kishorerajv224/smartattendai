import React, { useState, useEffect, useRef } from 'react';
import { X, Mic, MicOff, Sparkles, Navigation, Volume2 } from 'lucide-react';
import {
  isSpeechRecognitionSupported,
  createSpeechRecognizer,
  speakText,
  stopSpeaking,
} from '../utils/speech';
import { CAMPUS_LOCATIONS } from '../data/campusData';
import { CampusLocation } from '../types/campus';

interface VoiceAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToLocation: (loc: CampusLocation) => void;
}

export const VoiceAssistantModal: React.FC<VoiceAssistantModalProps> = ({
  isOpen,
  onClose,
  onNavigateToLocation,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [assistantStatus, setAssistantStatus] = useState<string>(
    'Tap the microphone or say "Take me to Food Court"'
  );
  const recognizerRef = useRef<any>(null);

  useEffect(() => {
    if (isOpen) {
      startListening();
    } else {
      stopListening();
      stopSpeaking();
    }
  }, [isOpen]);

  const startListening = () => {
    if (!isSpeechRecognitionSupported()) {
      setAssistantStatus('Speech recognition is not supported in this browser.');
      return;
    }

    setTranscript('');
    setAssistantStatus('Listening to your voice command...');
    setIsListening(true);

    const recognizer = createSpeechRecognizer(
      (text) => {
        setTranscript(text);
        processVoiceCommand(text);
      },
      () => {
        setIsListening(false);
      },
      (err) => {
        console.warn(err);
        setAssistantStatus('Could not understand voice. Please try speaking again.');
        setIsListening(false);
      }
    );

    if (recognizer) {
      recognizerRef.current = recognizer;
      recognizer.start();
    }
  };

  const stopListening = () => {
    if (recognizerRef.current) {
      try {
        recognizerRef.current.stop();
      } catch {}
      recognizerRef.current = null;
    }
    setIsListening(false);
  };

  const processVoiceCommand = (rawText: string) => {
    const text = rawText.toLowerCase();

    // Match building from voice text
    let matchedLocation: CampusLocation | undefined;

    for (const loc of CAMPUS_LOCATIONS) {
      const name = loc.name.toLowerCase();
      const numStr = loc.number.toString();
      if (text.includes(name) || text.includes(`location ${numStr}`) || text.includes(`block ${numStr}`)) {
        matchedLocation = loc;
        break;
      }
    }

    // Keyword shortcuts
    if (!matchedLocation) {
      if (text.includes('food') || text.includes('canteen') || text.includes('eat') || text.includes('cafeteria') || text.includes('snack')) {
        matchedLocation = CAMPUS_LOCATIONS.find((l) => l.id === 39 || l.name.toLowerCase().includes('food')); // Food Court
      } else if (text.includes('library') || text.includes('book') || text.includes('read')) {
        matchedLocation = CAMPUS_LOCATIONS.find((l) => l.id === 1 || l.name.toLowerCase().includes('library')); // Central Library
      } else if (text.includes('chemistry')) {
        matchedLocation = CAMPUS_LOCATIONS.find((l) => l.id === 14 || l.name.toLowerCase().includes('chemistry')); // Chem Lab
      } else if (text.includes('physics')) {
        matchedLocation = CAMPUS_LOCATIONS.find((l) => l.id === 13 || l.name.toLowerCase().includes('physics')); // Physics Lab
      } else if (text.includes('placement') || text.includes('job') || text.includes('interview')) {
        matchedLocation = CAMPUS_LOCATIONS.find((l) => l.id === 12 || l.name.toLowerCase().includes('placement')); // Placement Hall
      } else if (text.includes('gate') || text.includes('entrance') || text.includes('exit') || text.includes('security')) {
        matchedLocation = CAMPUS_LOCATIONS.find((l) => l.id === 5 || l.id === 4 || l.name.toLowerCase().includes('security') || l.name.toLowerCase().includes('gate')); // Main Gate
      } else if (text.includes('football') || text.includes('ground') || text.includes('track') || text.includes('sports')) {
        matchedLocation = CAMPUS_LOCATIONS.find((l) => l.id === 34 || l.category === 'sports'); // Football Ground
      } else if (text.includes('atm') || text.includes('bank') || text.includes('money') || text.includes('cash')) {
        matchedLocation = CAMPUS_LOCATIONS.find((l) => l.id === 36 || l.name.toLowerCase().includes('atm') || l.name.toLowerCase().includes('bank')); // Indian Bank & ATM
      } else if (text.includes('auditorium') || text.includes('audi') || text.includes('hall')) {
        matchedLocation = CAMPUS_LOCATIONS.find((l) => l.id === 29 || l.name.toLowerCase().includes('auditorium')); // Auditorium
      } else if (text.includes('admin') || text.includes('principal') || text.includes('b block') || text.includes('office')) {
        matchedLocation = CAMPUS_LOCATIONS.find((l) => l.id === 27); // B Block / Admin
      } else if (text.includes('c block') || text.includes('computer science') || text.includes('cse') || text.includes('it')) {
        matchedLocation = CAMPUS_LOCATIONS.find((l) => l.id === 25); // C Block
      }
    }

    if (matchedLocation) {
      const reply = `Routing you to ${matchedLocation.name}, Location #${matchedLocation.number}. Starting campus navigation now.`;
      setAssistantStatus(reply);
      speakText(reply, () => {
        onNavigateToLocation(matchedLocation!);
        onClose();
      });
    } else {
      const reply = `I heard "${rawText}". I could not find a matching campus building. Try saying "Take me to Food Court" or "Find Chemistry Lab".`;
      setAssistantStatus(reply);
      speakText(reply);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-3xl p-6 shadow-2xl text-center space-y-6 animate-in zoom-in-95 duration-200 relative"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="space-y-1">
          <div className="flex items-center justify-center gap-1.5 text-amber-400 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-4 h-4" />
            <span>KCE Voice Assistant</span>
          </div>
          <h2 className="text-xl font-bold text-slate-100">
            Hands-Free Navigation
          </h2>
        </div>

        {/* Pulsing Mic Visualizer */}
        <div className="relative w-28 h-28 mx-auto flex items-center justify-center">
          {isListening && (
            <>
              <div className="absolute inset-0 rounded-full bg-amber-500/20 animate-ping" />
              <div className="absolute inset-2 rounded-full bg-amber-500/30 animate-pulse" />
            </>
          )}
          <button
            onClick={isListening ? stopListening : startListening}
            className={`relative z-10 w-20 h-20 rounded-full flex items-center justify-center text-white shadow-2xl transition-transform active:scale-95 ${
              isListening
                ? 'bg-amber-500 text-slate-950 shadow-amber-500/40 ring-4 ring-amber-400/40'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
            }`}
          >
            {isListening ? <Mic className="w-8 h-8 animate-pulse" /> : <MicOff className="w-8 h-8" />}
          </button>
        </div>

        {/* Live Status & Transcript */}
        <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-1 min-h-[80px] flex flex-col justify-center">
          {transcript && (
            <p className="text-xs text-amber-400 font-mono">
              "{transcript}"
            </p>
          )}
          <p className="text-xs text-slate-300 font-medium leading-relaxed">
            {assistantStatus}
          </p>
        </div>

        {/* Sample Voice Queries */}
        <div className="space-y-2 text-left">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block text-center">
            Try saying:
          </span>
          <div className="grid grid-cols-2 gap-2 text-xs">
            {[
              'Take me to Food Court',
              'Go to Central Library',
              'Where is Chemistry Lab?',
              'Find nearest ATM',
            ].map((query, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setTranscript(query);
                  processVoiceCommand(query);
                }}
                className="p-2 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-300 text-left border border-slate-700/60 transition truncate"
              >
                "{query}"
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
