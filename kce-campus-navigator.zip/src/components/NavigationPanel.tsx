import React, { useState, useEffect } from 'react';
import {
  Navigation,
  CornerUpRight,
  CornerUpLeft,
  ArrowUp,
  Flag,
  Volume2,
  VolumeX,
  X,
  Play,
  Pause,
  RotateCcw,
  List,
  CheckCircle2,
  QrCode,
  Layers,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { RouteResult, RouteStep, CampusLocation, UserLiveLocation } from '../types/campus';
import { speakText, stopSpeaking, isAudioMuted, setAudioMuted } from '../utils/speech';

interface NavigationPanelProps {
  route: RouteResult | null;
  destination: CampusLocation | null;
  onEndNavigation: () => void;
  userLocation: UserLiveLocation;
  setUserLocation: React.Dispatch<React.SetStateAction<UserLiveLocation>>;
  isSimulatingWalk: boolean;
  setIsSimulatingWalk: React.Dispatch<React.SetStateAction<boolean>>;
  onOpenFloorPlan: (loc: CampusLocation) => void;
  onOpenQRScanner: () => void;
}

export const NavigationPanel: React.FC<NavigationPanelProps> = ({
  route,
  destination,
  onEndNavigation,
  userLocation,
  setUserLocation,
  isSimulatingWalk,
  setIsSimulatingWalk,
  onOpenFloorPlan,
  onOpenQRScanner,
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [showStepList, setShowStepList] = useState(false);
  const [isMuted, setIsMutedState] = useState(isAudioMuted());
  const [hasArrived, setHasArrived] = useState(false);

  // Reset state when new route begins
  useEffect(() => {
    if (route) {
      setCurrentStepIndex(0);
      setHasArrived(false);
      // Speak initial instruction
      if (route.steps.length > 0) {
        speakText(`Starting navigation to ${destination?.name || 'destination'}. ${route.steps[0].spokenText}`);
      }
    }
  }, [route, destination]);

  // Voice toggle
  const toggleAudio = () => {
    const nextMuted = !isMuted;
    setIsMutedState(nextMuted);
    setAudioMuted(nextMuted);
  };

  // Walk simulation effect
  useEffect(() => {
    if (!isSimulatingWalk || !route || hasArrived) return;

    const pathCoords = route.pathCoordinates;
    let pointIdx = 0;
    const interval = setInterval(() => {
      if (pointIdx < pathCoords.length) {
        const nextCoord = pathCoords[pointIdx];
        
        // Calculate heading to next point
        let heading = 0;
        if (pointIdx < pathCoords.length - 1) {
          const p1 = pathCoords[pointIdx];
          const p2 = pathCoords[pointIdx + 1];
          heading = (Math.atan2(p2.x - p1.x, -(p2.y - p1.y)) * 180) / Math.PI;
          if (heading < 0) heading += 360;
        }

        setUserLocation((prev) => ({
          ...prev,
          x: nextCoord.x,
          y: nextCoord.y,
          heading,
          isSimulated: true,
        }));

        // Check if matching step coordinate
        const matchedStepIdx = route.steps.findIndex(
          (s, idx) => idx > 0 && Math.hypot(s.coordinate.x - nextCoord.x, s.coordinate.y - nextCoord.y) < 15
        );
        if (matchedStepIdx !== -1 && matchedStepIdx !== currentStepIndex) {
          setCurrentStepIndex(matchedStepIdx);
          speakText(route.steps[matchedStepIdx].spokenText);
        }

        pointIdx++;
      } else {
        // Arrived at destination
        setIsSimulatingWalk(false);
        setHasArrived(true);
        try {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 },
          });
        } catch {
          // ignore
        }
        speakText(`You have reached your destination: ${destination?.name || 'your stop'}.`);
        clearInterval(interval);
      }
    }, 1200);

    return () => clearInterval(interval);
  }, [isSimulatingWalk, route, hasArrived, destination, currentStepIndex, setUserLocation, setIsSimulatingWalk]);

  if (!route) return null;

  const currentStep: RouteStep = route.steps[currentStepIndex] || route.steps[0];
  const nextStep: RouteStep | undefined = route.steps[currentStepIndex + 1];

  const getStepIcon = (iconType: RouteStep['icon']) => {
    switch (iconType) {
      case 'turn_left':
      case 'slight_left':
        return <CornerUpLeft className="w-6 h-6 text-amber-400" />;
      case 'turn_right':
      case 'slight_right':
        return <CornerUpRight className="w-6 h-6 text-amber-400" />;
      case 'arrive':
        return <Flag className="w-6 h-6 text-emerald-400" />;
      case 'start':
      case 'straight':
      default:
        return <ArrowUp className="w-6 h-6 text-sky-400" />;
    }
  };

  return (
    <>
      {/* Active Navigation Card (Pinned at Bottom) */}
      <div className="fixed bottom-3 left-3 right-3 sm:left-auto sm:right-6 sm:w-[420px] z-40 bg-slate-900/95 border border-slate-700 rounded-2xl sm:rounded-3xl shadow-2xl backdrop-blur-md overflow-hidden animate-in slide-in-from-bottom-5 duration-200">
        {/* Top Progress bar */}
        <div className="h-1 bg-slate-800 w-full">
          <div
            className="h-full bg-gradient-to-r from-sky-400 via-amber-400 to-emerald-400 transition-all duration-300"
            style={{
              width: `${Math.min(100, ((currentStepIndex + 1) / route.steps.length) * 100)}%`,
            }}
          />
        </div>

        <div className="p-3.5 sm:p-4">
          {/* Top Row: Turn instruction with big icon */}
          <div className="flex items-start gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0 shadow-inner">
              {getStepIcon(currentStep.icon)}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">
                  Step {currentStepIndex + 1} of {route.steps.length}
                </span>
                <span className="text-xs font-semibold text-slate-300">
                  {currentStep.distanceMeters > 0 ? `In ${currentStep.distanceMeters}m` : 'Arriving'}
                </span>
              </div>
              <h3 className="font-bold text-sm sm:text-base text-slate-100 mt-0.5 leading-snug">
                {currentStep.instruction}
              </h3>
              {nextStep && (
                <p className="text-[11px] text-slate-400 mt-1 truncate">
                  Then: {nextStep.instruction}
                </p>
              )}
            </div>
          </div>

          {/* Stats Bar: Remaining distance & ETA */}
          <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-300">
            <div className="flex items-center gap-3">
              <div>
                <span className="text-slate-400 text-[10px] block font-medium">Distance</span>
                <span className="font-bold text-sm text-slate-100">
                  {route.totalDistanceMeters} m
                </span>
              </div>
              <div className="h-6 w-px bg-slate-800" />
              <div>
                <span className="text-slate-400 text-[10px] block font-medium">Walking ETA</span>
                <span className="font-bold text-sm text-amber-400">
                  ~{route.estimatedTimeMinutes} min
                </span>
              </div>
            </div>

            {/* Simulation & Audio Controls */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={toggleAudio}
                className={`p-2 rounded-xl border transition ${
                  isMuted
                    ? 'bg-slate-800 text-slate-500 border-slate-700'
                    : 'bg-slate-800 text-amber-400 border-amber-500/30'
                }`}
                title={isMuted ? 'Unmute voice' : 'Mute voice'}
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>

              <button
                onClick={() => setIsSimulatingWalk(!isSimulatingWalk)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
                  isSimulatingWalk
                    ? 'bg-amber-500 text-slate-950 shadow-md animate-pulse'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                }`}
                title="Simulate step-by-step walking"
              >
                {isSimulatingWalk ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                <span>{isSimulatingWalk ? 'Pause' : 'Simulate'}</span>
              </button>

              <button
                onClick={() => setShowStepList(!showStepList)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
                title="View All Route Steps"
              >
                <List className="w-4 h-4" />
              </button>

              <button
                onClick={onEndNavigation}
                className="p-2 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 transition"
                title="End Route"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Step-by-Step List Modal */}
      {showStepList && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl p-5 max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-base text-slate-100 flex items-center gap-2">
                <Navigation className="w-4 h-4 text-amber-400" />
                Turn-by-Turn Route Steps
              </h3>
              <button
                onClick={() => setShowStepList(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="overflow-y-auto py-3 space-y-2 flex-1 divide-y divide-slate-800/60">
              {route.steps.map((step, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    setCurrentStepIndex(idx);
                    speakText(step.spokenText);
                  }}
                  className={`pt-2.5 px-3 py-2 rounded-xl flex items-start gap-3 cursor-pointer transition ${
                    idx === currentStepIndex
                      ? 'bg-amber-500/15 border border-amber-500/40 text-slate-100'
                      : 'hover:bg-slate-800 text-slate-300'
                  }`}
                >
                  <div className="mt-0.5 shrink-0">{getStepIcon(step.icon)}</div>
                  <div className="flex-1">
                    <p className="text-xs font-semibold leading-relaxed">
                      {step.instruction}
                    </p>
                    {step.distanceMeters > 0 && (
                      <span className="text-[11px] text-slate-400 block mt-0.5">
                        Distance: {step.distanceMeters} meters
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => setShowStepList(false)}
              className="mt-3 w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition"
            >
              Back to Navigation
            </button>
          </div>
        </div>
      )}

      {/* Arrival Celebration Card */}
      {hasArrived && destination && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in zoom-in-95 duration-200">
          <div className="w-full max-w-sm bg-slate-900 border border-emerald-500/50 rounded-3xl p-6 shadow-2xl text-center space-y-4">
            <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center mx-auto text-emerald-400 shadow-lg">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                You have arrived
              </span>
              <h2 className="text-xl font-black text-slate-100 mt-1">
                {destination.name}
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Location #{destination.number} • Karpagam College of Engineering
              </p>
            </div>

            <div className="space-y-2 pt-2">
              <button
                onClick={() => {
                  setHasArrived(false);
                  onOpenQRScanner();
                }}
                className="w-full py-2.5 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg flex items-center justify-center gap-2 transition"
              >
                <QrCode className="w-4 h-4" />
                <span>Scan Entrance QR Code</span>
              </button>

              <button
                onClick={() => {
                  setHasArrived(false);
                  onOpenFloorPlan(destination);
                }}
                className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs rounded-xl border border-slate-700 flex items-center justify-center gap-2 transition"
              >
                <Layers className="w-4 h-4 text-sky-400" />
                <span>View Indoor Floor Directory</span>
              </button>

              <button
                onClick={() => {
                  setHasArrived(false);
                  onEndNavigation();
                }}
                className="w-full py-2 text-slate-400 hover:text-white text-xs font-medium transition"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
