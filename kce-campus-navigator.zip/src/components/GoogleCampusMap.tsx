import React, { useState, useEffect, useRef } from 'react';
import {
  APIProvider,
  Map,
  AdvancedMarker,
  Pin,
  InfoWindow,
  useMap,
} from '@vis.gl/react-google-maps';
import {
  Navigation,
  Compass,
  Layers,
  Sparkles,
  Info,
  Maximize2,
  Volume2,
  VolumeX,
  Footprints,
  Eye,
  KeyRound,
  ExternalLink,
} from 'lucide-react';
import { CAMPUS_LOCATIONS, KCE_BASE_COORDINATES } from '../data/campusData';
import { CampusLocation, RouteResult, UserLiveLocation } from '../types/campus';

interface GoogleCampusMapProps {
  selectedLocation: CampusLocation | null;
  onSelectLocation: (loc: CampusLocation) => void;
  activeRoute: RouteResult | null;
  userLocation: UserLiveLocation;
  setUserLocation: React.Dispatch<React.SetStateAction<UserLiveLocation>>;
  onStartNavigation: (loc: CampusLocation) => void;
  onOpenFloorPlan: (loc: CampusLocation) => void;
  onOpenLocationDetail: (loc: CampusLocation) => void;
  categoryFilter: string;
  setCategoryFilter: (cat: string) => void;
  onSwitchToVectorMap?: () => void;
}

// Polyline & Camera controller sub-component inside Google Map context
const MapRouteOverlay: React.FC<{
  route: RouteResult | null;
  selectedLocation: CampusLocation | null;
  userLocation: UserLiveLocation;
}> = ({ route, selectedLocation, userLocation }) => {
  const map = useMap();
  const polylineRef = useRef<google.maps.Polyline | null>(null);

  // Pan to selected location or fit route bounds
  useEffect(() => {
    if (!map) return;

    if (route && route.nodes.length > 0) {
      const bounds = new google.maps.LatLngBounds();
      route.nodes.forEach((node) => {
        if (node.lat && node.lng) {
          bounds.extend({ lat: node.lat, lng: node.lng });
        }
      });
      if (userLocation.lat && userLocation.lng) {
        bounds.extend({ lat: userLocation.lat, lng: userLocation.lng });
      }
      map.fitBounds(bounds, 70);
    } else if (selectedLocation?.coordinates.lat && selectedLocation?.coordinates.lng) {
      map.panTo({
        lat: selectedLocation.coordinates.lat,
        lng: selectedLocation.coordinates.lng,
      });
      map.setZoom(19);
    }
  }, [map, route, selectedLocation, userLocation.lat, userLocation.lng]);

  // Render glowing route polyline
  useEffect(() => {
    if (!map) return;

    if (polylineRef.current) {
      polylineRef.current.setMap(null);
      polylineRef.current = null;
    }

    if (route && route.nodes.length > 1) {
      const coordinates = route.nodes
        .filter((n) => n.lat && n.lng)
        .map((n) => ({ lat: n.lat!, lng: n.lng! }));

      if (coordinates.length > 1) {
        polylineRef.current = new google.maps.Polyline({
          path: coordinates,
          geodesic: true,
          strokeColor: '#38bdf8',
          strokeOpacity: 0.9,
          strokeWeight: 6,
          map: map,
        });
      }
    }

    return () => {
      if (polylineRef.current) {
        polylineRef.current.setMap(null);
        polylineRef.current = null;
      }
    };
  }, [map, route]);

  return null;
};

export const GoogleCampusMap: React.FC<GoogleCampusMapProps> = ({
  selectedLocation,
  onSelectLocation,
  activeRoute,
  userLocation,
  setUserLocation,
  onStartNavigation,
  onOpenFloorPlan,
  onOpenLocationDetail,
  categoryFilter,
  setCategoryFilter,
  onSwitchToVectorMap,
}) => {
  const [activeInfoWindowLoc, setActiveInfoWindowLoc] = useState<CampusLocation | null>(null);
  const [mapTypeId, setMapTypeId] = useState<'hybrid' | 'satellite' | 'roadmap'>('hybrid');
  const [tilt, setTilt] = useState<number>(45);
  const [heading, setHeading] = useState<number>(0);

  // Read API Key from Vite env or fallback
  const apiKey = (import.meta as any).env?.VITE_GOOGLE_MAPS_API_KEY || '';

  // Filter locations
  const filteredLocations = CAMPUS_LOCATIONS.filter((loc) => {
    if (categoryFilter === 'all') return true;
    return loc.category === categoryFilter;
  });

  const categories = [
    { id: 'all', label: 'All Places' },
    { id: 'academic', label: 'Academic Blocks' },
    { id: 'lab', label: 'Labs & Workshops' },
    { id: 'hostel', label: 'Hostels & Mess' },
    { id: 'sports', label: 'Sports & Gym' },
    { id: 'amenity', label: 'Food & Cafeteria' },
    { id: 'admin', label: 'Admin & Gates' },
  ];

  return (
    <div className="w-full h-full relative overflow-hidden bg-slate-950">
      {/* Google Maps View */}
      <APIProvider apiKey={apiKey} language="en" region="IN">
        <Map
          id="kce-google-map"
          mapId="DEMO_MAP_ID"
          defaultCenter={{
            lat: KCE_BASE_COORDINATES.lat,
            lng: KCE_BASE_COORDINATES.lng,
          }}
          defaultZoom={18}
          mapTypeId={mapTypeId}
          heading={heading}
          tilt={tilt}
          gestureHandling="greedy"
          disableDefaultUI={false}
          className="w-full h-full"
          internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        >
          {/* Route Overlay & Bounds Controller */}
          <MapRouteOverlay
            route={activeRoute}
            selectedLocation={selectedLocation}
            userLocation={userLocation}
          />

          {/* User Live GPS Location Marker */}
          {userLocation.lat && userLocation.lng && (
            <AdvancedMarker
              position={{ lat: userLocation.lat, lng: userLocation.lng }}
              title="Your Current Location"
            >
              <div className="relative flex items-center justify-center">
                <span className="animate-ping absolute inline-flex h-8 w-8 rounded-full bg-blue-400 opacity-75" />
                <div className="w-6 h-6 rounded-full bg-blue-600 border-2 border-white shadow-lg flex items-center justify-center text-white">
                  <div
                    className="w-2.5 h-2.5 bg-white rounded-full"
                    style={{ transform: `rotate(${userLocation.heading}deg)` }}
                  />
                </div>
              </div>
            </AdvancedMarker>
          )}

          {/* Campus Building Markers (1-45) */}
          {filteredLocations.map((loc) => {
            const lat = loc.coordinates.lat || KCE_BASE_COORDINATES.lat;
            const lng = loc.coordinates.lng || KCE_BASE_COORDINATES.lng;
            const isSelected = selectedLocation?.id === loc.id;

            return (
              <AdvancedMarker
                key={loc.id}
                position={{ lat, lng }}
                title={`${loc.number}. ${loc.name}`}
                onClick={() => {
                  onSelectLocation(loc);
                  setActiveInfoWindowLoc(loc);
                }}
              >
                <div
                  className={`px-2 py-1 rounded-lg text-xs font-bold shadow-md cursor-pointer transition-all duration-200 flex items-center gap-1 border ${
                    isSelected
                      ? 'bg-amber-400 text-slate-950 border-white scale-110 ring-4 ring-amber-400/30'
                      : 'bg-slate-900/90 text-white border-slate-700 hover:bg-slate-800'
                  }`}
                  style={{
                    borderColor: isSelected ? '#ffffff' : loc.color || '#3b82f6',
                  }}
                >
                  <span
                    className="w-4 h-4 rounded-full flex items-center justify-center text-[10px] text-white shrink-0 font-extrabold"
                    style={{ backgroundColor: loc.color || '#3b82f6' }}
                  >
                    {loc.number}
                  </span>
                  <span className="truncate max-w-[120px]">{loc.code || loc.name}</span>
                </div>
              </AdvancedMarker>
            );
          })}

          {/* Marker InfoWindow Card */}
          {activeInfoWindowLoc && (
            <InfoWindow
              position={{
                lat: activeInfoWindowLoc.coordinates.lat || KCE_BASE_COORDINATES.lat,
                lng: activeInfoWindowLoc.coordinates.lng || KCE_BASE_COORDINATES.lng,
              }}
              onCloseClick={() => setActiveInfoWindowLoc(null)}
            >
              <div className="p-1 max-w-[260px] text-slate-900 font-sans">
                <div className="flex items-center gap-2 mb-1.5">
                  <span
                    className="w-6 h-6 rounded-md text-white flex items-center justify-center font-bold text-xs shrink-0"
                    style={{ backgroundColor: activeInfoWindowLoc.color || '#3b82f6' }}
                  >
                    #{activeInfoWindowLoc.number}
                  </span>
                  <div>
                    <h3 className="font-bold text-sm leading-tight">
                      {activeInfoWindowLoc.name}
                    </h3>
                    <p className="text-[11px] text-slate-500 capitalize">
                      {activeInfoWindowLoc.category} Block
                    </p>
                  </div>
                </div>

                <p className="text-xs text-slate-600 line-clamp-2 mb-2">
                  {activeInfoWindowLoc.shortDesc || activeInfoWindowLoc.fullDesc}
                </p>

                {activeInfoWindowLoc.departments && activeInfoWindowLoc.departments.length > 0 && (
                  <div className="mb-2.5">
                    <span className="text-[10px] font-semibold text-slate-500 uppercase">
                      Departments/Labs:
                    </span>
                    <p className="text-xs text-slate-700 font-medium truncate">
                      {activeInfoWindowLoc.departments.slice(0, 2).join(', ')}
                    </p>
                  </div>
                )}

                <div className="flex items-center gap-1.5 pt-1 border-t border-slate-200">
                  <button
                    id="btn-infowindow-navigate"
                    onClick={() => {
                      onStartNavigation(activeInfoWindowLoc);
                      setActiveInfoWindowLoc(null);
                    }}
                    className="flex-1 px-2.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-semibold flex items-center justify-center gap-1 transition-colors"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    Navigate
                  </button>

                  {activeInfoWindowLoc.floors && activeInfoWindowLoc.floors.length > 0 && (
                    <button
                      id="btn-infowindow-floorplan"
                      onClick={() => {
                        onOpenFloorPlan(activeInfoWindowLoc);
                        setActiveInfoWindowLoc(null);
                      }}
                      className="px-2 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded text-xs font-medium flex items-center gap-1 transition-colors"
                      title="View Floor Blueprint"
                    >
                      <Eye className="w-3.5 h-3.5 text-slate-600" />
                      Floors
                    </button>
                  )}

                  <button
                    id="btn-infowindow-details"
                    onClick={() => {
                      onOpenLocationDetail(activeInfoWindowLoc);
                      setActiveInfoWindowLoc(null);
                    }}
                    className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs transition-colors"
                    title="Full Building Info"
                  >
                    <Info className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </InfoWindow>
          )}
        </Map>
      </APIProvider>

      {/* Floating Category Filter Chips */}
      <div className="absolute top-3 left-3 right-3 z-10 flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar pointer-events-auto">
        {categories.map((cat) => (
          <button
            key={cat.id}
            id={`filter-gmap-${cat.id}`}
            onClick={() => setCategoryFilter(cat.id)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all duration-200 shadow-md backdrop-blur-md border ${
              categoryFilter === cat.id
                ? 'bg-blue-600 text-white border-blue-400 font-semibold scale-105 ring-2 ring-blue-500/30'
                : 'bg-slate-900/80 text-slate-300 border-slate-700 hover:bg-slate-800 hover:text-white'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Map Control Toolbar (Bottom-Right) */}
      <div className="absolute bottom-6 right-4 z-10 flex flex-col gap-2">
        {/* Layer Switcher: Hybrid, Satellite, Roadmap */}
        <div className="bg-slate-900/90 border border-slate-700 rounded-xl p-1 shadow-xl flex flex-col gap-1 backdrop-blur-md">
          <button
            id="btn-gmap-layer-hybrid"
            onClick={() => setMapTypeId('hybrid')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors ${
              mapTypeId === 'hybrid'
                ? 'bg-blue-600 text-white font-semibold'
                : 'text-slate-300 hover:bg-slate-800'
            }`}
            title="Google Hybrid Satellite + Labels"
          >
            <Layers className="w-3.5 h-3.5" />
            Hybrid
          </button>
          <button
            id="btn-gmap-layer-satellite"
            onClick={() => setMapTypeId('satellite')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors ${
              mapTypeId === 'satellite'
                ? 'bg-blue-600 text-white font-semibold'
                : 'text-slate-300 hover:bg-slate-800'
            }`}
            title="Pure Satellite Imagery"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Satellite
          </button>
          <button
            id="btn-gmap-layer-roadmap"
            onClick={() => setMapTypeId('roadmap')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors ${
              mapTypeId === 'roadmap'
                ? 'bg-blue-600 text-white font-semibold'
                : 'text-slate-300 hover:bg-slate-800'
            }`}
            title="Standard Google Roadmap"
          >
            Roadmap
          </button>
        </div>

        {/* 3D Tilt Toggle */}
        <button
          id="btn-gmap-tilt-toggle"
          onClick={() => setTilt((prev) => (prev === 0 ? 45 : 0))}
          className={`p-2.5 rounded-xl border shadow-xl flex items-center justify-center backdrop-blur-md transition-colors ${
            tilt > 0
              ? 'bg-indigo-600 text-white border-indigo-400'
              : 'bg-slate-900/90 text-slate-300 border-slate-700 hover:bg-slate-800'
          }`}
          title="Toggle 3D Perspective Tilt"
        >
          <span className="text-xs font-bold">3D</span>
        </button>

        {/* Switch to Blueprint Vector Canvas if preferred */}
        {onSwitchToVectorMap && (
          <button
            id="btn-switch-to-vector-map"
            onClick={onSwitchToVectorMap}
            className="px-2.5 py-1.5 bg-slate-900/90 hover:bg-slate-800 text-slate-300 border border-slate-700 rounded-xl text-xs font-medium shadow-xl flex items-center gap-1.5 transition-colors backdrop-blur-md"
            title="Switch to Vector Blueprint Canvas"
          >
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            Blueprint View
          </button>
        )}
      </div>

      {/* Campus GPS Coordinate Status Pill (Bottom-Left) */}
      <div className="absolute bottom-6 left-4 z-10 hidden sm:flex items-center gap-2 bg-slate-900/90 border border-slate-700 px-3 py-1.5 rounded-full shadow-lg text-xs text-slate-300 backdrop-blur-md">
        <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        <span>KCE Campus: 10.9025° N, 76.9930° E</span>
      </div>
    </div>
  );
};
