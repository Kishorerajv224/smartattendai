import React, { useState } from 'react';
import {
  X,
  Layers,
  Search,
  MapPin,
  Compass,
  Building,
  DoorOpen,
  ArrowRight,
  Sparkles,
  QrCode,
  Info,
} from 'lucide-react';
import { CampusLocation, FloorPlan, RoomInfo } from '../types/campus';
import { CAMPUS_LOCATIONS } from '../data/campusData';

interface IndoorNavigatorModalProps {
  location: CampusLocation | null;
  onClose: () => void;
  initialFloor?: number;
  highlightRoomId?: string;
  onSelectCheckpoint?: (qrCodeId: string) => void;
}

export const IndoorNavigatorModal: React.FC<IndoorNavigatorModalProps> = ({
  location,
  onClose,
  initialFloor = 0,
  highlightRoomId,
  onSelectCheckpoint,
}) => {
  // If location has no floors defined, default to C-Block (most detailed) or first campus location
  const activeLocation =
    location?.floors && location.floors.length > 0
      ? location
      : CAMPUS_LOCATIONS.find((l) => l.id === 25) || CAMPUS_LOCATIONS[0];

  const [selectedFloorNum, setSelectedFloorNum] = useState<number>(initialFloor);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRoom, setSelectedRoom] = useState<RoomInfo | null>(null);

  const currentFloorPlan: FloorPlan =
    activeLocation.floors?.find((f) => f.floorNumber === selectedFloorNum) ||
    activeLocation.floors?.[0] || {
      floorNumber: 0,
      floorName: 'Ground Floor',
      description: 'Main ground level rooms and labs',
      rooms: [],
    };

  // Filter rooms by search query
  const filteredRooms = currentFloorPlan.rooms.filter((r) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    return (
      r.name.toLowerCase().includes(q) ||
      r.roomNumber.toLowerCase().includes(q) ||
      r.category.toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-4xl bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between gap-3 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-white text-base shadow-md"
              style={{ backgroundColor: activeLocation.color }}
            >
              {activeLocation.number}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-slate-100">
                  {activeLocation.name}
                </h2>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-sky-400 border border-slate-700">
                  Indoor Directory
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {currentFloorPlan.floorName} — {currentFloorPlan.description}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Floor Selection Bar & Search Bar */}
        <div className="p-3 sm:px-5 bg-slate-950/60 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          {/* Floor tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto">
            {activeLocation.floors &&
              activeLocation.floors.map((fl) => (
                <button
                  key={fl.floorNumber}
                  onClick={() => {
                    setSelectedFloorNum(fl.floorNumber);
                    setSelectedRoom(null);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                    selectedFloorNum === fl.floorNumber
                      ? 'bg-amber-500 text-slate-950 font-bold shadow'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
                  }`}
                >
                  {fl.floorName}
                </button>
              ))}
          </div>

          {/* Quick Room Search */}
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search room / lab on this floor..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-800 text-xs text-slate-100 placeholder-slate-400 pl-8 pr-3 py-1.5 rounded-xl border border-slate-700 focus:outline-none focus:border-amber-400"
            />
          </div>
        </div>

        {/* Main Content: Floor Blueprint Canvas + Side Directory */}
        <div className="flex-1 overflow-hidden grid grid-cols-1 md:grid-cols-12 min-h-0">
          {/* Blueprint SVG Stage */}
          <div className="md:col-span-8 p-4 bg-slate-950 flex flex-col items-center justify-center overflow-auto relative border-b md:border-b-0 md:border-r border-slate-800">
            <div className="w-full max-w-xl aspect-[16/10] bg-slate-900 border border-slate-700/80 rounded-2xl p-4 shadow-inner relative overflow-hidden flex flex-col justify-between">
              {/* Floor Plan Header Stamp */}
              <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono border-b border-slate-800 pb-2">
                <span>{activeLocation.name.toUpperCase()}</span>
                <span>{currentFloorPlan.floorName.toUpperCase()} ARCHITECTURAL LAYOUT</span>
                <span className="text-amber-400">N ↑</span>
              </div>

              {/* Schematic Rooms Layout */}
              <div className="flex-1 grid grid-cols-3 grid-rows-2 gap-3 py-3 relative">
                {/* Entrance & Stairs / Lift Pillar on Left */}
                <div className="absolute left-1 bottom-1 top-1 w-12 bg-slate-800/80 rounded-lg border border-slate-700 flex flex-col items-center justify-around text-[9px] text-slate-400 p-1">
                  <span className="font-bold text-sky-400">LIFT</span>
                  <span className="font-bold text-amber-400">STAIRS</span>
                  <span className="text-[8px]">ENTRY</span>
                </div>

                {/* Central Corridor Area */}
                <div className="col-span-3 h-8 my-auto bg-slate-800/40 border-y border-dashed border-slate-700/60 rounded flex items-center justify-center text-[10px] text-slate-400 font-medium pl-14">
                  ← CENTRAL CORRIDOR & WALKWAY →
                </div>

                {/* Interactive Room Boxes */}
                {currentFloorPlan.rooms.map((room) => {
                  const isSelected = selectedRoom?.id === room.id || highlightRoomId === room.id;
                  return (
                    <div
                      key={room.id}
                      onClick={() => setSelectedRoom(room)}
                      className={`p-2.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ml-14 ${
                        isSelected
                          ? 'bg-amber-500/20 border-amber-400 shadow-md ring-1 ring-amber-400'
                          : 'bg-slate-800/90 hover:bg-slate-800 border-slate-700 text-slate-200'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-slate-900 text-amber-400">
                          {room.roomNumber}
                        </span>
                        <span className="text-[9px] uppercase tracking-wider text-slate-400">
                          {room.category}
                        </span>
                      </div>
                      <h4 className="font-bold text-xs text-slate-100 line-clamp-2 mt-1">
                        {room.name}
                      </h4>
                      <span className="text-[9px] text-sky-400 mt-1 font-mono">
                        {room.qrCodeId}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Floor Plan Footer Info */}
              <div className="flex items-center justify-between text-[10px] text-slate-400 pt-2 border-t border-slate-800">
                <span>Total Rooms on Floor: {currentFloorPlan.rooms.length}</span>
                <span>Restrooms: North & South Ends</span>
                <span className="text-emerald-400">Emergency Exit: East Stairwell</span>
              </div>
            </div>
          </div>

          {/* Right Side: Floor Directory & Step-by-Step Guidance */}
          <div className="md:col-span-4 p-4 bg-slate-900 overflow-y-auto space-y-3">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <DoorOpen className="w-3.5 h-3.5 text-amber-400" />
              Rooms on this Floor ({filteredRooms.length})
            </h3>

            {/* Room List */}
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {filteredRooms.map((room) => {
                const isSelected = selectedRoom?.id === room.id;
                return (
                  <div
                    key={room.id}
                    onClick={() => setSelectedRoom(room)}
                    className={`p-2.5 rounded-xl border transition cursor-pointer flex items-start justify-between gap-2 ${
                      isSelected
                        ? 'bg-amber-500/20 border-amber-400 text-slate-100'
                        : 'bg-slate-800/60 hover:bg-slate-800 border-slate-700/60 text-slate-300'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-mono font-bold text-amber-400">
                          {room.roomNumber}
                        </span>
                        <span className="text-[10px] uppercase px-1 py-0.2 rounded bg-slate-800 text-slate-400">
                          {room.category}
                        </span>
                      </div>
                      <p className="text-xs font-semibold text-slate-100 mt-0.5">
                        {room.name}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-500 shrink-0 mt-1" />
                  </div>
                );
              })}
            </div>

            {/* Selected Room Guidance Step List */}
            {selectedRoom && (
              <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-700/80 space-y-2 animate-in fade-in duration-150">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-400 font-mono">
                    {selectedRoom.roomNumber}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    QR ID: {selectedRoom.qrCodeId}
                  </span>
                </div>
                <h4 className="font-bold text-sm text-slate-100">
                  {selectedRoom.name}
                </h4>

                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-1">
                  <span className="font-bold text-[11px] text-sky-400 block">
                    Walking Directions from Floor Entrance:
                  </span>
                  <p>1. From the lift / stairs landing, enter the central corridor.</p>
                  <p>2. Walk straight approx 10 meters.</p>
                  <p>
                    3. <strong className="text-white">{selectedRoom.name} ({selectedRoom.roomNumber})</strong> is on your{' '}
                    {selectedRoom.coordinates.y > 50 ? 'right' : 'left'}.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
