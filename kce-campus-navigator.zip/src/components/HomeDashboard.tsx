import React, { useState, useEffect } from 'react';
import {
  Search,
  Navigation,
  Compass,
  Mic,
  QrCode,
  Bot,
  MapPin,
  Clock,
  Star,
  Sparkles,
  ArrowRight,
  Building2,
  BookOpen,
  Utensils,
  Home,
  Shield,
  Layers,
  Flame,
  Award,
  Bell,
} from 'lucide-react';
import { CAMPUS_LOCATIONS } from '../data/campusData';
import { CampusLocation, UserLiveLocation, RouteResult } from '../types/campus';
import { RouteSettings, RoutingSettingsPanel } from './RoutingSettingsPanel';

interface HomeDashboardProps {
  userLocation: UserLiveLocation;
  routeSettings: RouteSettings;
  setRouteSettings: React.Dispatch<React.SetStateAction<RouteSettings>>;
  onNavigateToDestination: (destination: CampusLocation, originBuildingId?: number | null) => void;
  onOpenMap: () => void;
  onOpenVoice: () => void;
  onOpenQRScanner: () => void;
  onOpenAiChat: (initialPrompt?: string) => void;
  onOpenFloorPlan: (location: CampusLocation) => void;
  activeRoute: RouteResult | null;
  onCalculateRoute: (startBuildingId: number | null, endBuildingId: number) => void;
  onStartNavigation: () => void;
  onClearRoute: () => void;
  onOpenLiveLocation?: () => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  userLocation,
  routeSettings,
  setRouteSettings,
  onNavigateToDestination,
  onOpenMap,
  onOpenVoice,
  onOpenQRScanner,
  onOpenAiChat,
  onOpenFloorPlan,
  activeRoute,
  onCalculateRoute,
  onStartNavigation,
  onClearRoute,
  onOpenLiveLocation,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<CampusLocation[]>([]);
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  // Favorites & Recents in LocalStorage
  const [favorites, setFavorites] = useState<number[]>([1, 12, 39, 25]); // Library, Placement, Food Court, C Block
  const [recents, setRecents] = useState<number[]>([1, 13, 24]);

  useEffect(() => {
    try {
      const savedFavs = localStorage.getItem('kce_fav_destinations');
      if (savedFavs) setFavorites(JSON.parse(savedFavs));
      const savedRecents = localStorage.getItem('kce_recent_destinations');
      if (savedRecents) setRecents(JSON.parse(savedRecents));
    } catch {}
  }, []);

  // Search filter across names, departments, labs, amenities, and room keywords
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }
    const q = searchQuery.toLowerCase();
    const results = CAMPUS_LOCATIONS.filter((loc) => {
      const nameMatch = loc.name.toLowerCase().includes(q);
      const codeMatch = loc.code?.toLowerCase().includes(q);
      const numMatch = loc.number.toString() === q;
      const deptMatch = loc.departments?.some((d) => d.toLowerCase().includes(q));
      const labMatch = loc.labs?.some((l) => l.toLowerCase().includes(q));
      const descMatch = loc.shortDesc.toLowerCase().includes(q);
      const roomMatch = loc.floors?.some((f) =>
        f.rooms.some((r) => r.name.toLowerCase().includes(q) || r.roomNumber.toLowerCase().includes(q))
      );
      return nameMatch || codeMatch || numMatch || deptMatch || labMatch || descMatch || roomMatch;
    }).slice(0, 8);

    setSearchResults(results);
  }, [searchQuery]);

  const handleSelectDestination = (loc: CampusLocation) => {
    // Save to recents
    const updatedRecents = [loc.id, ...recents.filter((id) => id !== loc.id)].slice(0, 5);
    setRecents(updatedRecents);
    try {
      localStorage.setItem('kce_recent_destinations', JSON.stringify(updatedRecents));
    } catch {}

    setSearchQuery('');
    setIsSearchFocused(false);
    
    // Set in routing settings
    setRouteSettings((prev) => ({
      ...prev,
      destinationBuildingId: loc.id,
    }));
    
    const originId = routeSettings.originType === 'building' ? routeSettings.originBuildingId : null;
    onNavigateToDestination(loc, originId);
  };

  const toggleFavorite = (locId: number, e: React.MouseEvent) => {
    e.stopPropagation();
    let updated: number[];
    if (favorites.includes(locId)) {
      updated = favorites.filter((id) => id !== locId);
    } else {
      updated = [...favorites, locId];
    }
    setFavorites(updated);
    try {
      localStorage.setItem('kce_fav_destinations', JSON.stringify(updated));
    } catch {}
  };

  // Quick Access presets
  const quickPlaces = [
    { label: 'Central Library', id: 1, icon: BookOpen, color: 'text-sky-400 bg-sky-950/40 border-sky-800/60' },
    { label: 'C Block (CSE/IT)', id: 25, icon: Building2, color: 'text-indigo-400 bg-indigo-950/40 border-indigo-800/60' },
    { label: 'Placement Hall', id: 12, icon: Award, color: 'text-amber-400 bg-amber-950/40 border-amber-800/60' },
    { label: 'Food Court', id: 39, icon: Utensils, color: 'text-emerald-400 bg-emerald-950/40 border-emerald-800/60' },
    { label: 'Auditorium', id: 29, icon: Sparkles, color: 'text-purple-400 bg-purple-950/40 border-purple-800/60' },
    { label: 'Main Gate', id: 5, icon: Shield, color: 'text-rose-400 bg-rose-950/40 border-rose-800/60' },
  ];

  // Campus Notices & Bulletins
  const notices = [
    {
      id: 1,
      title: 'Placement Drive • Tech Mahindra & Zoho',
      location: 'Placement Hall 1 & 2 (#12)',
      time: 'Today, 9:00 AM onwards',
      urgent: true,
      locId: 12,
    },
    {
      id: 2,
      title: 'Digital Library Extended Hours for Exams',
      location: 'Central Library (#1)',
      time: 'Open until 9:00 PM',
      urgent: false,
      locId: 1,
    },
    {
      id: 3,
      title: 'National Level Technical Symposium',
      location: 'Auditorium / C-Block (#29)',
      time: 'Starts 10:30 AM',
      urgent: false,
      locId: 29,
    },
  ];

  return (
    <div className="w-full h-full overflow-y-auto bg-slate-950 text-slate-100 p-4 sm:p-6 md:p-8 max-w-5xl mx-auto space-y-6 pb-24">
      {/* Hero Welcome Header with Live GPS Status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950 p-4 sm:p-5 rounded-2xl border border-slate-800 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-slate-950 font-black text-xl shadow-lg shrink-0">
            KCE
          </div>
          <div>
            <h1 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
              Karpagam College of Engineering
              <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30">
                NAAC A+ Autonomous
              </span>
            </h1>
            <p className="text-xs text-slate-400">
              Campus Navigator • Official Blueprint Map & Origin-to-Destination Routing
            </p>
          </div>
        </div>

        {/* Live GPS Origin Badge / Pin Trigger */}
        <button
          onClick={onOpenLiveLocation}
          className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-950/80 hover:bg-slate-900 border border-slate-700/80 hover:border-emerald-500/50 text-xs text-slate-300 self-start sm:self-auto transition cursor-pointer group"
          title="Click to Grant Live Location Access or Pin Location"
        >
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
          </span>
          <div className="text-[11px] leading-tight text-left">
            <span className="text-slate-400 group-hover:text-slate-200 block text-[9px] uppercase font-semibold">
              {userLocation.isSimulated ? 'Pinned Location' : 'Live GPS'}
            </span>
            <span className="font-semibold text-emerald-300 group-hover:text-emerald-200">
              {userLocation.isSimulated ? 'Custom Pin' : 'Active (Tap to Configure)'}
            </span>
          </div>
        </button>
      </div>

      {/* Embedded Routing Settings Card (Starting Point to Destination) */}
      <div className="space-y-2">
        <RoutingSettingsPanel
          routeSettings={routeSettings}
          setRouteSettings={setRouteSettings}
          userLocation={userLocation}
          activeRoute={activeRoute}
          onCalculateRoute={onCalculateRoute}
          onStartNavigation={onStartNavigation}
          onClearRoute={onClearRoute}
          isOpen={true}
          inline={true}
        />
      </div>

      {/* Main Single Destination Quick Search Bar */}
      <div className="relative">
        <div className="relative flex items-center">
          <Search className="w-5 h-5 text-amber-400 absolute left-4 pointer-events-none" />
          <input
            id="home-destination-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={() => setIsSearchFocused(true)}
            placeholder="Quick search any block or lab (e.g. C-Block #25, Placement Hall #12, Chemistry Lab #14)"
            className="w-full pl-12 pr-28 py-3.5 sm:py-4 rounded-2xl bg-slate-900/90 border-2 border-indigo-500/50 focus:border-amber-400 text-sm sm:text-base text-white placeholder-slate-400 shadow-2xl focus:outline-none focus:ring-4 focus:ring-amber-400/20 transition-all"
          />

          {/* Voice & QR Input Buttons inside search bar */}
          <div className="absolute right-3 flex items-center gap-1.5">
            <button
              id="btn-search-voice"
              onClick={onOpenVoice}
              className="p-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 transition-colors"
              title="Voice Search"
            >
              <Mic className="w-4 h-4" />
            </button>
            <button
              id="btn-search-qr"
              onClick={onOpenQRScanner}
              className="p-2 rounded-xl bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/30 transition-colors"
              title="Scan Indoor QR Code"
            >
              <QrCode className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Live Autocomplete Results Dropdown */}
        {searchResults.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-2 z-50 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden divide-y divide-slate-800">
            {searchResults.map((loc) => (
              <div
                key={loc.id}
                onClick={() => handleSelectDestination(loc)}
                className="p-3 sm:p-4 hover:bg-slate-800/80 cursor-pointer flex items-center justify-between transition-colors group"
              >
                <div className="flex items-center gap-3">
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-black text-white shrink-0 shadow-sm"
                    style={{ backgroundColor: loc.color || '#3b82f6' }}
                  >
                    #{loc.number}
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-white group-hover:text-amber-400 transition-colors">
                      {loc.name}
                    </h4>
                    <p className="text-xs text-slate-400 truncate max-w-[280px] sm:max-w-md">
                      {loc.shortDesc}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSelectDestination(loc);
                    }}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1 shadow-sm transition-all"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    Go
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick-Access Destination Buttons */}
      <div className="space-y-2">
        <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
          <Flame className="w-3.5 h-3.5 text-amber-400" />
          Popular Destinations
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5">
          {quickPlaces.map((item) => {
            const loc = CAMPUS_LOCATIONS.find((l) => l.id === item.id);
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                id={`quick-dest-${item.id}`}
                onClick={() => loc && handleSelectDestination(loc)}
                className={`p-3 rounded-xl border flex flex-col items-center text-center gap-2 hover:scale-[1.02] active:scale-95 transition-all shadow-md ${item.color}`}
              >
                <Icon className="w-5 h-5 shrink-0" />
                <span className="text-xs font-semibold line-clamp-1">{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Mini Blueprint Map Preview + Saved Favorites Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Mini Blueprint Map Card */}
        <div
          onClick={onOpenMap}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 cursor-pointer relative overflow-hidden group shadow-xl flex flex-col justify-between min-h-[220px]"
        >
          <div className="flex items-center justify-between z-10">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-blue-400" />
              <h3 className="text-sm font-bold text-white">Official KCE Blueprint Map</h3>
            </div>
            <span className="text-[11px] font-semibold text-blue-400 group-hover:text-blue-300 flex items-center gap-1 bg-blue-950/60 px-2 py-0.5 rounded-full border border-blue-800/40">
              Open Full Map <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
            </span>
          </div>

          <div className="my-3 py-6 px-4 bg-slate-950/70 border border-slate-800 rounded-xl relative flex flex-col items-center justify-center text-center">
            <div className="relative flex items-center justify-center mb-2">
              <span className="animate-ping absolute inline-flex h-10 w-10 rounded-full bg-blue-400 opacity-60" />
              <div className="w-8 h-8 rounded-full bg-blue-600 border-2 border-white flex items-center justify-center shadow-lg">
                <Navigation className="w-4 h-4 text-white" />
              </div>
            </div>
            <p className="text-xs font-semibold text-slate-200">Interactive Blueprint with All 45 Blocks</p>
            <p className="text-[11px] text-slate-400">Tap anywhere to inspect buildings, select origins, and route</p>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 z-10 pt-2 border-t border-slate-800">
            <span>45 Indexed Blocks & Facilities</span>
            <span className="text-emerald-400 font-medium">100% Walkable Routing Ready</span>
          </div>
        </div>

        {/* Saved Favorites & Recents */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col justify-between min-h-[220px]">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
              <h3 className="text-sm font-bold text-white">Saved & Recent Places</h3>
            </div>
            <span className="text-[11px] text-slate-400">1-Tap Navigation</span>
          </div>

          <div className="space-y-2 flex-1">
            {favorites.map((favId) => {
              const loc = CAMPUS_LOCATIONS.find((l) => l.id === favId);
              if (!loc) return null;
              return (
                <div
                  key={loc.id}
                  onClick={() => handleSelectDestination(loc)}
                  className="p-2.5 rounded-xl bg-slate-950/60 hover:bg-slate-800/80 border border-slate-800 flex items-center justify-between cursor-pointer transition-colors group"
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className="w-6 h-6 rounded-md flex items-center justify-center text-[11px] font-bold text-white shrink-0"
                      style={{ backgroundColor: loc.color || '#3b82f6' }}
                    >
                      #{loc.number}
                    </span>
                    <div>
                      <h4 className="text-xs font-semibold text-slate-200 group-hover:text-amber-400 transition-colors">
                        {loc.name}
                      </h4>
                      <p className="text-[10px] text-slate-400 truncate max-w-[180px]">
                        {loc.shortDesc}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={(e) => toggleFavorite(loc.id, e)}
                      className="p-1 text-amber-400 hover:text-amber-300"
                      title="Remove Favorite"
                    >
                      <Star className="w-3.5 h-3.5 fill-amber-400" />
                    </button>
                    <button
                      onClick={() => handleSelectDestination(loc)}
                      className="p-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium"
                      title="Navigate"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-2 mt-2 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Tap star on any building to add</span>
            <button
              onClick={() => onOpenFloorPlan(CAMPUS_LOCATIONS[0])}
              className="text-cyan-400 hover:underline"
            >
              Browse Floor Plans →
            </button>
          </div>
        </div>
      </div>

      {/* Campus Notices & Daily Announcements */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-rose-400" />
            <h3 className="text-sm font-bold text-white">Today's Campus Bulletins & Events</h3>
          </div>
          <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            Live Feed
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {notices.map((n) => {
            const loc = CAMPUS_LOCATIONS.find((l) => l.id === n.locId);
            return (
              <div
                key={n.id}
                className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col justify-between gap-2 hover:border-slate-700 transition-colors"
              >
                <div>
                  <div className="flex items-center gap-1.5 mb-1">
                    {n.urgent && (
                      <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                    )}
                    <h4 className="text-xs font-bold text-slate-100">{n.title}</h4>
                  </div>
                  <p className="text-[11px] text-slate-400">{n.location}</p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                  <span className="text-[10px] text-amber-400/90 font-medium">{n.time}</span>
                  {loc && (
                    <button
                      onClick={() => handleSelectDestination(loc)}
                      className="text-[11px] text-blue-400 hover:text-blue-300 font-semibold flex items-center gap-0.5"
                    >
                      Guide Me <ArrowRight className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Floating Smart Tools Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
        <button
          id="btn-home-voice-assistant"
          onClick={onOpenVoice}
          className="p-4 rounded-2xl bg-gradient-to-br from-amber-600/20 to-orange-600/20 hover:from-amber-600/30 hover:to-orange-600/30 border border-amber-500/40 text-left flex items-center gap-3.5 transition-all group shadow-lg"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center shadow-md shrink-0 group-hover:scale-110 transition-transform">
            <Mic className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white group-hover:text-amber-300">Voice Assistant</h4>
            <p className="text-xs text-slate-400">Speak "Take me to Physics Lab"</p>
          </div>
        </button>

        <button
          id="btn-home-qr-scanner"
          onClick={onOpenQRScanner}
          className="p-4 rounded-2xl bg-gradient-to-br from-blue-600/20 to-cyan-600/20 hover:from-blue-600/30 hover:to-cyan-600/30 border border-blue-500/40 text-left flex items-center gap-3.5 transition-all group shadow-lg"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-500 text-white flex items-center justify-center shadow-md shrink-0 group-hover:scale-110 transition-transform">
            <QrCode className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white group-hover:text-blue-300">Indoor QR Check-in</h4>
            <p className="text-xs text-slate-400">Scan door/pillar QR for room steps</p>
          </div>
        </button>

        <button
          id="btn-home-ai-mitra"
          onClick={() => onOpenAiChat()}
          className="p-4 rounded-2xl bg-gradient-to-br from-purple-600/20 to-indigo-600/20 hover:from-purple-600/30 hover:to-indigo-600/30 border border-purple-500/40 text-left flex items-center gap-3.5 transition-all group shadow-lg"
        >
          <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-md shrink-0 group-hover:scale-110 transition-transform">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white group-hover:text-indigo-300">Ask KCE Mitra AI</h4>
            <p className="text-xs text-slate-400">HOD cabins, timings & hostel queries</p>
          </div>
        </button>
      </div>
    </div>
  );
};
