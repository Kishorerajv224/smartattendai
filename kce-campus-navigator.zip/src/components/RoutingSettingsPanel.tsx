import React, { useState, useEffect } from 'react';
import {
  Navigation,
  MapPin,
  ArrowRightLeft,
  Search,
  Footprints,
  Accessibility,
  Umbrella,
  X,
  Play,
  RotateCcw,
  Sparkles,
  ChevronDown,
  LocateFixed,
  Clock,
  Compass,
} from 'lucide-react';
import { CAMPUS_LOCATIONS } from '../data/campusData';
import { CampusLocation, RouteResult, UserLiveLocation } from '../types/campus';

export interface RouteSettings {
  originType: 'gps' | 'building';
  originBuildingId: number | null;
  destinationBuildingId: number | null;
  preference: 'fastest' | 'accessible' | 'covered';
}

interface RoutingSettingsPanelProps {
  routeSettings: RouteSettings;
  setRouteSettings: React.Dispatch<React.SetStateAction<RouteSettings>>;
  userLocation: UserLiveLocation;
  activeRoute: RouteResult | null;
  onCalculateRoute: (startBuildingId: number | null, endBuildingId: number) => void;
  onStartNavigation: () => void;
  onClearRoute: () => void;
  isOpen: boolean;
  onClose?: () => void;
  inline?: boolean;
}

export const RoutingSettingsPanel: React.FC<RoutingSettingsPanelProps> = ({
  routeSettings,
  setRouteSettings,
  userLocation,
  activeRoute,
  onCalculateRoute,
  onStartNavigation,
  onClearRoute,
  isOpen,
  onClose,
  inline = false,
}) => {
  const [originSearch, setOriginSearch] = useState('');
  const [destSearch, setDestSearch] = useState('');
  const [showOriginDropdown, setShowOriginDropdown] = useState(false);
  const [showDestDropdown, setShowDestDropdown] = useState(false);

  const selectedOriginBuilding = routeSettings.originBuildingId
    ? CAMPUS_LOCATIONS.find((b) => b.id === routeSettings.originBuildingId)
    : null;

  const selectedDestBuilding = routeSettings.destinationBuildingId
    ? CAMPUS_LOCATIONS.find((b) => b.id === routeSettings.destinationBuildingId)
    : null;

  // Filter origins
  const filteredOrigins = CAMPUS_LOCATIONS.filter((loc) => {
    if (!originSearch.trim()) return true;
    const q = originSearch.toLowerCase();
    return (
      loc.name.toLowerCase().includes(q) ||
      loc.number.toString() === q ||
      loc.shortDesc.toLowerCase().includes(q) ||
      loc.code?.toLowerCase().includes(q)
    );
  });

  // Filter destinations
  const filteredDests = CAMPUS_LOCATIONS.filter((loc) => {
    if (!destSearch.trim()) return true;
    const q = destSearch.toLowerCase();
    return (
      loc.name.toLowerCase().includes(q) ||
      loc.number.toString() === q ||
      loc.shortDesc.toLowerCase().includes(q) ||
      loc.code?.toLowerCase().includes(q)
    );
  });

  // Swap Origin and Destination
  const handleSwap = () => {
    if (!selectedDestBuilding) return;

    if (routeSettings.originType === 'gps') {
      // If was GPS, set origin to previous destination and destination to Main Gate (#5)
      const prevDest = routeSettings.destinationBuildingId;
      setRouteSettings((prev) => ({
        ...prev,
        originType: 'building',
        originBuildingId: prevDest,
        destinationBuildingId: 5,
      }));
      if (prevDest) {
        onCalculateRoute(prevDest, 5);
      }
    } else {
      const prevOrigin = routeSettings.originBuildingId;
      const prevDest = routeSettings.destinationBuildingId;
      setRouteSettings((prev) => ({
        ...prev,
        originBuildingId: prevDest,
        destinationBuildingId: prevOrigin,
      }));
      if (prevDest && prevOrigin) {
        onCalculateRoute(prevDest, prevOrigin);
      }
    }
  };

  const handleSelectOrigin = (loc: CampusLocation | 'gps') => {
    if (loc === 'gps') {
      setRouteSettings((prev) => ({
        ...prev,
        originType: 'gps',
        originBuildingId: null,
      }));
      setShowOriginDropdown(false);
      setOriginSearch('');
      if (routeSettings.destinationBuildingId) {
        onCalculateRoute(null, routeSettings.destinationBuildingId);
      }
    } else {
      setRouteSettings((prev) => ({
        ...prev,
        originType: 'building',
        originBuildingId: loc.id,
      }));
      setShowOriginDropdown(false);
      setOriginSearch('');
      if (routeSettings.destinationBuildingId) {
        onCalculateRoute(loc.id, routeSettings.destinationBuildingId);
      }
    }
  };

  const handleSelectDestination = (loc: CampusLocation) => {
    setRouteSettings((prev) => ({
      ...prev,
      destinationBuildingId: loc.id,
    }));
    setShowDestDropdown(false);
    setDestSearch('');
    const originId = routeSettings.originType === 'building' ? routeSettings.originBuildingId : null;
    onCalculateRoute(originId, loc.id);
  };

  // Quick Preset Points
  const quickOrigins = [
    { label: 'Live GPS', id: 'gps', icon: LocateFixed },
    { label: 'Main Gate (#5)', id: 5 },
    { label: 'Bus Parking (#35)', id: 35 },
    { label: 'Boys Hostel (#32)', id: 32 },
    { label: 'Girls Hostel (#33)', id: 33 },
  ];

  const quickDests = [
    { label: 'Central Library (#1)', id: 1 },
    { label: 'C Block CSE (#25)', id: 25 },
    { label: 'Placement Hall (#12)', id: 12 },
    { label: 'Food Court (#39)', id: 39 },
    { label: 'Auditorium (#29)', id: 29 },
  ];

  if (!isOpen && !inline) return null;

  return (
    <div
      id="routing-settings-panel"
      className={`${
        inline
          ? 'w-full bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl'
          : 'fixed top-16 left-4 right-4 sm:left-6 sm:right-auto sm:w-[420px] z-40 bg-slate-900/95 border border-slate-700/80 rounded-2xl p-4 shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-top-4'
      }`}
    >
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
            <Navigation className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-white">Route Settings</h3>
            <p className="text-[11px] text-slate-400">Set start location and destination</p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          {activeRoute && (
            <button
              onClick={onClearRoute}
              className="px-2 py-1 text-[11px] font-medium text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-1"
              title="Clear active route"
            >
              <RotateCcw className="w-3 h-3" />
              Reset
            </button>
          )}
          {onClose && !inline && (
            <button
              onClick={onClose}
              className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Start and Destination Input Group */}
      <div className="relative mt-3 space-y-2">
        {/* Origin / Starting Point */}
        <div className="relative">
          <label className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1 mb-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            Starting Point (Origin)
          </label>
          <div
            onClick={() => {
              setShowOriginDropdown(!showOriginDropdown);
              setShowDestDropdown(false);
            }}
            className="w-full bg-slate-950/80 hover:bg-slate-950 border border-slate-700/80 hover:border-emerald-500/50 rounded-xl px-3 py-2 text-xs text-white flex items-center justify-between cursor-pointer transition-all"
          >
            <div className="flex items-center gap-2 truncate">
              {routeSettings.originType === 'gps' ? (
                <>
                  <LocateFixed className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="font-semibold text-emerald-300">Your Live GPS Location</span>
                </>
              ) : selectedOriginBuilding ? (
                <>
                  <span
                    className="w-5 h-5 rounded text-[10px] font-bold text-white flex items-center justify-center shrink-0"
                    style={{ backgroundColor: selectedOriginBuilding.color || '#3b82f6' }}
                  >
                    #{selectedOriginBuilding.number}
                  </span>
                  <span className="font-semibold text-white truncate">
                    {selectedOriginBuilding.name}
                  </span>
                </>
              ) : (
                <span className="text-slate-400">Select Starting Point...</span>
              )}
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          </div>

          {/* Origin Dropdown Menu */}
          {showOriginDropdown && (
            <div className="absolute top-full left-0 right-0 mt-1 z-50 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden divide-y divide-slate-800 max-h-64 overflow-y-auto">
              <div className="p-2 sticky top-0 bg-slate-900 z-10">
                <input
                  type="text"
                  placeholder="Search starting block..."
                  value={originSearch}
                  onChange={(e) => setOriginSearch(e.target.value)}
                  onClick={(e) => e.stopPropagation()}
                  className="w-full bg-slate-950 text-xs px-2.5 py-1.5 rounded-lg border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
                  autoFocus
                />
              </div>

              {/* GPS Option */}
              <div
                onClick={() => handleSelectOrigin('gps')}
                className="p-2.5 hover:bg-slate-800 cursor-pointer flex items-center gap-2 text-xs font-semibold text-emerald-400"
              >
                <LocateFixed className="w-4 h-4" />
                <span>Use Current Live GPS Location</span>
              </div>

              {/* Building List */}
              {filteredOrigins.map((loc) => (
                <div
                  key={loc.id}
                  onClick={() => handleSelectOrigin(loc)}
                  className="p-2.5 hover:bg-slate-800 cursor-pointer flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2 truncate">
                    <span
                      className="w-5 h-5 rounded text-[10px] font-bold text-white flex items-center justify-center shrink-0"
                      style={{ backgroundColor: loc.color || '#3b82f6' }}
                    >
                      {loc.number}
                    </span>
                    <span className="text-slate-200 truncate">{loc.name}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 shrink-0 capitalize">{loc.category}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Swap Origin & Destination Button */}
        <div className="flex justify-center -my-1 relative z-10">
          <button
            id="btn-swap-origin-destination"
            onClick={handleSwap}
            disabled={!routeSettings.destinationBuildingId}
            className="w-7 h-7 rounded-full bg-slate-800 hover:bg-blue-600 text-slate-300 hover:text-white border border-slate-700 hover:border-blue-400 flex items-center justify-center shadow-md transition-all disabled:opacity-40 disabled:pointer-events-none"
            title="Swap Origin & Destination"
          >
            <ArrowRightLeft className="w-3.5 h-3.5 rotate-90" />
          </button>
        </div>

        {/* Destination Point */}
        <div className="relative">
          <label className="text-[10px] font-bold uppercase tracking-wider text-rose-400 flex items-center gap-1 mb-1">
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            Destination Point
          </label>
          <div
            onClick={() => {
              setShowDestDropdown(!showDestDropdown);
              setShowOriginDropdown(false);
            }}
            className="w-full bg-slate-950/80 hover:bg-slate-950 border border-slate-700/80 hover:border-rose-500/50 rounded-xl px-3 py-2 text-xs text-white flex items-center justify-between cursor-pointer transition-all"
          >
            <div className="flex items-center gap-2 truncate">
              {selectedDestBuilding ? (
                <>
                  <span
                    className="w-5 h-5 rounded text-[10px] font-bold text-white flex items-center justify-center shrink-0"
                    style={{ backgroundColor: selectedDestBuilding.color || '#ef4444' }}
                  >
                    #{selectedDestBuilding.number}
                  </span>
                  <span className="font-semibold text-white truncate">
                    {selectedDestBuilding.name}
                  </span>
                </>
              ) : (
                <span className="text-slate-400">Select Destination...</span>
              )}
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          </div>

          {/* Destination Dropdown Menu */}
          {showDestDropdown && (
            <div className="absolute top-full left-0 right-0 mt-1 z-50 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden divide-y divide-slate-800 max-h-64 overflow-y-auto">
              <div className="p-2 sticky top-0 bg-slate-900 z-10">
                <input
                  type="text"
                  placeholder="Search destination block (1-45)..."
                  value={destSearch}
                  onChange={(e) => setDestSearch(e.target.value)}
                  onClick={(e) => e.stopPropagation()}
                  className="w-full bg-slate-950 text-xs px-2.5 py-1.5 rounded-lg border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-rose-400"
                  autoFocus
                />
              </div>

              {filteredDests.map((loc) => (
                <div
                  key={loc.id}
                  onClick={() => handleSelectDestination(loc)}
                  className="p-2.5 hover:bg-slate-800 cursor-pointer flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2 truncate">
                    <span
                      className="w-5 h-5 rounded text-[10px] font-bold text-white flex items-center justify-center shrink-0"
                      style={{ backgroundColor: loc.color || '#ef4444' }}
                    >
                      {loc.number}
                    </span>
                    <span className="text-slate-200 truncate">{loc.name}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 shrink-0 capitalize">{loc.category}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Quick Access Destination Chips */}
      <div className="mt-3">
        <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider block mb-1.5">
          Quick Destination Presets:
        </span>
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {quickDests.map((qd) => {
            const loc = CAMPUS_LOCATIONS.find((l) => l.id === qd.id);
            if (!loc) return null;
            const isSelected = routeSettings.destinationBuildingId === loc.id;
            return (
              <button
                key={qd.id}
                onClick={() => handleSelectDestination(loc)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-medium whitespace-nowrap border transition-all ${
                  isSelected
                    ? 'bg-rose-600 text-white border-rose-400 font-semibold'
                    : 'bg-slate-950/70 text-slate-300 border-slate-800 hover:bg-slate-800'
                }`}
              >
                {qd.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Route Preferences / Mode */}
      <div className="mt-3 pt-3 border-t border-slate-800">
        <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider block mb-1.5">
          Route Preference:
        </span>
        <div className="grid grid-cols-3 gap-1.5">
          <button
            onClick={() => setRouteSettings((prev) => ({ ...prev, preference: 'fastest' }))}
            className={`px-2 py-1.5 rounded-xl border text-[11px] font-medium flex items-center justify-center gap-1 transition-all ${
              routeSettings.preference === 'fastest'
                ? 'bg-blue-600 text-white border-blue-400 font-bold'
                : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:bg-slate-800'
            }`}
          >
            <Footprints className="w-3.5 h-3.5" />
            Fastest
          </button>
          <button
            onClick={() => setRouteSettings((prev) => ({ ...prev, preference: 'accessible' }))}
            className={`px-2 py-1.5 rounded-xl border text-[11px] font-medium flex items-center justify-center gap-1 transition-all ${
              routeSettings.preference === 'accessible'
                ? 'bg-blue-600 text-white border-blue-400 font-bold'
                : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:bg-slate-800'
            }`}
          >
            <Accessibility className="w-3.5 h-3.5" />
            Step-Free
          </button>
          <button
            onClick={() => setRouteSettings((prev) => ({ ...prev, preference: 'covered' }))}
            className={`px-2 py-1.5 rounded-xl border text-[11px] font-medium flex items-center justify-center gap-1 transition-all ${
              routeSettings.preference === 'covered'
                ? 'bg-blue-600 text-white border-blue-400 font-bold'
                : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:bg-slate-800'
            }`}
          >
            <Umbrella className="w-3.5 h-3.5" />
            Covered
          </button>
        </div>
      </div>

      {/* Calculated Route Summary Card & Start Navigation Button */}
      {activeRoute && selectedDestBuilding && (
        <div className="mt-3 pt-3 border-t border-slate-800 space-y-2.5">
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <Footprints className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-white">
                  {activeRoute.totalDistanceMeters} meters
                </div>
                <div className="text-[11px] text-slate-400 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-amber-400" />
                  <span>~{activeRoute.estimatedTimeMinutes} min walk ({activeRoute.steps.length} turns)</span>
                </div>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30">
                Dijkstra Optimal
              </span>
            </div>
          </div>

          <button
            id="btn-routing-start-navigation"
            onClick={onStartNavigation}
            className="w-full py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg flex items-center justify-center gap-2 transition-all active:scale-95"
          >
            <Play className="w-4 h-4 fill-white" />
            Start Turn-by-Turn Guidance
          </button>
        </div>
      )}
    </div>
  );
};
