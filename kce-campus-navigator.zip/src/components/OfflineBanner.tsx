import React, { useState, useEffect } from 'react';
import { WifiOff, CheckCircle2 } from 'lucide-react';

export const OfflineBanner: React.FC = () => {
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [showReconnected, setShowReconnected] = useState<boolean>(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setShowReconnected(true);
      setTimeout(() => setShowReconnected(false), 3500);
    };

    const handleOffline = () => {
      setIsOnline(false);
      setShowReconnected(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (isOnline && !showReconnected) return null;

  return (
    <div
      id="offline-status-banner"
      className={`fixed top-14 left-1/2 -translate-x-1/2 z-40 px-4 py-2 rounded-full shadow-lg border text-xs font-medium flex items-center gap-2 backdrop-blur-md transition-all duration-300 ${
        isOnline
          ? 'bg-emerald-950/90 border-emerald-500/50 text-emerald-200'
          : 'bg-amber-950/90 border-amber-500/50 text-amber-200 animate-pulse'
      }`}
    >
      {isOnline ? (
        <>
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>Back Online • Campus sync active</span>
        </>
      ) : (
        <>
          <WifiOff className="w-4 h-4 text-amber-400" />
          <span>Offline Mode • Using cached campus directory & pathfinding</span>
        </>
      )}
    </div>
  );
};
