import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Camera,
  QrCode,
  CheckCircle2,
  AlertTriangle,
  RotateCw,
  Printer,
  Sparkles,
  ArrowRight,
  Layers,
  MapPin,
  Compass,
} from 'lucide-react';
import QRCode from 'qrcode';
import { QR_CHECKPOINTS, CAMPUS_LOCATIONS } from '../data/campusData';
import { QRCodeCheckpoint, CampusLocation } from '../types/campus';
import { speakText } from '../utils/speech';

interface QRScannerModalProps {
  onClose: () => void;
  onSelectCheckpointLocation: (location: CampusLocation, floorNumber?: number) => void;
  onOpenFloorPlan: (location: CampusLocation, floorNumber?: number) => void;
}

export const QRScannerModal: React.FC<QRScannerModalProps> = ({
  onClose,
  onSelectCheckpointLocation,
  onOpenFloorPlan,
}) => {
  const [activeTab, setActiveTab] = useState<'camera' | 'demo' | 'print'>('camera');
  const [scannedCheckpoint, setScannedCheckpoint] = useState<QRCodeCheckpoint | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [qrImages, setQrImages] = useState<Record<string, string>>({});
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Generate QR code data URLs for the printable sheet
  useEffect(() => {
    async function generateQRs() {
      const generated: Record<string, string> = {};
      for (const cp of QR_CHECKPOINTS) {
        try {
          const url = await QRCode.toDataURL(
            JSON.stringify({
              app: 'KCE_NAVIGATOR',
              id: cp.id,
              buildingId: cp.buildingId,
              floor: cp.floorNumber,
              title: cp.title,
            }),
            {
              width: 200,
              margin: 2,
              color: {
                dark: '#0f172a',
                light: '#ffffff',
              },
            }
          );
          generated[cp.id] = url;
        } catch (e) {
          console.error(e);
        }
      }
      setQrImages(generated);
    }
    generateQRs();
  }, []);

  // Camera start / stop
  useEffect(() => {
    let isCancelled = false;

    if (activeTab !== 'camera' || scannedCheckpoint) {
      stopCamera();
      return;
    }

    const startCamera = async () => {
      setCameraError(null);
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          if (!isCancelled) {
            setCameraError('Camera access not supported on this device/browser.');
          }
          return;
        }

        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: facingMode },
        });

        if (isCancelled) {
          // Clean up if cancelled while waiting for permission
          stream.getTracks().forEach((t) => t.stop());
          return;
        }

        streamRef.current = stream;
        if (videoRef.current) {
          const video = videoRef.current;
          video.srcObject = stream;
          video.onloadedmetadata = () => {
            if (!isCancelled && streamRef.current === stream) {
              const playPromise = video.play();
              if (playPromise !== undefined) {
                playPromise.catch((err) => {
                  // Silently ignore benign interruption and abort errors
                  if (err?.name !== 'AbortError' && !err?.message?.includes('interrupted')) {
                    console.warn('Camera play warning:', err);
                  }
                });
              }
            }
          };
        }
      } catch (err: any) {
        if (!isCancelled) {
          console.warn('Camera error:', err);
          setCameraError(
            'Camera permission was not granted or camera is busy. You can use the Demo Checkpoints tab to simulate instant indoor scanning!'
          );
        }
      }
    };

    startCamera();

    return () => {
      isCancelled = true;
      stopCamera();
    };
  }, [activeTab, facingMode, scannedCheckpoint]);

  const stopCamera = () => {
    if (videoRef.current) {
      videoRef.current.onloadedmetadata = null;
      try {
        videoRef.current.pause();
      } catch {}
      videoRef.current.srcObject = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
  };

  const handleCheckpointSelect = (cp: QRCodeCheckpoint) => {
    setScannedCheckpoint(cp);
    speakText(`Scanned: ${cp.title}. ${cp.stepGuide[0] || ''}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-xl bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between gap-3 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-100">
                Indoor QR Navigator
              </h2>
              <p className="text-xs text-slate-400">
                Scan checkpoint QR codes at building entrances, floors & labs
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        {!scannedCheckpoint && (
          <div className="flex border-b border-slate-800 px-4 bg-slate-950/60">
            <button
              onClick={() => setActiveTab('camera')}
              className={`py-3 px-4 text-xs font-semibold border-b-2 transition flex items-center gap-1.5 ${
                activeTab === 'camera'
                  ? 'border-amber-400 text-amber-400 font-bold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Live Camera</span>
            </button>
            <button
              onClick={() => setActiveTab('demo')}
              className={`py-3 px-4 text-xs font-semibold border-b-2 transition flex items-center gap-1.5 ${
                activeTab === 'demo'
                  ? 'border-amber-400 text-amber-400 font-bold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-sky-400" />
              <span>Demo Checkpoints (9)</span>
            </button>
            <button
              onClick={() => setActiveTab('print')}
              className={`py-3 px-4 text-xs font-semibold border-b-2 transition flex items-center gap-1.5 ${
                activeTab === 'print'
                  ? 'border-amber-400 text-amber-400 font-bold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Printer className="w-3.5 h-3.5 text-emerald-400" />
              <span>Print Codes</span>
            </button>
          </div>
        )}

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5">
          {/* 1. Scanned Result View */}
          {scannedCheckpoint ? (
            <div className="space-y-4 animate-in fade-in zoom-in-95 duration-200">
              <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-500 text-slate-950 flex items-center justify-center font-bold shrink-0">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
                    Checkpoint Verified
                  </span>
                  <h3 className="font-bold text-base text-slate-100">
                    {scannedCheckpoint.title}
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5">
                    {scannedCheckpoint.buildingName} • {scannedCheckpoint.floorName}
                  </p>
                </div>
              </div>

              {/* Step-by-Step Directions from this checkpoint */}
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2.5">
                <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5" />
                  Turn-by-Turn Indoor Walking Guide:
                </h4>
                <ul className="space-y-2 text-xs text-slate-200 divide-y divide-slate-800/60 pt-1">
                  {scannedCheckpoint.stepGuide.map((step, idx) => (
                    <li key={idx} className="pt-2 flex items-start gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-800 text-amber-400 font-bold flex items-center justify-center text-[10px] shrink-0">
                        {idx + 1}
                      </span>
                      <span className="leading-relaxed">{step}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  onClick={() => {
                    const loc = CAMPUS_LOCATIONS.find((l) => l.id === scannedCheckpoint.buildingId);
                    if (loc) {
                      onOpenFloorPlan(loc, scannedCheckpoint.floorNumber);
                      onClose();
                    }
                  }}
                  className="py-2.5 px-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow transition"
                >
                  <Layers className="w-4 h-4" />
                  <span>Floor Blueprint</span>
                </button>

                <button
                  onClick={() => {
                    const loc = CAMPUS_LOCATIONS.find((l) => l.id === scannedCheckpoint.buildingId);
                    if (loc) {
                      onSelectCheckpointLocation(loc, scannedCheckpoint.floorNumber);
                      onClose();
                    }
                  }}
                  className="py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow transition"
                >
                  <MapPin className="w-4 h-4" />
                  <span>View on Campus Map</span>
                </button>
              </div>

              <button
                onClick={() => setScannedCheckpoint(null)}
                className="w-full py-2 text-slate-400 hover:text-white text-xs font-medium transition"
              >
                Scan Another QR Code
              </button>
            </div>
          ) : activeTab === 'camera' ? (
            /* 2. Live Camera View */
            <div className="space-y-4">
              <div className="relative aspect-square max-w-sm mx-auto bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 flex items-center justify-center">
                {cameraError ? (
                  <div className="p-6 text-center space-y-3">
                    <AlertTriangle className="w-10 h-10 text-amber-400 mx-auto" />
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {cameraError}
                    </p>
                    <button
                      onClick={() => setActiveTab('demo')}
                      className="px-4 py-2 bg-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow"
                    >
                      Use Demo Checkpoints Tab
                    </button>
                  </div>
                ) : (
                  <>
                    <video
                      ref={videoRef}
                      className="w-full h-full object-cover"
                      playsInline
                      muted
                    />
                    {/* Viewfinder Overlay Frame */}
                    <div className="absolute inset-8 border-2 border-amber-400/80 rounded-2xl pointer-events-none flex flex-col justify-between p-2">
                      <div className="flex justify-between">
                        <div className="w-4 h-4 border-t-2 border-l-2 border-amber-400" />
                        <div className="w-4 h-4 border-t-2 border-r-2 border-amber-400" />
                      </div>
                      {/* Scanning Laser Animation */}
                      <div className="w-full h-0.5 bg-gradient-to-r from-transparent via-amber-400 to-transparent animate-pulse" />
                      <div className="flex justify-between">
                        <div className="w-4 h-4 border-b-2 border-l-2 border-amber-400" />
                        <div className="w-4 h-4 border-b-2 border-r-2 border-amber-400" />
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Quick simulation buttons for camera tab */}
              <div className="space-y-2">
                <p className="text-xs text-slate-400 text-center">
                  Quick test: Tap a sample checkpoint below to simulate scanning
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleCheckpointSelect(QR_CHECKPOINTS[2])} // C-Block 001
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-left border border-slate-700 transition"
                  >
                    <span className="font-bold text-amber-400 block">C Block Entrance</span>
                    <span className="text-[10px] text-slate-400">Ground Floor Lobby</span>
                  </button>
                  <button
                    onClick={() => handleCheckpointSelect(QR_CHECKPOINTS[4])} // C-Block 201
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-left border border-slate-700 transition"
                  >
                    <span className="font-bold text-amber-400 block">C Block 2nd Floor</span>
                    <span className="text-[10px] text-slate-400">AI & Data Science</span>
                  </button>
                </div>
              </div>
            </div>
          ) : activeTab === 'demo' ? (
            /* 3. Demo Checkpoints List */
            <div className="space-y-2.5">
              <p className="text-xs text-slate-400 mb-2">
                Select any official campus QR checkpoint to test instant indoor arrival:
              </p>
              <div className="space-y-2">
                {QR_CHECKPOINTS.map((cp) => (
                  <div
                    key={cp.id}
                    onClick={() => handleCheckpointSelect(cp)}
                    className="p-3 bg-slate-950/80 hover:bg-slate-800/80 border border-slate-800 hover:border-slate-700 rounded-2xl transition cursor-pointer flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center font-bold text-xs text-amber-400">
                        {cp.buildingId}
                      </div>
                      <div>
                        <h4 className="font-bold text-xs text-slate-100">
                          {cp.title}
                        </h4>
                        <p className="text-[11px] text-slate-400">
                          {cp.buildingName} • {cp.floorName}
                        </p>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-500 shrink-0" />
                  </div>
                ))}
              </div>
            </div>
          ) : (
            /* 4. Printable Sheet Tab */
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-xs text-slate-300">
                  Ready-to-print QR codes for campus facility placement:
                </p>
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print All</span>
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {QR_CHECKPOINTS.map((cp) => (
                  <div
                    key={cp.id}
                    className="p-3 bg-white text-slate-900 rounded-2xl shadow flex flex-col items-center text-center space-y-2"
                  >
                    <span className="text-[9px] font-black tracking-tighter uppercase text-slate-600">
                      Karpagam College of Engg
                    </span>
                    {qrImages[cp.id] && (
                      <img
                        src={qrImages[cp.id]}
                        alt={cp.title}
                        className="w-28 h-28 object-contain"
                      />
                    )}
                    <div>
                      <h5 className="font-bold text-[11px] leading-tight text-slate-900">
                        {cp.title}
                      </h5>
                      <span className="text-[9px] font-mono text-slate-500 block mt-0.5">
                        {cp.id}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
