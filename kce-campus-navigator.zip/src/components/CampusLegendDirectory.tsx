import React, { useState } from 'react';
import {
  Search,
  Navigation,
  MapPin,
  Layers,
  Sparkles,
  Building2,
  FlaskConical,
  Coffee,
  Trophy,
  ShieldCheck,
  QrCode,
  Clock,
  Accessibility,
} from 'lucide-react';
import { CAMPUS_LOCATIONS } from '../data/campusData';
import { CampusLocation } from '../types/campus';

interface CampusLegendDirectoryProps {
  onSelectLocation: (loc: CampusLocation) => void;
  onNavigateToLocation: (loc: CampusLocation) => void;
  onOpenFloorPlan: (loc: CampusLocation) => void;
  onOpenQR: (loc: CampusLocation) => void;
}

export const CampusLegendDirectory: React.FC<CampusLegendDirectoryProps> = ({
  onSelectLocation,
  onNavigateToLocation,
  onOpenFloorPlan,
  onOpenQR,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All 45 Locations', icon: Building2 },
    { id: 'academic', label: 'Academic & Blocks', icon: Building2 },
    { id: 'lab', label: 'Laboratories (13-19, 21-22)', icon: FlaskConical },
    { id: 'hostel', label: 'Hostels & Dining (31-33, 39, 41)', icon: Coffee },
    { id: 'sports', label: 'Sports & Grounds (2-4, 23, 34)', icon: Trophy },
    { id: 'amenity', label: 'Amenities & Admin (1, 12, 35-37, 45)', icon: ShieldCheck },
  ];

  const filteredLocations = CAMPUS_LOCATIONS.filter((loc) => {
    // Category match
    let catMatch = true;
    if (selectedCategory === 'academic') catMatch = loc.category === 'academic' || loc.category === 'admin';
    else if (selectedCategory === 'lab') catMatch = loc.category === 'lab';
    else if (selectedCategory === 'hostel') catMatch = loc.category === 'hostel';
    else if (selectedCategory === 'sports') catMatch = loc.category === 'sports';
    else if (selectedCategory === 'amenity') catMatch = loc.category === 'amenity' || loc.category === 'parking';

    // Search query match
    let qMatch = true;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const numMatch = loc.number.toString() === q || `location ${loc.number}`.includes(q) || `block ${loc.number}`.includes(q);
      const nameMatch = loc.name.toLowerCase().includes(q);
      const codeMatch = loc.code?.toLowerCase().includes(q);
      const deptMatch = loc.departments?.some((d) => d.toLowerCase().includes(q));
      const labMatch = loc.labs?.some((l) => l.toLowerCase().includes(q));
      const descMatch = loc.shortDesc.toLowerCase().includes(q);
      qMatch = !!(numMatch || nameMatch || codeMatch || deptMatch || labMatch || descMatch);
    }

    return catMatch && qMatch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Header Info */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs font-bold uppercase">
              Official Campus Map Legend
            </span>
            <span className="text-xs text-slate-400 font-medium">45 Campus Locations</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-100 mt-1">
            Karpagam College of Engineering Directory
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Full comprehensive directory of academic blocks, departments, research labs, hostels, and sports grounds.
          </p>
        </div>

        {/* Quick Search */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by number (1-45), lab, or dept..."
            className="w-full bg-slate-800 text-xs sm:text-sm text-slate-100 placeholder-slate-400 pl-9 pr-4 py-2.5 rounded-xl border border-slate-700 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => {
          const Icon = cat.icon;
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition flex items-center gap-2 ${
                isSelected
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'bg-slate-900/90 text-slate-300 hover:bg-slate-800 border border-slate-800'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Locations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredLocations.map((loc) => (
          <div
            key={loc.id}
            className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 shadow-lg transition-all duration-200 flex flex-col justify-between space-y-3 group"
          >
            {/* Top row */}
            <div>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span
                    className="w-10 h-10 rounded-xl flex items-center justify-center font-black text-white text-base shadow-md shrink-0"
                    style={{ backgroundColor: loc.color }}
                  >
                    {loc.number}
                  </span>
                  <div>
                    <h3 className="font-bold text-sm sm:text-base text-slate-100 group-hover:text-amber-400 transition leading-snug">
                      {loc.name}
                    </h3>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[10px] uppercase font-bold text-slate-400">
                        {loc.category}
                      </span>
                      {loc.code && (
                        <span className="text-[10px] font-mono px-1 py-0.2 rounded bg-slate-800 text-slate-300">
                          {loc.code}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <p className="text-xs text-slate-400 mt-2.5 line-clamp-2 leading-relaxed">
                {loc.shortDesc}
              </p>

              {/* Departments or Labs Pills */}
              {loc.departments && loc.departments.length > 0 && (
                <div className="mt-2.5 flex flex-wrap gap-1">
                  {loc.departments.slice(0, 3).map((dept, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded bg-slate-800/80 text-[10px] text-slate-300 border border-slate-700/50"
                    >
                      {dept}
                    </span>
                  ))}
                  {loc.departments.length > 3 && (
                    <span className="px-1.5 py-0.5 text-[10px] text-slate-500">
                      +{loc.departments.length - 3} more
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Bottom Controls */}
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => onSelectLocation(loc)}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1 border border-slate-700 transition"
                  title="View on Campus Map"
                >
                  <MapPin className="w-3.5 h-3.5 text-amber-400" />
                  <span>Map</span>
                </button>

                {loc.floors && loc.floors.length > 0 && (
                  <button
                    onClick={() => onOpenFloorPlan(loc)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-400 text-xs border border-slate-700 transition"
                    title="View Indoor Floor Plan"
                  >
                    <Layers className="w-3.5 h-3.5" />
                  </button>
                )}

                <button
                  onClick={() => onOpenQR(loc)}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-400 text-xs border border-slate-700 transition"
                  title="QR Checkpoint"
                >
                  <QrCode className="w-3.5 h-3.5" />
                </button>
              </div>

              <button
                onClick={() => onNavigateToLocation(loc)}
                className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center gap-1 shadow-md shadow-amber-500/10 transition"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Navigate</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
