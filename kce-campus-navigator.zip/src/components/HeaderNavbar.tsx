import React from 'react';
import {
  MapPin,
  Search,
  Compass,
  QrCode,
  Sparkles,
  Mic,
  BookOpen,
  Navigation,
  Layers,
  LayoutDashboard,
  Home,
} from 'lucide-react';
import { CAMPUS_LOCATIONS } from '../data/campusData';
import { CampusLocation, UserLiveLocation } from '../types/campus';
import { LocateFixed } from 'lucide-react';

interface HeaderNavbarProps {
  activeTab: 'home' | 'map' | 'directory' | 'indoor' | 'chat';
  setActiveTab: (tab: 'home' | 'map' | 'directory' | 'indoor' | 'chat') => void;
  onOpenVoice: () => void;
  onOpenQRScanner: () => void;
  onSelectLocation: (loc: CampusLocation) => void;
  mapLayer: 'hybrid' | 'vector' | 'satellite';
  setMapLayer: (layer: 'hybrid' | 'vector' | 'satellite') => void;
  isNavigating: boolean;
  userLocation?: UserLiveLocation;
  onOpenLiveLocation?: () => void;
}

export const HeaderNavbar: React.FC<HeaderNavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenVoice,
  onOpenQRScanner,
  onSelectLocation,
  mapLayer,
  setMapLayer,
  isNavigating,
  userLocation,
  onOpenLiveLocation,
}) => {
  const [searchQuery, setSearchQuery] = React.useState('');
  const [isSearchOpen, setIsSearchOpen] = React.useState(false);
  const searchRef = React.useRef<HTMLDivElement>(null);

  // Close search dropdown on click outside
  React.useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const searchResults = React.useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase().trim();
    return CAMPUS_LOCATIONS.filter((loc) => {
      const matchName = loc.name.toLowerCase().includes(q);
      const matchNum = loc.number.toString() === q || `block ${loc.number}`.includes(q);
      const matchCode = loc.code?.toLowerCase().includes(q);
      const matchDepts = loc.departments?.some((d) => d.toLowerCase().includes(q));
      const matchLabs = loc.labs?.some((l) => l.toLowerCase().includes(q));
      const matchDesc = loc.shortDesc.toLowerCase().includes(q);
      return matchName || matchNum || matchCode || matchDepts || matchLabs || matchDesc;
    }).slice(0, 7);
  }, [searchQuery]);

  return (
    <header className="sticky top-0 z-30 bg-slate-900/95 text-white backdrop-blur-md border-b border-slate-800 shadow-md">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-2.5 flex items-center justify-between gap-2 sm:gap-4">
        {/* Brand & Badge */}
        <div className="flex items-center gap-2.5 shrink-0 cursor-pointer" onClick={() => setActiveTab('home')}>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-yellow-400 to-sky-500 p-0.5 shadow-md flex items-center justify-center">
            <div className="w-full h-full bg-slate-900 rounded-[10px] flex items-center justify-center font-black text-amber-400 text-sm tracking-tighter">
              KCE
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-bold text-sm sm:text-base text-slate-100 tracking-tight leading-tight">
                KCE Navigator
              </h1>
              <span className="hidden sm:inline-block text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                NAAC A+
              </span>
            </div>
            <p className="text-[10px] sm:text-xs text-slate-400 font-medium">
              Karpagam College of Engineering
            </p>
          </div>
        </div>

        {/* Primary Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 bg-slate-950/60 p-1 rounded-xl border border-slate-800">
          <button
            id="nav-tab-home"
            onClick={() => setActiveTab('home')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              activeTab === 'home'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Home className="w-3.5 h-3.5" />
            Home
          </button>
          <button
            id="nav-tab-map"
            onClick={() => setActiveTab('map')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              activeTab === 'map'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            Interactive Map
          </button>
          <button
            id="nav-tab-directory"
            onClick={() => setActiveTab('directory')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              activeTab === 'directory'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            Directory (1–45)
          </button>
        </nav>

        {/* Global Search Bar */}
        <div ref={searchRef} className="relative flex-1 max-w-xs sm:max-w-sm mx-1 sm:mx-2">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search blocks, labs, rooms..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setIsSearchOpen(true);
              }}
              onFocus={() => setIsSearchOpen(true)}
              className="w-full bg-slate-800/90 text-xs text-slate-100 placeholder-slate-400 pl-8 pr-7 py-1.5 sm:py-2 rounded-xl border border-slate-700/80 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs p-1"
              >
                ✕
              </button>
            )}
          </div>

          {/* Autocomplete Dropdown */}
          {isSearchOpen && searchResults.length > 0 && (
            <div className="absolute top-full mt-1.5 left-0 right-0 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden z-50 divide-y divide-slate-800/60 max-h-80 overflow-y-auto">
              {searchResults.map((loc) => (
                <div
                  key={loc.id}
                  onClick={() => {
                    onSelectLocation(loc);
                    setIsSearchOpen(false);
                    setSearchQuery('');
                    setActiveTab('map');
                  }}
                  className="px-3.5 py-2.5 hover:bg-slate-800/80 cursor-pointer transition flex items-center justify-between gap-2"
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0"
                      style={{ backgroundColor: loc.color }}
                    >
                      {loc.number}
                    </span>
                    <div>
                      <div className="text-xs sm:text-sm font-semibold text-slate-100 flex items-center gap-1.5">
                        {loc.name}
                        {loc.code && (
                          <span className="text-[10px] text-slate-400 px-1 py-0.2 bg-slate-800 rounded">
                            {loc.code}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 line-clamp-1">
                        {loc.shortDesc}
                      </p>
                    </div>
                  </div>
                  <Navigation className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Action Controls & Navigation Tabs */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Live Location / GPS Trigger */}
          {onOpenLiveLocation && (
            <button
              id="btn-header-live-gps"
              onClick={onOpenLiveLocation}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 hover:text-emerald-200 rounded-xl border border-emerald-500/30 text-xs font-semibold transition"
              title="Pin Live Location & GPS Settings"
            >
              <LocateFixed className="w-4 h-4 text-emerald-400 animate-pulse" />
              <span className="hidden md:inline">
                {userLocation?.isSimulated ? 'Custom Pin' : 'Live GPS'}
              </span>
            </button>
          )}

          {/* QR Scanner Trigger */}
          <button
            id="btn-header-qr"
            onClick={onOpenQRScanner}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl border border-slate-700 text-xs font-medium transition"
            title="Scan Indoor QR Code"
          >
            <QrCode className="w-4 h-4 text-emerald-400" />
            <span className="hidden sm:inline">Indoor QR</span>
          </button>

          {/* Voice Assistant Trigger */}
          <button
            id="btn-header-voice"
            onClick={onOpenVoice}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-gradient-to-r from-amber-500/20 to-orange-500/20 hover:from-amber-500/30 hover:to-orange-500/30 text-amber-300 rounded-xl border border-amber-500/40 text-xs font-semibold transition"
            title="Voice Assistant"
          >
            <Mic className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Voice</span>
          </button>

          {/* AI Mitra Chat Trigger */}
          <button
            id="btn-header-ai-mitra"
            onClick={() => setActiveTab('chat')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-sm ${
              activeTab === 'chat'
                ? 'bg-amber-500 text-slate-950'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white'
            }`}
          >
            <Sparkles className="w-4 h-4 animate-pulse" />
            <span className="hidden sm:inline">AI Mitra</span>
          </button>
        </div>
      </div>

      {/* Secondary Mobile Nav Tabs */}
      <div className="flex lg:hidden border-t border-slate-800/80 px-2 py-1.5 justify-around bg-slate-950/60">
        <button
          onClick={() => setActiveTab('home')}
          className={`flex items-center gap-1 text-xs py-1 px-2.5 rounded-lg font-semibold ${
            activeTab === 'home' ? 'bg-blue-600 text-white' : 'text-slate-400'
          }`}
        >
          <Home className="w-3.5 h-3.5" />
          Home
        </button>
        <button
          onClick={() => setActiveTab('map')}
          className={`flex items-center gap-1 text-xs py-1 px-2.5 rounded-lg font-semibold ${
            activeTab === 'map' ? 'bg-blue-600 text-white' : 'text-slate-400'
          }`}
        >
          <Compass className="w-3.5 h-3.5" />
          Map
        </button>
        <button
          onClick={() => setActiveTab('directory')}
          className={`flex items-center gap-1 text-xs py-1 px-2.5 rounded-lg font-semibold ${
            activeTab === 'directory' ? 'bg-blue-600 text-white' : 'text-slate-400'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          Directory (1–45)
        </button>
        <button
          onClick={() => setActiveTab('chat')}
          className={`flex items-center gap-1 text-xs py-1 px-2.5 rounded-lg font-semibold ${
            activeTab === 'chat' ? 'bg-amber-500 text-slate-950' : 'text-slate-400'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          AI Guide
        </button>
      </div>
    </header>
  );
};
