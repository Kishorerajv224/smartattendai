import React from 'react';
import {
  X,
  Navigation,
  Layers,
  Clock,
  Accessibility,
  Building2,
  FlaskConical,
  Sparkles,
  QrCode,
  Share2,
  CheckCircle2,
} from 'lucide-react';
import { CampusLocation } from '../types/campus';

interface BuildingDetailModalProps {
  location: CampusLocation | null;
  onClose: () => void;
  onStartNavigation: (location: CampusLocation) => void;
  onSetOrigin?: (location: CampusLocation) => void;
  onOpenFloorPlan: (location: CampusLocation) => void;
  onScanQR: (location: CampusLocation) => void;
  onAskAi: (prompt: string) => void;
}

export const BuildingDetailModal: React.FC<BuildingDetailModalProps> = ({
  location,
  onClose,
  onStartNavigation,
  onSetOrigin,
  onOpenFloorPlan,
  onScanQR,
  onAskAi,
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!location) return null;

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(
        `Karpagam College of Engineering - Location #${location.number}: ${location.name} (${location.shortDesc})`
      );
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col animate-in slide-in-from-bottom-6 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with color accent bar */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-start justify-between gap-3 relative">
          <div className="flex items-start gap-3.5">
            <span
              className="w-12 h-12 rounded-2xl flex items-center justify-center font-black text-white text-lg shrink-0 shadow-lg"
              style={{ backgroundColor: location.color }}
            >
              {location.number}
            </span>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-800 text-amber-400 border border-slate-700">
                  {location.category}
                </span>
                {location.code && (
                  <span className="text-[11px] font-mono px-1.5 py-0.5 rounded bg-slate-800/80 text-slate-300">
                    {location.code}
                  </span>
                )}
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-slate-100 mt-1 leading-snug">
                {location.name}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleShare}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
              title="Share Location"
            >
              {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Body Content */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 text-slate-300 text-xs sm:text-sm divide-y divide-slate-800/60">
          {/* Overview */}
          <div>
            <p className="text-slate-200 leading-relaxed">
              {location.fullDesc || location.shortDesc}
            </p>
          </div>

          {/* Departments Housed */}
          {location.departments && location.departments.length > 0 && (
            <div className="pt-3.5">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-amber-400" />
                Departments & Wings
              </h3>
              <div className="flex flex-wrap gap-1.5">
                {location.departments.map((dept, idx) => (
                  <span
                    key={idx}
                    className="px-2.5 py-1 rounded-lg bg-slate-800/80 border border-slate-700 text-slate-200 text-xs font-medium"
                  >
                    {dept}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Laboratories & Centers */}
          {location.labs && location.labs.length > 0 && (
            <div className="pt-3.5">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <FlaskConical className="w-3.5 h-3.5 text-sky-400" />
                Laboratories & Equipment
              </h3>
              <ul className="space-y-1 text-xs text-slate-300">
                {location.labs.map((lab, idx) => (
                  <li key={idx} className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-sky-400" />
                    <span>{lab}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Key Details: Hours & Accessibility */}
          <div className="pt-3.5 grid grid-cols-2 gap-3">
            {location.timings && (
              <div className="p-2.5 rounded-xl bg-slate-800/50 border border-slate-800 flex items-start gap-2">
                <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-[11px] text-slate-400 block font-medium">Timings</span>
                  <span className="text-xs font-semibold text-slate-200">{location.timings}</span>
                </div>
              </div>
            )}
            <div className="p-2.5 rounded-xl bg-slate-800/50 border border-slate-800 flex items-start gap-2">
              <Accessibility className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <span className="text-[11px] text-slate-400 block font-medium">Accessibility</span>
                <span className="text-xs font-semibold text-slate-200">
                  {location.wheelchairAccessible ? 'Wheelchair Accessible (Ramps/Lift)' : 'Standard Access'}
                </span>
              </div>
            </div>
          </div>

          {/* Amenities Chips */}
          {location.amenities && location.amenities.length > 0 && (
            <div className="pt-3.5">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                Building Amenities
              </h3>
              <div className="flex flex-wrap gap-1.5">
                {location.amenities.map((amn, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[11px] border border-slate-700/60"
                  >
                    ✓ {amn}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Action Button Footer */}
        <div className="p-4 bg-slate-950/80 border-t border-slate-800 flex flex-wrap items-center gap-2">
          {/* Set as Start Point Action */}
          {onSetOrigin && (
            <button
              onClick={() => {
                onSetOrigin(location);
                onClose();
              }}
              className="py-2.5 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-300 font-semibold text-xs flex items-center gap-1.5 border border-emerald-500/30 transition"
              title="Set as Starting Point"
            >
              <Navigation className="w-3.5 h-3.5 rotate-180 text-emerald-400" />
              <span>Set as Start</span>
            </button>
          )}

          {/* Primary Navigate Action */}
          <button
            onClick={() => {
              onStartNavigation(location);
              onClose();
            }}
            className="flex-1 min-w-[130px] py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 transition"
          >
            <Navigation className="w-4 h-4" />
            <span>Navigate Here</span>
          </button>

          {/* Floor Plan Action (if multi-storey or floor plan available) */}
          <button
            onClick={() => {
              onOpenFloorPlan(location);
              onClose();
            }}
            className="py-2.5 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center gap-1.5 border border-slate-700 transition"
            title="View Indoor Floor Plans"
          >
            <Layers className="w-4 h-4 text-sky-400" />
            <span>Floor Plan</span>
          </button>

          {/* QR Code Action */}
          <button
            onClick={() => {
              onScanQR(location);
              onClose();
            }}
            className="py-2.5 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center gap-1.5 border border-slate-700 transition"
            title="Scan QR checkpoint at this location"
          >
            <QrCode className="w-4 h-4 text-emerald-400" />
            <span>QR Scan</span>
          </button>

          {/* Ask AI Action */}
          <button
            onClick={() => {
              onAskAi(`Tell me about ${location.name} (Location #${location.number}) at KCE.`);
              onClose();
            }}
            className="p-2.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 font-semibold text-xs flex items-center justify-center border border-indigo-500/40 transition"
            title="Ask AI Guide"
          >
            <Sparkles className="w-4 h-4 text-indigo-400" />
          </button>
        </div>
      </div>
    </div>
  );
};
