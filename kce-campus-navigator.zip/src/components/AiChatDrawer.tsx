import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Send,
  Sparkles,
  Mic,
  MicOff,
  Navigation,
  Layers,
  MapPin,
  Bot,
  User,
  Volume2,
  VolumeX,
  RotateCcw,
} from 'lucide-react';
import { ChatMessage, CampusLocation } from '../types/campus';
import { CAMPUS_LOCATIONS } from '../data/campusData';
import { speakText, isSpeechRecognitionSupported, createSpeechRecognizer } from '../utils/speech';

interface AiChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToBuilding: (location: CampusLocation) => void;
  onOpenFloorPlan: (location: CampusLocation, floorNumber?: number) => void;
  onLocateOnMap: (location: CampusLocation) => void;
  initialPrompt?: string;
}

export const AiChatDrawer: React.FC<AiChatDrawerProps> = ({
  isOpen,
  onClose,
  onNavigateToBuilding,
  onOpenFloorPlan,
  onLocateOnMap,
  initialPrompt,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'assistant',
      text: 'Vanakkam & Welcome to Karpagam College of Engineering! I am **KCE Mitra**, your intelligent campus guide.\n\nAsk me anything about blocks 1–45, departments, laboratories, classrooms, hostel mess timings, or step-by-step navigation directions across campus!',
      timestamp: new Date(),
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognizerRef = useRef<any>(null);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Handle initial prompt from parent
  useEffect(() => {
    if (initialPrompt && isOpen) {
      handleSendMessage(initialPrompt);
    }
  }, [initialPrompt, isOpen]);

  const quickPrompts = [
    'Where is the Chemistry Laboratory?',
    'How do I reach Placement Hall from Main Gate?',
    'What labs are inside C Block?',
    'Where can I find Food Court & Cafeteria?',
    'Show me Boys Hostel & Mess location',
  ];

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputText).trim();
    if (!query || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: query,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputText('');
    setIsLoading(true);

    try {
      // Format chat history for API
      const history = messages
        .filter((m) => m.id !== '1')
        .map((m) => ({
          role: m.sender === 'user' ? 'user' : 'model',
          parts: [{ text: m.text }],
        }));

      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history,
        }),
      });

      const data = await res.json();
      const aiReply = data.reply || "I'm sorry, I couldn't process that request right now.";

      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'assistant',
        text: aiReply,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, aiMsg]);
      speakText(aiReply.replace(/[*#_]/g, ''));
    } catch (err) {
      console.error('Chat error:', err);
      // Fallback response
      const fallbackMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'assistant',
        text: "I'm having trouble connecting to the network right now. You can check the Campus Directory (1-45) tab for all official locations and timings.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // Voice input toggle
  const toggleRecording = () => {
    if (isRecording) {
      if (recognizerRef.current) {
        recognizerRef.current.stop();
      }
      setIsRecording(false);
    } else {
      if (!isSpeechRecognitionSupported()) {
        alert('Voice speech recognition is not supported in this browser.');
        return;
      }

      const recognizer = createSpeechRecognizer(
        (transcript) => {
          setInputText(transcript);
          handleSendMessage(transcript);
          setIsRecording(false);
        },
        () => setIsRecording(false),
        () => setIsRecording(false)
      );

      if (recognizer) {
        recognizerRef.current = recognizer;
        recognizer.start();
        setIsRecording(true);
      }
    }
  };

  // Helper to extract building mentions and render actionable buttons
  const renderMessageActions = (text: string) => {
    // Check if any campus location is mentioned in the response
    const mentionedLocations = CAMPUS_LOCATIONS.filter((loc) => {
      const nameMatch = text.toLowerCase().includes(loc.name.toLowerCase());
      const numMatch = text.includes(`Location #${loc.number}`) || text.includes(`Number ${loc.number}`);
      return nameMatch || numMatch;
    }).slice(0, 2);

    if (mentionedLocations.length === 0) return null;

    return (
      <div className="mt-2.5 pt-2 border-t border-slate-700/60 flex flex-wrap gap-1.5">
        {mentionedLocations.map((loc) => (
          <div key={loc.id} className="flex items-center gap-1">
            <button
              onClick={() => {
                onNavigateToBuilding(loc);
                onClose();
              }}
              className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center gap-1 shadow transition"
            >
              <Navigation className="w-3 h-3" />
              <span>Navigate to {loc.name}</span>
            </button>
            <button
              onClick={() => {
                onLocateOnMap(loc);
                onClose();
              }}
              className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs"
              title="Show on map"
            >
              <MapPin className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full sm:w-[460px] h-full bg-slate-900 border-l border-slate-800 shadow-2xl flex flex-col animate-in slide-in-from-right duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between gap-3 bg-slate-900/90">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-indigo-600 p-0.5 flex items-center justify-center shadow">
              <div className="w-full h-full bg-slate-900 rounded-[10px] flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
              </div>
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
                KCE Mitra AI Guide
                <span className="text-[10px] font-semibold px-1.5 py-0.2 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Gemini 3.7
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">Campus Assistance & Routing</p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() =>
                setMessages([
                  {
                    id: '1',
                    sender: 'assistant',
                    text: 'Vanakkam! How can I help you find your way around Karpagam College of Engineering today?',
                    timestamp: new Date(),
                  },
                ])
              }
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
              title="Clear conversation"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-2.5 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.sender === 'assistant' && (
                <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
                  <Bot className="w-4 h-4" />
                </div>
              )}
              <div
                className={`max-w-[85%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed shadow-sm ${
                  msg.sender === 'user'
                    ? 'bg-amber-500 text-slate-950 font-medium rounded-tr-none'
                    : 'bg-slate-800/90 text-slate-200 border border-slate-700/70 rounded-tl-none'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.text}</div>
                {msg.sender === 'assistant' && renderMessageActions(msg.text)}
              </div>
              {msg.sender === 'user' && (
                <div className="w-7 h-7 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex gap-2.5 items-center text-slate-400 text-xs pl-9">
              <div className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
              <span>KCE Mitra is searching campus map directory...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Quick Prompts */}
        <div className="px-3 py-2 bg-slate-950/60 border-t border-slate-800/80 overflow-x-auto scrollbar-none flex gap-1.5">
          {quickPrompts.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(prompt)}
              className="px-2.5 py-1 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-300 text-[11px] whitespace-nowrap border border-slate-700/60 transition"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Composer Footer */}
        <div className="p-3 bg-slate-900 border-t border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <div className="relative flex-1">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Ask KCE Mitra (e.g. Where is Chemistry Lab?)"
                className="w-full bg-slate-800 text-xs sm:text-sm text-slate-100 placeholder-slate-400 pl-3.5 pr-10 py-2.5 rounded-xl border border-slate-700 focus:outline-none focus:border-amber-400"
              />
              <button
                type="button"
                onClick={toggleRecording}
                className={`absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-lg transition ${
                  isRecording
                    ? 'bg-red-500 text-white animate-pulse'
                    : 'text-slate-400 hover:text-amber-400'
                }`}
                title={isRecording ? 'Listening...' : 'Voice Input'}
              >
                {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>
            </div>

            <button
              type="submit"
              disabled={!inputText.trim() || isLoading}
              className="p-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 font-bold transition shadow-md"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
