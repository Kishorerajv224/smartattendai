export type LocationCategory =
  | 'academic'
  | 'lab'
  | 'hostel'
  | 'sports'
  | 'amenity'
  | 'parking'
  | 'admin'
  | 'facility';

export interface Coordinate {
  x: number; // Percentage coordinate on canvas (0 to 1000)
  y: number; // Percentage coordinate on canvas (0 to 1000)
  lat?: number; // Real GPS Latitude
  lng?: number; // Real GPS Longitude
}

export interface BuildingPolygon {
  points: { x: number; y: number }[];
}

export interface RoomInfo {
  id: string;
  roomNumber: string;
  name: string;
  category: 'classroom' | 'lab' | 'office' | 'seminar' | 'restroom' | 'utility' | 'facility';
  department?: string;
  floor: number;
  qrCodeId: string;
  description?: string;
  coordinates: { x: number; y: number }; // relative coordinate on floor plan (0-100)
}

export interface FloorPlan {
  floorNumber: number;
  floorName: string;
  description: string;
  rooms: RoomInfo[];
}

export interface CampusLocation {
  id: number; // Numbered 1-45 from official map legend
  number: number;
  name: string;
  code?: string;
  category: LocationCategory;
  shortDesc: string;
  fullDesc: string;
  departments?: string[];
  labs?: string[];
  timings?: string;
  floorCount?: number;
  floors?: FloorPlan[];
  coordinates: Coordinate;
  polygon?: BuildingPolygon;
  amenities?: string[];
  wheelchairAccessible: boolean;
  color: string;
}

export interface NavNode {
  id: string;
  name: string;
  x: number;
  y: number;
  lat?: number;
  lng?: number;
  type: 'junction' | 'building' | 'gate' | 'parking' | 'sports' | 'poi';
  buildingId?: number;
}

export interface NavEdge {
  from: string;
  to: string;
  distanceMeters: number;
  pathType: 'main_road' | 'walkway' | 'paved_trail' | 'corridor';
}

export interface RouteStep {
  instruction: string;
  distanceMeters: number;
  icon: 'straight' | 'turn_left' | 'turn_right' | 'slight_left' | 'slight_right' | 'arrive' | 'start';
  targetNodeId: string;
  spokenText: string;
  coordinate: { x: number; y: number };
}

export interface RouteResult {
  nodes: NavNode[];
  pathCoordinates: { x: number; y: number }[];
  totalDistanceMeters: number;
  estimatedTimeMinutes: number;
  steps: RouteStep[];
}

export interface QRCodeCheckpoint {
  id: string;
  title: string;
  buildingId: number;
  buildingName: string;
  floorNumber: number;
  floorName: string;
  roomNumber?: string;
  locationDesc: string;
  stepGuide: string[];
  indoorMapUrl?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: Date | string;
  action?: {
    type: 'NAVIGATE' | 'VIEW_FLOOR' | 'VIEW_INFO';
    targetId?: number;
    targetName?: string;
    floorNumber?: number;
  };
}

export interface UserLiveLocation {
  x: number;
  y: number;
  lat?: number;
  lng?: number;
  heading: number; // 0-360 degrees
  accuracy?: number;
  isSimulated: boolean;
  currentFloor?: number;
}
