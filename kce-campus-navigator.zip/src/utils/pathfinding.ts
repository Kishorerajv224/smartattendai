import { NavNode, RouteResult, RouteStep } from '../types/campus';
import { NAV_NODES, NAV_EDGES, CAMPUS_LOCATIONS } from '../data/campusData';

interface GraphAdjacency {
  nodeId: string;
  distance: number;
  pathType: string;
}

// Build adjacency graph from edges (undirected graph for walkable paths)
const buildAdjacencyList = (): Map<string, GraphAdjacency[]> => {
  const adj = new Map<string, GraphAdjacency[]>();

  // Initialize nodes
  for (const nodeId in NAV_NODES) {
    adj.set(nodeId, []);
  }

  // Populate edges in both directions
  for (const edge of NAV_EDGES) {
    if (!adj.has(edge.from)) adj.set(edge.from, []);
    if (!adj.has(edge.to)) adj.set(edge.to, []);

    adj.get(edge.from)!.push({
      nodeId: edge.to,
      distance: edge.distanceMeters,
      pathType: edge.pathType,
    });

    adj.get(edge.to)!.push({
      nodeId: edge.from,
      distance: edge.distanceMeters,
      pathType: edge.pathType,
    });
  }

  return adj;
};

const adjacencyList = buildAdjacencyList();

export function findNodeByBuildingId(buildingId: number): NavNode | null {
  for (const nodeId in NAV_NODES) {
    if (NAV_NODES[nodeId].buildingId === buildingId) {
      return NAV_NODES[nodeId];
    }
  }
  // Fallback: find nearest node to building coordinates
  const building = CAMPUS_LOCATIONS.find((b) => b.id === buildingId);
  if (building) {
    return findNearestNode(building.coordinates.x, building.coordinates.y);
  }
  return null;
}

export function findNearestNode(x: number, y: number): NavNode {
  let closestNode: NavNode = Object.values(NAV_NODES)[0];
  let minDistance = Infinity;

  for (const node of Object.values(NAV_NODES)) {
    const dx = node.x - x;
    const dy = node.y - y;
    const distSq = dx * dx + dy * dy;
    if (distSq < minDistance) {
      minDistance = distSq;
      closestNode = node;
    }
  }

  return closestNode;
}

// Calculate angle between three consecutive points
function calculateTurnAngle(p1: { x: number; y: number }, p2: { x: number; y: number }, p3: { x: number; y: number }): number {
  const angle1 = Math.atan2(p2.y - p1.y, p2.x - p1.x);
  const angle2 = Math.atan2(p3.y - p2.y, p3.x - p2.x);
  let diff = (angle2 - angle1) * (180 / Math.PI);
  while (diff > 180) diff -= 360;
  while (diff < -180) diff += 360;
  return diff; // Negative = turn left, Positive = turn right
}

// Generate human-friendly instructions
function generateSteps(pathNodes: NavNode[], endBuildingId?: number): RouteStep[] {
  if (pathNodes.length === 0) return [];
  if (pathNodes.length === 1) {
    return [
      {
        instruction: `You are already at ${pathNodes[0].name}.`,
        distanceMeters: 0,
        icon: 'arrive',
        targetNodeId: pathNodes[0].id,
        spokenText: `You are already at your destination: ${pathNodes[0].name}.`,
        coordinate: { x: pathNodes[0].x, y: pathNodes[0].y },
      },
    ];
  }

  const steps: RouteStep[] = [];
  
  // Step 1: Departure
  steps.push({
    instruction: `Start from ${pathNodes[0].name} and head towards ${pathNodes[1].name}.`,
    distanceMeters: getDistanceBetweenNodes(pathNodes[0], pathNodes[1]),
    icon: 'start',
    targetNodeId: pathNodes[1].id,
    spokenText: `Start walking from ${pathNodes[0].name} towards ${pathNodes[1].name}.`,
    coordinate: { x: pathNodes[0].x, y: pathNodes[0].y },
  });

  // Intermediate turns
  for (let i = 1; i < pathNodes.length - 1; i++) {
    const prev = pathNodes[i - 1];
    const curr = pathNodes[i];
    const next = pathNodes[i + 1];

    const angle = calculateTurnAngle(prev, curr, next);
    const distToNext = getDistanceBetweenNodes(curr, next);

    let turnType: 'straight' | 'turn_left' | 'turn_right' | 'slight_left' | 'slight_right' = 'straight';
    let turnPhrase = 'Continue straight';

    if (angle < -45) {
      turnType = 'turn_left';
      turnPhrase = 'Turn left';
    } else if (angle < -15) {
      turnType = 'slight_left';
      turnPhrase = 'Bear slightly left';
    } else if (angle > 45) {
      turnType = 'turn_right';
      turnPhrase = 'Turn right';
    } else if (angle > 15) {
      turnType = 'slight_right';
      turnPhrase = 'Bear slightly right';
    }

    steps.push({
      instruction: `${turnPhrase} at ${curr.name} towards ${next.name}. (${distToNext}m)`,
      distanceMeters: distToNext,
      icon: turnType,
      targetNodeId: next.id,
      spokenText: `${turnPhrase} at ${curr.name} and proceed ${distToNext} meters towards ${next.name}.`,
      coordinate: { x: curr.x, y: curr.y },
    });
  }

  // Final arrival step
  const lastNode = pathNodes[pathNodes.length - 1];
  const destName = endBuildingId
    ? CAMPUS_LOCATIONS.find((b) => b.id === endBuildingId)?.name || lastNode.name
    : lastNode.name;

  steps.push({
    instruction: `Arrive at destination: ${destName}.`,
    distanceMeters: 0,
    icon: 'arrive',
    targetNodeId: lastNode.id,
    spokenText: `You have arrived at ${destName}.`,
    coordinate: { x: lastNode.x, y: lastNode.y },
  });

  return steps;
}

function getDistanceBetweenNodes(n1: NavNode, n2: NavNode): number {
  const edge = NAV_EDGES.find(
    (e) => (e.from === n1.id && e.to === n2.id) || (e.from === n2.id && e.to === n1.id)
  );
  if (edge) return edge.distanceMeters;

  // Euclidean pixel scale approximation (~0.5m per pixel)
  const dx = n1.x - n2.x;
  const dy = n1.y - n2.y;
  return Math.round(Math.sqrt(dx * dx + dy * dy) * 0.7);
}

// Dijkstra Algorithm for Shortest Path
export function calculateShortestPath(startNodeId: string, endNodeId: string, endBuildingId?: number): RouteResult | null {
  if (!NAV_NODES[startNodeId] || !NAV_NODES[endNodeId]) {
    return null;
  }

  const distances = new Map<string, number>();
  const previous = new Map<string, string | null>();
  const unvisited = new Set<string>();

  for (const nodeId in NAV_NODES) {
    distances.set(nodeId, Infinity);
    previous.set(nodeId, null);
    unvisited.add(nodeId);
  }

  distances.set(startNodeId, 0);

  while (unvisited.size > 0) {
    // Find node with minimum distance
    let minNode: string | null = null;
    let minDistance = Infinity;

    for (const nodeId of unvisited) {
      const dist = distances.get(nodeId)!;
      if (dist < minDistance) {
        minDistance = dist;
        minNode = nodeId;
      }
    }

    if (!minNode || minDistance === Infinity) break;
    if (minNode === endNodeId) break;

    unvisited.delete(minNode);

    const neighbors = adjacencyList.get(minNode) || [];
    for (const neighbor of neighbors) {
      if (!unvisited.has(neighbor.nodeId)) continue;

      const alt = distances.get(minNode)! + neighbor.distance;
      if (alt < distances.get(neighbor.nodeId)!) {
        distances.set(neighbor.nodeId, alt);
        previous.set(neighbor.nodeId, minNode);
      }
    }
  }

  // Reconstruct path
  const pathNodeIds: string[] = [];
  let curr: string | null = endNodeId;

  while (curr !== null) {
    pathNodeIds.unshift(curr);
    curr = previous.get(curr) || null;
  }

  // If path doesn't start with startNodeId, no path was found
  if (pathNodeIds[0] !== startNodeId) {
    return null;
  }

  const nodes: NavNode[] = pathNodeIds.map((id) => NAV_NODES[id]);
  const pathCoordinates = nodes.map((n) => ({ x: n.x, y: n.y }));
  const totalDistanceMeters = distances.get(endNodeId) || 0;
  
  // Walking speed: 1.2 m/s (approx 72 m/min)
  const estimatedTimeMinutes = Math.max(1, Math.ceil(totalDistanceMeters / 70));
  const steps = generateSteps(nodes, endBuildingId);

  return {
    nodes,
    pathCoordinates,
    totalDistanceMeters,
    estimatedTimeMinutes,
    steps,
  };
}
