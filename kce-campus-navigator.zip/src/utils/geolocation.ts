import { CAMPUS_LOCATIONS, KCE_BASE_COORDINATES } from '../data/campusData';
import { CampusLocation, UserLiveLocation } from '../types/campus';

// Bounding box for KCE Campus coordinates
// Top-Left (North-West): ~10.9055 N, 76.9905 E -> Canvas (x: 200, y: 50)
// Bottom-Right (South-East): ~10.8995 N, 76.9955 E -> Canvas (x: 800, y: 750)
const KCE_BOUNDS = {
  northLat: 10.9055,
  southLat: 10.8995,
  westLng: 76.9905,
  eastLng: 76.9955,
  minCanvasX: 200,
  maxCanvasX: 800,
  minCanvasY: 50,
  maxCanvasY: 750,
};

export type GeolocationStatus =
  | 'idle'
  | 'requesting'
  | 'granted'
  | 'denied'
  | 'unavailable'
  | 'timeout'
  | 'off_campus';

/**
 * Converts real GPS (lat, lng) to canvas (x, y) coordinates on the KCE map.
 */
export function gpsToCanvasCoordinate(lat: number, lng: number): { x: number; y: number; isInsideCampus: boolean } {
  const isInsideLat = lat >= KCE_BOUNDS.southLat && lat <= KCE_BOUNDS.northLat;
  const isInsideLng = lng >= KCE_BOUNDS.westLng && lng <= KCE_BOUNDS.eastLng;
  const isInsideCampus = isInsideLat && isInsideLng;

  // Normalized 0 to 1
  const normY = (KCE_BOUNDS.northLat - lat) / (KCE_BOUNDS.northLat - KCE_BOUNDS.southLat);
  const normX = (lng - KCE_BOUNDS.westLng) / (KCE_BOUNDS.eastLng - KCE_BOUNDS.westLng);

  // Clamp within canvas drawing area (or slight overflow for outside)
  const clampedNormX = Math.max(0.05, Math.min(0.95, normX));
  const clampedNormY = Math.max(0.05, Math.min(0.95, normY));

  const x = Math.round(
    KCE_BOUNDS.minCanvasX + clampedNormX * (KCE_BOUNDS.maxCanvasX - KCE_BOUNDS.minCanvasX)
  );
  const y = Math.round(
    KCE_BOUNDS.minCanvasY + clampedNormY * (KCE_BOUNDS.maxCanvasY - KCE_BOUNDS.minCanvasY)
  );

  return { x, y, isInsideCampus };
}

/**
 * Converts canvas (x, y) coordinates back to real GPS (lat, lng).
 */
export function canvasCoordinateToGps(x: number, y: number): { lat: number; lng: number } {
  const normX = (x - KCE_BOUNDS.minCanvasX) / (KCE_BOUNDS.maxCanvasX - KCE_BOUNDS.minCanvasX);
  const normY = (y - KCE_BOUNDS.minCanvasY) / (KCE_BOUNDS.maxCanvasY - KCE_BOUNDS.minCanvasY);

  const lat = KCE_BOUNDS.northLat - normY * (KCE_BOUNDS.northLat - KCE_BOUNDS.southLat);
  const lng = KCE_BOUNDS.westLng + normX * (KCE_BOUNDS.eastLng - KCE_BOUNDS.westLng);

  return { lat, lng };
}

/**
 * Finds the nearest building or landmark to given canvas (x, y) coordinates.
 */
export function findNearestLocation(x: number, y: number): { location: CampusLocation; distanceMeters: number } | null {
  let closest: CampusLocation | null = null;
  let minDistance = Infinity;

  for (const loc of CAMPUS_LOCATIONS) {
    const dx = loc.coordinates.x - x;
    const dy = loc.coordinates.y - y;
    const dist = Math.hypot(dx, dy);
    if (dist < minDistance) {
      minDistance = dist;
      closest = loc;
    }
  }

  if (!closest) return null;
  // Approximation: 1 canvas unit ≈ 0.8 meters
  return {
    location: closest,
    distanceMeters: Math.round(minDistance * 0.8),
  };
}
